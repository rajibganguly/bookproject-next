import {
  Component,
  OnInit,
  Renderer2,
  Inject,
  ElementRef,
  AfterContentInit,
  OnDestroy,
} from '@angular/core';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { RegistrationFormService } from '../../forms/registration-form/registration-form-service';
import { CampaignBrandAttributeFieldType } from '../../models/campaign-brand/campaignBrandAttributeFieldType';
import { DOCUMENT } from '@angular/common';
import { AppService } from '../../service/app.service';
import { GlobalContext } from '../../service/constants.service';
import { CommonStoreService } from 'src/app/service/common-store.service';

@Component({
  selector: 'app-single-coupon',
  templateUrl: './single-coupon.component.html',
  styleUrls: ['./single-coupon.component.scss'],
})
export class SingleCouponComponent
  implements OnInit, AfterContentInit, OnDestroy
{
  campaignBrandAttributeFieldType: typeof CampaignBrandAttributeFieldType =
    CampaignBrandAttributeFieldType;
  
  registrationFormHeaderImageUrl: SafeUrl =
    this.sanitizer.bypassSecurityTrustUrl(
      'assets/pamitv_logo_hort_grad_blk.png'
    );
  registrationPageBackgroundColor? = 'white';
  offerAttributeTitle: string = GlobalContext.an_agent_will_contact_you_shortly;
  offerAttributeButton: string = GlobalContext.go_to_our_website;
  would_you_like_to_do: string = GlobalContext.WWYLToDo;
  thank_you: string = GlobalContext.thank_you;

  ctaButtonBackgroundColor: unknown = 'white';
  ctaButtonTextColor: unknown = 'black';
  link: string = '';

  registrationFormTitleTextColor? = 'black';
  registrationPageFont? = '';
  registrationPageFontName? = '';
  registrationPageFontSize? = '1rem';
  localStorePamiTv: string | null;
  welcomeBack: string = 'Welcome';
  couponAddMessage: string = 'Coupon added!';
  localCookieChkVar: string | null = '';

  constructor(
    private renderer: Renderer2,
    private sanitizer: DomSanitizer,
    @Inject(DOCUMENT) private document: Document,
    private registrationFormService: RegistrationFormService,
    private appService: AppService,
    private el: ElementRef,
    private commService: CommonStoreService
  ) {
    const guestName = JSON.parse(
      localStorage.getItem('fullNameAsStored') || ''
    );
    // Initiate cookie value
    if (guestName) {
      this.localCookieChkVar = this.welcomeBack + ' ' + guestName + '!';
      this.localStorePamiTv = localStorage.getItem('pamitv');
    } else {
      this.localCookieChkVar = this.welcomeBack + '!';
    }
  }

  ngOnInit() {
    // const offerAttributes = this.appService.offer.Attributes;
    const offerAttributes = this.commService.brandAttributes;
    offerAttributes.forEach((each: any, index: number) => {
      switch (each.Key) {
        case this.campaignBrandAttributeFieldType.LandingSubtitle:
          this.couponAddMessage = each.Value;
          break;
        case this.campaignBrandAttributeFieldType.QuickConnectRequestedFormSubTitleText:
          this.offerAttributeTitle = each.Value;
          break;
        case this.campaignBrandAttributeFieldType.QuickConnectCtaButtonText:
          this.offerAttributeButton = each.Value;
          break;
        default:
          break;
      }
    });
  }

  /***
   * @description: Image & Styles fetch from CampaignBrandTemplate
   */
  ngAfterContentInit() {
    this.registrationPageBackgroundColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationPageBackgroundColor
      );
    const imageUrl =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationHeaderImageUrl
      );
    this.ctaButtonTextColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationCtaTextColor
      );
    this.ctaButtonBackgroundColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationCtaBackgroundColor
      );
    if (imageUrl) {
      this.renderer.setStyle(
        this.document.body,
        'background-color',
        this.registrationPageBackgroundColor
      );
      this.registrationFormHeaderImageUrl =
        this.sanitizer.bypassSecurityTrustUrl(imageUrl);
    }
    // Dynamic Font-size setup
    const formFontSize = this.el.nativeElement.querySelector(
      '.single-coupon-comp'
    );
    this.renderer.setStyle(
      formFontSize,
      'font-size',
      this.registrationPageFontSize
    );
  }

  /***
   * @description: onclick goToWebsite
   */

  goToWebsite() {
    const offerParam = this.commService.offerParametersForQuickConnect;
    if (offerParam.length === 0) {
      console.log(
        '%cNot Available data => ' + offerParam,
        'background:#C1F1FF; color: #333'
      );
    }
    offerParam.forEach((each: any, index: number) => {
      switch (index) {
        case this.campaignBrandAttributeFieldType.LandingSubtitle:
          this.link = each.Value;
          break;
        default:
          break;
      }
    });
    let isPamiTvAvailable: any;
    if (this.localStorePamiTv) {
      isPamiTvAvailable = JSON.parse(this.localStorePamiTv);
    }
    const displayOfferId = this.commService.displayOfferId;

    const customLink = this.createCustomLink(
      offerParam,
      isPamiTvAvailable,
      displayOfferId
    );

    window.open(customLink, '_blank');
  }

  /**
   * @description If OfferParameters available and values stored in local pamitv cookies
   * @param OfferParameters
   * @param local pamitv object
   * @param displayOfferId
   */
  private createCustomLink(
    array: { Index: number; Type: number; Key: string; Value: string }[],
    localObject: { [key: string]: string },
    displayOfferId: string
  ): string {
    let link = '';

    const baseUrlObj = array.find((item) => item.Key === 'RedirectBaseUrl');
    const baseUrl = baseUrlObj ? baseUrlObj.Value : '';

    if (baseUrl !== '') {
      link = baseUrl;

      for (let i = 1; i < array.length; i++) {
        const { Key, Value } = array[i];
        const val =
          Value === 'DisplayOfferId' ? displayOfferId : localObject[Value];
        if (Value === 'DisplayOfferId') {
          link += `?${Key}=${val}`;
        }
        if (Value != 'DisplayOfferId') {
          link += `&${Key}=${val}`;
        }
      }
    }

    return link;
  }

  ngOnDestroy(): void {
    const formFontFamily = this.el.nativeElement.querySelector(
      '.single-coupon-comp'
    );
    const btns = this.el.nativeElement.querySelector('button');
    this.renderer.removeStyle(this.document.body, 'background-color');
    this.renderer.removeStyle(formFontFamily, 'font-family');
    this.renderer.removeStyle(formFontFamily, 'font-size');
    this.renderer.removeStyle(btns, 'font-family');
  }
}
