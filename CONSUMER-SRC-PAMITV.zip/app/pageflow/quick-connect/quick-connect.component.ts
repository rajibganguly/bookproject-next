import { CommonStoreService } from 'src/app/service/common-store.service';
import {
  Component,
  OnInit,
  Renderer2,
  Inject,
  ElementRef,
  AfterContentInit,
  OnDestroy,
} from '@angular/core';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { RegistrationFormService } from '../../forms/registration-form/registration-form-service';
import { CampaignBrandAttributeFieldType } from '../../models/campaign-brand/campaignBrandAttributeFieldType';
import { DOCUMENT } from '@angular/common';
import { AppService } from '../../service/app.service';
import {
  GlobalContext
} from '../../service/constants.service';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';
import { GoogleAnalyticsService } from 'ngx-google-analytics';


@Component({
  selector: 'app-quick-connect',
  templateUrl: './quick-connect.component.html',
  styleUrls: ['./quick-connect.component.scss'],
})
export class QuickConnectComponent
  implements OnInit, AfterContentInit, OnDestroy
{
  campaignBrandAttributeFieldType: typeof CampaignBrandAttributeFieldType =
    CampaignBrandAttributeFieldType;
  registrationFormHeaderImageUrl: SafeUrl =
    this.sanitizer.bypassSecurityTrustUrl(
      'assets/pamitv_logo_hort_grad_blk.png'
    );
  registrationPageBackgroundColor? = 'white';
  offerAttributeTitle: string = 'An agent will contact you soon';
  offerAttributeButton: string = 'Go to our website';
  would_you_like_to_do: string = 'What would you like to do';
  thankYou: string = 'Thank you';
  editProfile = 'Edit my profile';
  updateProfile = 'Update my profile';
  agentWillContact = 'An agent will contact you soon';
  visitPamitvText: string = 'Visit PamiTv';
  welcomeBack: string = 'Welcome';
  // @ViewChild('formHeaderText') formHeaderText: ElementRef;
  finalQCSection: boolean = false;

  ctaButtonBackgroundColor? = 'white';
  ctaButtonTextColor? = 'black';
  link: string = '';
  offerSimpleRedirect: boolean = false;
  offerSingleUseBasicCoupon: boolean = false;
  offerCaptureThenRedirect: boolean = false;
  offerQuickConnect: boolean = false;

  registrationFormTitleTextColor? = 'black';
  localCookieChkVar: string | null = '';
  registrationPageFont: string = '';
  registrationPageFontName: string = '';
  registrationPageFontSize: string = '16px';
  isReturningGuest: string = '';

  currentUrl: string = '';
  snackBar: boolean = false;
  snackBarMessage: string = '';
  localStorePamiTv: string | null;

  constructor(
    private renderer: Renderer2,
    private sanitizer: DomSanitizer,
    @Inject(DOCUMENT) private document: Document,
    private registrationFormService: RegistrationFormService,
    private appService: AppService,
    private el: ElementRef,
    private cookieService: CookieService,
    private router: Router,
    private commService: CommonStoreService,
    private googleAnalyticsService: GoogleAnalyticsService
  ) {
    const guestName = JSON.parse(
      localStorage.getItem('fullNameAsStored') || ''
    );
    // Initiate cookie value
    if (guestName) {
      this.localCookieChkVar = ` ${guestName}!`;
      this.localStorePamiTv = localStorage.getItem('pamitv');
    } else {
      this.localCookieChkVar = '!';
    }
    /**
     * Deside returningGuest
     */
    this.isReturningGuest = this.cookieService.get('returningGuest');
  }

  ngOnInit() {
    /***
     * Based on CampaignOfferType,
     * Template created on UI
     */
    
    if (
      this.appService.offerTemplate.OfferType ==
      this.appService.CampaignOfferType.SimpleRedirect
    ) {
      this.offerSimpleRedirect = true;
    } else if (
      this.appService.offerTemplate.OfferType ==
      this.appService.CampaignOfferType.SingleUseBasicCoupon
    ) {
      this.offerSingleUseBasicCoupon = true;
    } else if (
      this.appService.offerTemplate.OfferType ==
      this.appService.CampaignOfferType.QuickConnect
    ) {
      this.offerQuickConnect = true;
    } else {
      this.offerCaptureThenRedirect = true;
    }

    // Attribute value assigned
    const offerAttributes = this.commService.brandAttributes;
    offerAttributes.forEach((each: {Key: number, Value: string}, index: number) => {
      switch (each.Key) {
        case this.campaignBrandAttributeFieldType.LandingSubtitle:
          this.offerAttributeTitle = each?.Value;
          break;
        case this.campaignBrandAttributeFieldType.LandingCtaButtonText:
          this.offerAttributeButton = each.Value;
          break;
        case this.campaignBrandAttributeFieldType.LandingCtaButtonUrl:
          this.link = each.Value;
          break;
        case this.campaignBrandAttributeFieldType.UpdateProfileButtonText:
          this.editProfile = each.Value;
          break;
        case this.campaignBrandAttributeFieldType.QuickConnectRequestedFormTitleText:
          this.agentWillContact = each.Value;
          break;
        case this.campaignBrandAttributeFieldType.QuickConnectRequestedFormSubTitleText:
          this.thankYou = each.Value;
          break;
        case this.campaignBrandAttributeFieldType.QuickConnectCtaButtonText:
          this.visitPamitvText = each.Value;
          break;
        case this.campaignBrandAttributeFieldType.ReturningGuestFormTitleText:
          this.welcomeBack = each.Value;
          break;
        default:
          break;
      }
    });

    // Google Analytics code
    this.googleAnalyticsService.pageView('/quickconnect', 'Quick Connect Page')
  }

  /***
   * @description: Image & Styles fetch from CampaignBrandTemplate
   */
  ngAfterContentInit(): void {
    this.registrationPageBackgroundColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationPageBackgroundColor
      );
    const imageUrl =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationHeaderImageUrl
      );
    this.ctaButtonTextColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationCtaTextColor
      );
    this.ctaButtonBackgroundColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationCtaBackgroundColor
      );
    if (imageUrl) {
      this.renderer.setStyle(
        this.document.body,
        'background-color',
        this.registrationPageBackgroundColor
      );
      this.registrationFormHeaderImageUrl =
        this.sanitizer.bypassSecurityTrustUrl(imageUrl);
    }
  }

  /***
   * @description: onclick goForQuickConnect
   */
  goForQuickConnect(): void {
    this.finalQCSection = true;
  }

  /***
   * @description: onclick goToWebsite
   */
  visitListing() {
    if (this.link) {
      window.open(this.link);
    } else {
      this.appService.redirectUser();
    }
  }

  /***
   * @description: onclick goToWebsite
   */
  goToWebsite() {
    const offerParam = this.commService.offerParametersForQuickConnect;
    let isPamiTvAvailable: any;
    if (this.localStorePamiTv) {
      isPamiTvAvailable = JSON.parse(this.localStorePamiTv);
    }
    const displayOfferId = this.commService.displayOfferId;

    const customLink = this.createCustomLink(
      offerParam,
      isPamiTvAvailable,
      displayOfferId
    );

    window.open(customLink, '_blank');
  }

  /**
   * @description If OfferParameters available and values stored in local pamitv cookies
   * @param OfferParameters
   * @param local pamitv object
   * @param displayOfferId
   */
  private createCustomLink(
    array: { Index: number; Type: number; Key: string; Value: string }[],
    localObject: { [key: string]: string },
    displayOfferId: string
  ): string {
    let link = '';

    // Find the RedirectBaseUrl from the Key and get Value else empty
    const baseUrlObj = array.find((item) => item.Key === 'RedirectBaseUrl');
    const baseUrl = baseUrlObj ? baseUrlObj.Value : '';

    if (baseUrl !== '') {
      link = baseUrl;

      // Loop run to create custom link
      for (let i = 1; i < array.length; i++) {
        const { Key, Value } = array[i];
        const val =
          Value === 'DisplayOfferId' ? displayOfferId : localObject[Value];
        if (Value === 'DisplayOfferId') {
          link += `?${Key}=${val}`;
        }
        if (Value != 'DisplayOfferId') {
          link += `&${Key}=${val}`;
        }
      }
    }

    return link;
  }

  /***
   * @description: onclick updateMyProfile
   */
  updateMyProfile() {
    this.router.navigate(['profile']);
  }

  ngOnDestroy(): void {
    const formFontFamily = this.el.nativeElement.querySelector('.qc-comp');
    const btns = this.el.nativeElement.querySelector('button');
    this.renderer.removeStyle(this.document.body, 'background-color');
    this.renderer.removeStyle(formFontFamily, 'font-family');
    this.renderer.removeStyle(formFontFamily, 'font-size');
    this.renderer.removeStyle(btns, 'font-family');
  }
}



