import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CouponService } from './service/coupon.service';
import { ConstantsService } from './service/constants.service';
import { CouponMasterComponent } from './coupons/coupon-master/coupon-master.component';
import { CouponDetailComponent } from './coupons/coupon-detail/coupon-detail.component';
import { CouponQrcodeComponent } from './coupons/coupon-qrcode/coupon-qrcode.component';
import { APP_INITIALIZER } from '@angular/core';
import { AppConfigService } from './service/app-config.service';
import { WalletService } from './service/wallet.service';
import { TermsMasterComponent } from './terms/terms-master/terms-master.component';
import { RegistrationFormMasterComponent } from './forms/registration-form/registration-form-master/registration-form-master.component';
import { RegistrationFormService } from './forms/registration-form/registration-form-service';
import { AppService } from './service/app.service';
import { SharedModule } from './shared/shared.module';
import { QuickConnectService } from './service/quick-connect.service';
import { SingleCouponComponent } from './pageflow/single-coupon/single-coupon.component';
import { QuickConnectComponent } from './pageflow/quick-connect/quick-connect.component';
import { FooterComponent } from './footer/footer.component';
import { EditFormComponent } from './forms/edit-form/edit-form.component';
import { EngageService } from './service/engage.service';
import { CommonStoreService } from './service/common-store.service';
import { GuestService } from './service/guest.service';
import { ErrorPageComponent } from './components/error-page/error-page.component';
import { NgxGoogleAnalyticsModule, NgxGoogleAnalyticsRouterModule } from 'ngx-google-analytics';

import { environment } from 'src/environment';
import { SysErrorPageComponent } from './components/sys-error-page/sys-error-page.component';

@NgModule({
  declarations: [
    AppComponent,
    CouponMasterComponent,
    CouponDetailComponent,
    CouponQrcodeComponent,
    TermsMasterComponent,
    RegistrationFormMasterComponent,
    SingleCouponComponent,
    QuickConnectComponent,
    FooterComponent,
    EditFormComponent,
    ErrorPageComponent,
    SysErrorPageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxGoogleAnalyticsModule.forRoot(environment.GoogleAnalyticsId),
    NgxGoogleAnalyticsRouterModule.forRoot()
  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      multi: true,
      deps: [AppConfigService],
      useFactory: (appConfigService: AppConfigService) => {
        return () => {
          //Make sure to return a promise!
          return appConfigService.loadAppConfig();
        };
      },
    },
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: { appearance: 'outline' },
    },
    AppService,
    CommonStoreService,
    EngageService,
    CouponService,
    ConstantsService,
    GuestService,
    RegistrationFormService,
    QuickConnectService,
    WalletService,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {  
}
