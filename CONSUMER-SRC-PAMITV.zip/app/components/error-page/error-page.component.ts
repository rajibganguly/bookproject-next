import { Component } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { AppConfigService } from './../../service/app-config.service'

@Component({
  selector: 'app-error-page',
  templateUrl: './error-page.component.html',
  styleUrls: ['./error-page.component.scss']
})
export class ErrorPageComponent {
  logoImageUrl: SafeHtml;
  url: string = ''

  constructor(
    private sanitizer: DomSanitizer,
    private cfgSvc: AppConfigService
    ) {
    this.logoImageUrl =
    this.sanitizer.bypassSecurityTrustUrl('assets/pamitv_logo_hort_grad_blk.png')
    this.url = this.cfgSvc.appConfig.pamitvsite;
  }
}
