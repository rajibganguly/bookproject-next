import { Component } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { AppConfigService } from 'src/app/service/app-config.service';

@Component({
  selector: 'app-sys-error-page',
  templateUrl: './sys-error-page.component.html',
  styleUrls: ['./sys-error-page.component.scss']
})
export class SysErrorPageComponent {
  logoImageUrl: SafeHtml;
  url: string = ''

  constructor(
    private sanitizer: DomSanitizer,
    private cfgSvc: AppConfigService
    ) {
    this.logoImageUrl =
    this.sanitizer.bypassSecurityTrustUrl('assets/pamitv_logo_hort_grad_blk.png')
    this.url = this.cfgSvc.appConfig.pamitvsite;
  }
}
