import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegistrationFormMasterComponent } from './forms/registration-form/registration-form-master/registration-form-master.component';
import { CouponMasterComponent } from './coupons/coupon-master/coupon-master.component';
import { SingleCouponComponent } from './pageflow/single-coupon/single-coupon.component';
import { QuickConnectComponent } from './pageflow/quick-connect/quick-connect.component';
import { EditFormComponent } from './forms/edit-form/edit-form.component';
import { ErrorPageComponent } from './components/error-page/error-page.component';
import { SysErrorPageComponent } from './components/sys-error-page/sys-error-page.component';


const routes: Routes = [
  {
    path: 'quickconnectrequest',
    component: QuickConnectComponent
  },
  {
    path: 'singlecoupon',
    component: SingleCouponComponent
  },
  {
    path: 'profile',
    component: EditFormComponent
  },
  {
    path: ':storageGroup/:requestId', component: RegistrationFormMasterComponent,
    children: [{ path: 'coupon', component: CouponMasterComponent }],

  },
  {
    path: 'coupon', component: CouponMasterComponent
  },
  {
    path: 'systemError', component: SysErrorPageComponent, pathMatch: 'full'
  },  
  {
    path: '**', component: ErrorPageComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
