import { Injectable } from '@angular/core';
import { GuestAttributeDataType } from '../models/patron/patronAttributeDataType';

@Injectable({
  providedIn: 'root'
})
export class InputFormatService {
  guestAttributeDataType: typeof GuestAttributeDataType =
  GuestAttributeDataType;

  constructor() { }

  public usesStandarInputFormat(key: GuestAttributeDataType) {
    switch (key) {
      case this.guestAttributeDataType.Bool:
        return false;
      case this.guestAttributeDataType.Dropdown:
        return false;
      case this.guestAttributeDataType.Phone:
        return false;
      case this.guestAttributeDataType.Email:
        return false;
      default:
        return true;
    }
  }

  usesCheckBoxInputFormat(key: GuestAttributeDataType) {
    switch (key) {
      case this.guestAttributeDataType.Bool:
        return true;
      default:
        return false;
    }
  }

  usesDropdownInputFormat(key: GuestAttributeDataType) {
    switch (key) {
      case this.guestAttributeDataType.Dropdown:
        return true;
      default:
        return false;
    }
  }

  usesTelephoneInputFormat(key: GuestAttributeDataType) {
    switch (key) {
      case this.guestAttributeDataType.Phone:
        return true;
      default:
        return false;
    }
  }

  usesEmailInputFormat(key: GuestAttributeDataType) {
    switch (key) {
        case this.guestAttributeDataType.Email:
          return true;
        default:
          return false;
      }
    }

}
