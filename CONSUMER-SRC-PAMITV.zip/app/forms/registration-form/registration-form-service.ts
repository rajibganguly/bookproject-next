import { Injectable } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  ValidatorFn,
  Validators,
} from '@angular/forms';
import { IEngageSchema } from 'src/app/models/pamitv.interface';
import { GuestAttributeFieldType } from 'src/app/models/patron/patronAttributeFieldType';
import { AppService } from 'src/app/service/app.service';
import { CommonStoreService } from 'src/app/service/common-store.service';
import { CampaignOfferType } from 'src/app/service/constants.service';

@Injectable()
export class RegistrationFormService {
  campaignOfferType = CampaignOfferType;
  guestAttributeFieldType = GuestAttributeFieldType;

  constructor(private appService: AppService, private commService: CommonStoreService) {}

  toRegistrationDetailFormGroup(): FormGroup {
    const group: FormGroup = new FormGroup({});
    var formControl = undefined;
    this.commService.guestRegistrationFormAttributes?.forEach((prompt: any) => {
      switch (prompt.GuestAttributeFieldType) {
        case GuestAttributeFieldType.FullName: {
          const fullName =
            this.appService.patron.FirstName.length == 0 &&
            this.appService.patron.LastName.length == 0
              ? ''
              : this.appService.patron.FirstName + ' ' + this.appService.patron.LastName;
          formControl = prompt.Required
            ? new FormControl(fullName, Validators.required)
            : new FormControl(fullName);
          const fieldName = this.patronAttributeFieldName(
            GuestAttributeFieldType.FullName
          );
          group.addControl(prompt.DataFieldName, formControl);
          group.get(fieldName)?.valueChanges.subscribe((newValue) => {
            this.applyFieldChange(fieldName, newValue);
          });
          break;
        }
        case GuestAttributeFieldType.FirstName: {
          formControl = prompt.Required
            ? new FormControl(this.appService.patron.FirstName, Validators.required)
            : new FormControl(this.appService.patron.FirstName);
          const fieldName = this.patronAttributeFieldName(
            GuestAttributeFieldType.FirstName
          );
          group.addControl(prompt.DataFieldName, formControl);
          group.get(fieldName)?.valueChanges.subscribe((newValue) => {
            this.applyFieldChange(fieldName, newValue);
          });
          break;
        }
        case GuestAttributeFieldType.LastName: {
          formControl = prompt.Required
            ? new FormControl(this.appService.patron.LastName, Validators.required)
            : new FormControl(this.appService.patron.LastName);
          const fieldName = this.patronAttributeFieldName(
            GuestAttributeFieldType.LastName
          );
          group.addControl(prompt.DataFieldName, formControl);
          group.get(fieldName)?.valueChanges.subscribe((newValue) => {
            this.applyFieldChange(fieldName, newValue);
          });
          break;
        }
        case GuestAttributeFieldType.Phone: {
          formControl = prompt.Required
            ? new FormControl(this.appService.patron.Phone1, [
                Validators.required,
                this.phoneValidator,
              ])
            : new FormControl(this.appService.patron.Phone1);
          const fieldName = this.patronAttributeFieldName(
            GuestAttributeFieldType.Phone
          );
          group.addControl(prompt.DataFieldName, formControl);
          group.get(fieldName)?.valueChanges.subscribe((newValue) => {
            this.applyFieldChange(fieldName, newValue);
          });
          break;
        }
        case GuestAttributeFieldType.Email: {
          formControl = prompt.Required
            ? new FormControl(this.appService.patron.Email, [Validators.required, Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,}$')])
            : new FormControl(this.appService.patron.Email);
          const fieldName = this.patronAttributeFieldName(
            GuestAttributeFieldType.Email
          );
          group.addControl(prompt.DataFieldName, formControl);
          group.get(fieldName)?.valueChanges.subscribe((newValue) => {
            this.applyFieldChange(fieldName, newValue);
          });
          break;
        }
        case GuestAttributeFieldType.PostalCode: {
          const postalcode = '' //this.appService.patron?.StreetAddress.PostalCode;
          formControl = prompt.Required
            ? new FormControl(postalcode,  [Validators.required, Validators.pattern('[0-9]{5}')])
            : new FormControl(postalcode);
          const fieldName = this.patronAttributeFieldName(
            GuestAttributeFieldType.PostalCode
          );
          group.addControl(prompt.DataFieldName, formControl);
          group.get(fieldName)?.valueChanges.subscribe((newValue) => {
            this.applyFieldChange(fieldName, newValue);
          });
          break;
        }
        case GuestAttributeFieldType.GuestCompany: {
          formControl = prompt.Required
            ? new FormControl('', Validators.required)
            : new FormControl('');
          const fieldName = prompt.DataFieldName;
          group.addControl(prompt.DataFieldName, formControl);
          group.get(fieldName)?.valueChanges.subscribe((newValue) => {
            this.applyFieldChange(fieldName, newValue);
          });
          break;
        }
        default: {
          this.toAdditionalDetailFormGroup()
          break;
        }
      }
    });
    return group;
  }

  toAdditionalDetailFormGroup(): FormGroup {
    const group: FormGroup = new FormGroup({});
    var formControl = undefined;
    this.commService.additionalBrandAttributes?.forEach((prompt: any) => {
      switch (prompt.GuestAttributeFieldType) {
        case GuestAttributeFieldType.Address1: {
          const address1 = '' //this.appService.patron.StreetAddress.Address1
          formControl = prompt.Required
            ? new FormControl(address1, Validators.required)
            : new FormControl(address1);
          const fieldName = this.patronAttributeFieldName(
            GuestAttributeFieldType.Address1
          );
          group.addControl(prompt.DataFieldName, formControl);
          group.get(fieldName)?.valueChanges.subscribe((newValue) => {
            this.applyFieldChange(fieldName, newValue);
          });
          break;
        }
      case GuestAttributeFieldType.City: {
          const city = '' //this.appService.patron.StreetAddress.City
          formControl = prompt.Required
            ? new FormControl(city, Validators.required)
            : new FormControl(city);
          const fieldName = this.patronAttributeFieldName(
            GuestAttributeFieldType.City
          );
          group.addControl(prompt.DataFieldName, formControl);
          group.get(fieldName)?.valueChanges.subscribe((newValue) => {
            this.applyFieldChange(fieldName, newValue);
          });
          break;
        }
      case GuestAttributeFieldType.State: {
          const state = '' //this.appService.patron.StreetAddress.State
          formControl = prompt.Required
            ? new FormControl(state, Validators.required)
            : new FormControl(state);
          const fieldName = this.patronAttributeFieldName(
            GuestAttributeFieldType.City
          );
          group.addControl(prompt.DataFieldName, formControl);
          group.get(fieldName)?.valueChanges.subscribe((newValue) => {
            this.applyFieldChange(fieldName, newValue);
          });
          break;
        }
      case GuestAttributeFieldType.PostalCode: {
          const zipcode = '' //this.appService.patron.StreetAddress.PostalCode
          formControl = prompt.Required
            ? new FormControl(zipcode, [Validators.required, Validators.pattern('[0-9]{5}')])
            : new FormControl(zipcode);
          const fieldName = this.patronAttributeFieldName(
            GuestAttributeFieldType.PostalCode
          );
          group.addControl(prompt.DataFieldName, formControl);
          group.get(fieldName)?.valueChanges.subscribe((newValue) => {
            this.applyFieldChange(fieldName, newValue);
          });
          break;
        }
        default: {
          break;
        }
      }
    });
    return group;
  }

  applyFieldChange(fieldName: string, newValue: string) {
    switch (fieldName) {
      case 'FirstName':
        this.appService.patron.FirstName = newValue;
        break;
      case 'LastName':
        this.appService.patron.LastName = newValue;
        break;
      case 'FullName':
        if(newValue) {
          var splitted = newValue.split(' ', 4);
          if (splitted.length > 0) {
            this.appService.patron.FirstName = splitted[0];
          }
          if (splitted.length > 1) {
            this.appService.patron.LastName = splitted[1];
          }
          if (splitted.length > 2) {
            this.appService.patron.LastName = this.appService.patron.LastName + ' ' + splitted[2];
          }
          if (splitted.length > 3) {
            this.appService.patron.LastName = this.appService.patron.LastName + ' ' + splitted[3];
          }
        }
        break;
      case 'Email':
        this.appService.patron.Email = newValue;
        break;
      case 'Phone':
        this.appService.patron.Phone1 = newValue;
        break;
      default:
        (this.appService.patron as any)[fieldName] = newValue;
        break;
    }
  }

  patronAttributeFieldName(key: number) {
    return this.guestAttributeFieldType[key];
  }

  phoneValidator: ValidatorFn = (
    control: AbstractControl
  ): { [key: string]: any } | null => {
    const value = control.value;
    if (value && !/^\d{10}$/.test(value)) {
      return { invalidPhone: true };
    }
    return null;
  };

  campaignBrandTemplateAttributeValue(key: number) {
    const data: IEngageSchema = this.commService.engageDetailsObject;
    const campaignBrandTemp = {
      Attributes: data.BrandAttributes,
      CampaignBrandTemplateId: data.CampaignBrandTemplateId,
      Description: "Hand Coded",
      Enabled: data.Enabled,
      Name: "Single Use Coupon"
    }

    if (campaignBrandTemp && campaignBrandTemp.Attributes) {
      const attribute = campaignBrandTemp.Attributes.find(
        (x: any) => Object.values(x).includes(key)
      );
      if (attribute) {
        return attribute.Value;
      }
      return 'Campaign Brand Template Attribute Not Found:' + key;
    }
    return undefined;
  }

  async performCallToAction() {
    //const offerTypeKey = this.appService.offerTemplate.OfferType.toString();
    const offerTypeKey = this.commService.engageDetailsObject.CampaignOfferType?.toString()
    switch (offerTypeKey) {
      case this.campaignOfferType.SingleUseBasicCoupon:
        console.log('SingleUseBasicCoupon');
        await this.appService.getCoupon();
        break;
      case this.campaignOfferType.CaptureThenRedirect:
        console.log('CaptureThenRedirect');
        await this.appService.redirectUser();
        break;
      case this.campaignOfferType.QuickConnect:
        console.log('QuickConnect');
        await this.appService.makeQuickConnect();
        break;
    }
  }
}
