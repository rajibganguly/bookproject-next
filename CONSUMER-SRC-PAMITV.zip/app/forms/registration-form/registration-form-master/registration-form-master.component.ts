import {
  Component,
  OnInit,
  Renderer2,
  ViewChild,
  Inject,
  ElementRef,
  OnDestroy,
  AfterViewInit,
  Input,
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { RegistrationFormService } from '../registration-form-service';
import { PromptedAttribute } from 'src/app/models/patron/promptedAttribute';
import { GuestAttributeFieldType } from 'src/app/models/patron/patronAttributeFieldType';
import { TermsMasterComponent } from 'src/app/terms/terms-master/terms-master.component';
import { MatDialog } from '@angular/material/dialog';
import { CampaignBrandAttributeFieldType } from 'src/app/models/campaign-brand/campaignBrandAttributeFieldType';
import { GuestAttributeDataType } from 'src/app/models/patron/patronAttributeDataType';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { AppService } from 'src/app/service/app.service';

//RG
import { DOCUMENT } from '@angular/common';
import { CookieService } from 'ngx-cookie-service';
import { CommonStoreService } from 'src/app/service/common-store.service';
import { PamitvCookiesService } from 'src/app/service/pamitv-cookies.service';
import { GlobalContext } from 'src/app/service/constants.service';
import { InputFormatService } from '../../input-format.service';
import { GuestService } from 'src/app/service/guest.service';
import { Subject, takeUntil } from 'rxjs';
import { IFormRegistrationFields, IGuestRegistrationFormAttributes } from 'src/app/models/pamitv.interface';
import { removedTrailingSpaceFromObj, whenFirstNLastNamesNotExist, whenFullNameNotExist } from 'src/app/utility/utility-functions';
import { GoogleAnalyticsService } from 'ngx-google-analytics';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration-form-master',
  templateUrl: './registration-form-master.component.html',
  styleUrls: ['./registration-form-master.component.scss'],
})
export class RegistrationFormMasterComponent
  implements OnInit, AfterViewInit, OnDestroy
{
  registrationForm!: FormGroup;
  promptedAttributes: PromptedAttribute[] | undefined;
  additionalPromptedAttributes: PromptedAttribute[] | undefined;
  guestAttributeFieldType: typeof GuestAttributeFieldType =
    GuestAttributeFieldType;
  guestAttributeDataType: typeof GuestAttributeDataType =
    GuestAttributeDataType;
  campaignBrandAttributeFieldType: typeof CampaignBrandAttributeFieldType =
    CampaignBrandAttributeFieldType;
  registrationFormHeaderImageUrl: SafeUrl = '';
  ctaButtonText? = 'placeholder';
  ctaButtonTextColor? = 'black';
  ctaButtonBackgroundColor? = 'white';
  registrationFormTitleText? = 'placeholder';
  registrationFormTitleTextColor? = 'black';
  registrationTextColor? = 'black';
  registrationPageBackgroundColor? = 'white';
  registrationPageFont? = '';
  registrationPageFontName? = '';
  registrationPageFontSize? = '16px';
  setRequiredField: any[] = [];

  private style?: HTMLLinkElement;
  localCookieChkVar: string | null = '';
  formValidFlag: boolean = false;
  countValidity: number = 0;
  emailTestFlag: boolean = true;
  emailTestError: string = '';
  nameTestFlag: boolean = true;
  nameTestError: string = '';
  firstnameTestFlag: boolean = true;
  firstnameTestError: string = '';
  lastnameTestFlag: boolean = true;
  lastnameTestError: string = '';
  phoneTestFlag: boolean = true;
  phoneTestError: string = '';
  pageReady: boolean = false;
  @ViewChild('formHeaderText') formHeaderText: ElementRef;
  cookieData: any = '';
  url: string = '';
  userDataStr = localStorage.getItem('pamitv');
  userData: any = {}; // RegistrationForm container
  pamitvCookie: boolean = false; // as default setup
  requiredFieldsInCurrentForm: any = [];
  private destroy$: Subject<void> = new Subject<void>();
  newRegistrationFormObject: any = {};
  errorColor: string = '';
  registrationFormTextColor: string;
  placeholderTextColor: string;

  isAdditionalOptions: boolean = false;
  currentFormGroup: string = ''

  constructor(
    private appService: AppService,
    private registrationFormService: RegistrationFormService,
    private dialog: MatDialog,
    private renderer: Renderer2,
    private sanitizer: DomSanitizer,
    private el: ElementRef,
    @Inject(DOCUMENT) private document: Document,
    private cookieService: CookieService,
    private commService: CommonStoreService,
    private pamitvCookieService: PamitvCookiesService,
    private inputFormatMethod: InputFormatService,
    private guestService: GuestService,
    private googleAnalyticsService: GoogleAnalyticsService,
    private router: Router
  ) {
    // Get cookie
    this.localCookieChkVar = localStorage.getItem('fullNameAsStored');
    this.url = this.cookieService.get('url');
    this.cookieData = this.cookieService.get('cookieCheckName');
  }

  async ngOnInit() {
    this.currentFormGroup = this.commService.dataFieldNameForAdditionalAttribute
    const imageUrl =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationHeaderImageUrl
      );
    if (imageUrl) {
      this.registrationFormHeaderImageUrl = imageUrl;
    } else {
      this.registrationFormHeaderImageUrl =
        this.sanitizer.bypassSecurityTrustUrl(
          'assets/pamitv_logo_hort_grad_blk.png'
        );
    }
    
    this.registrationForm = this.registrationFormService.toRegistrationDetailFormGroup();
    // Add control if required additional attribute
    if(this.currentFormGroup != "") {
      this.registrationForm.addControl(this.currentFormGroup, this.registrationFormService.toAdditionalDetailFormGroup());
    }
    

    

    this.newRegistrationFormObject = this.registrationForm.value;
    this.promptedAttributes = this.commService.guestRegistrationFormAttributes;
    this.additionalPromptedAttributes = this.commService.additionalBrandAttributes;
    this.ctaButtonText =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationCtaButtonText
      );
    this.registrationFormTitleText =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationFormTitleText
      );
    this.registrationTextColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationTextColor
      );
    this.registrationFormTitleTextColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationFormTitleTextColor
      );
    this.ctaButtonTextColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationCtaTextColor
      );
    this.ctaButtonBackgroundColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationCtaBackgroundColor
      );
    this.errorColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.ErrorTextFontColor
      );

    this.registrationFormTextColor = this.ifAvailableColorNotFound(
      this.campaignBrandAttributeFieldType.RegistrationFormTextColor,
      'black'
    );
    this.placeholderTextColor = this.ifAvailableColorNotFound(
      this.campaignBrandAttributeFieldType.PlaceholderTextColor,
      '#666'
    );

    this.registrationPageBackgroundColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationPageBackgroundColor
      );
    this.registrationPageFont =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationPageFont
      );
    this.registrationPageFontName =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationFontName
      );
    this.registrationPageFontSize =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationFontSize
      );

    this.pageReady = true; // loader
    //const activeOffer = this.appService.offerTemplate.Active; //offer
    const activeOffer = this.commService.engageDetailsObject.Active;

    /***
     * Set Required field
     * send to service for check
     * Also form will check and active submit button
     */
    this.promptedAttributes?.filter((f) => {
      if (f.Required === true) {
        this.requiredFieldsInCurrentForm.push(f.DataFieldName);
      }
    });
    console.info('Available form fields >>', this.promptedAttributes.length);
    console.info('Required Formfields=', this.requiredFieldsInCurrentForm);

    /***
     * Fetch cookies data
     * Update FormData from cookies data
     * Set returningGuest cookies if (Telephone & Email filled)
     */

    /***
     * @description: Return pamitv true/false
     */

    this.pamitvCookie = this.pamitvCookieService.pamiTvExistingUserData(
      this.newRegistrationFormObject, //this.registrationForm.value,
      this.requiredFieldsInCurrentForm
    );

    /***
     * @description: Set required field
     */
    this.setRequiredField = this.pamitvCookieService.requiredDatafieldMap(
      this.requiredFieldsInCurrentForm
    );

    if (this.userDataStr) {
      this.userData = JSON.parse(this.userDataStr);
      const updateValue = this.pamitvCookieService.bindCookiesDataIntoForm(
        this.newRegistrationFormObject, //this.registrationForm.value,
        this.userData
      );

      this.registrationForm.setValue(updateValue);
      this.emailTestFlag = this.phoneTestFlag = false; // Set flag for required flag

      // Logic if filled all mendatory data
      console.log('pamitvCookie returns', this.pamitvCookie);
      //Redirection based on pamitv cookie
      if (this.pamitvCookie) {
        // Validate form
        this.validateFormFunc();
        this.cookieService.set('returningGuest', 'true');
        this.appService.patron.Phone1 = this.userData.Phone;
        this.pageReady = false;
        this.registrationFormService.performCallToAction();
      }
    } else {
      // If no 'pamitv' in localStorage
      this.cookieService.set('returningGuest', 'false');
    }
    
    this.newRegistrationFormObject = this.registrationForm.value;

    // Google Analytics code
    this.googleAnalyticsService.pageView('/', 'Registration Page')
    
  }


  

  ngAfterViewInit(): void {
    this.renderer.setStyle(
      this.document.body,
      'background-color',
      this.registrationPageBackgroundColor
    );

    // Dynamic Font-size setup
    const formFontSize = this.el.nativeElement.querySelector('.clform');
    this.renderer.setStyle(
      formFontSize,
      'font-size',
      this.registrationPageFontSize
    );

    // Dynamic font size set for Form Header Text
    const formFont = this.el.nativeElement.querySelector('#formHeaderText');
    this.renderer.setStyle(formFont, 'font-size', '20px');

    const link = this.registrationPageFont;
    if (link) {
      const btns = this.el.nativeElement.querySelector('button');
      const formFontFamily = this.el.nativeElement.querySelector('.clform');
      this.renderer.setStyle(
        formFontFamily,
        'font-family',
        this.registrationPageFontName
      );
      this.renderer.setStyle(
        btns,
        'font-family',
        this.registrationPageFontName
      );
    }
  }

  /**
   * @description: usesDropdownInputFormat for dropdown
   * @description: usesTelephoneInputFormat for Phone number component
   * @description: usesCheckBoxInputFormat for checkbox
   * @description: usesEmailInputFormat for Email number component
   * @description: usesStandarInputFormat for all type input type
   */

  usesDropdownInputFormat(key: GuestAttributeDataType) {
    return this.inputFormatMethod.usesDropdownInputFormat(key);
  }
  usesTelephoneInputFormat(key: GuestAttributeDataType) {
    return this.inputFormatMethod.usesTelephoneInputFormat(key);
  }
  usesCheckBoxInputFormat(key: GuestAttributeDataType) {
    return this.inputFormatMethod.usesCheckBoxInputFormat(key);
  }
  usesEmailInputFormat(key: GuestAttributeDataType) {
    return this.inputFormatMethod.usesEmailInputFormat(key);
  }
  usesStandarInputFormat(key: GuestAttributeDataType) {
    return this.inputFormatMethod.usesStandarInputFormat(key);
  }

  GuestAttributeFieldName(key: number) {
    return this.guestAttributeFieldType[key];
  }

  GuestDataFieldName(name: string) {
    return name;
  }

  
  /**
   * @description: input string validation
   * @input user input i.e. name, pincode
   */
  getOtherStringInput() {
    this.validateFormFunc();
  }

  
  /**
   * @description: Email validation
   * @input email ID user input
   */
  getEmailInput() {
    let emailId: string = '';
    if (this.registrationForm.value.Email)
      emailId = this.registrationForm.value.Email;
    if (this.registrationForm.value.GuestEmail)
      emailId = this.registrationForm.value.GuestEmail;

    const emailTest = this.validateEmail(emailId);
    if (emailTest) {
      this.emailTestFlag = false;
    } else {
      this.emailTestFlag = true;
      this.emailTestError = GlobalContext.email_error_message;
    }
    this.validateFormFunc();
  }

  /**
   * @description: phone Number validation
   * @input phone number
   */
  getPhoneInput() {
    let phoneNumber: string = '';
    if (this.registrationForm.value.Phone)
      phoneNumber = this.registrationForm.value.Phone;
    if (this.registrationForm.value.GuestPhone)
      phoneNumber = this.registrationForm.value.GuestPhone;
    const phoneNumTest = this.validatePhone(phoneNumber);
    if (phoneNumTest) {
      this.phoneTestFlag = false;
    } else {
      this.phoneTestFlag = true;
      this.phoneTestError = GlobalContext.phone_error_message;
    }
    this.validateFormFunc();
  }

  /**
   * @description: Validate form overall
   * @input phone number
   */
  validateFormFunc() {
    if (
      !this.emailTestFlag &&
      !this.phoneTestFlag &&
      this.validateBasedOutOfRequiredField()
    ) {
      this.formValidFlag = true;
    } else {
      this.formValidFlag = false;
    }
  }

  validateBasedOutOfRequiredField() {
    const requiredFld = this.commService.requiredFields();
    const formData = this.registrationForm.value;
    return requiredFld.every(
      (each) => formData[each] !== '' || this.userData[each] !== ''
    );
  }

  /***
   * @description: If color not defined in brandAttributes
   */
  ifAvailableColorNotFound(
    brandAttributeFieldTypeName: number,
    defaultColor: string
  ) {
    let color: any =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        brandAttributeFieldTypeName
      );
    if (color.includes('Not Found')) {
      color = defaultColor;
    }
    return color;
  }

  /***
   * @description: Option only choose when install
   */
  
  chooseOptions(ev: Event, prompObject: IGuestRegistrationFormAttributes) {
    const event = (ev.target as HTMLInputElement).value;
    let noticeValue: string = '';
    prompObject.Options.find((each: any) => {
      if(each.specialValue === event) {
        noticeValue = each.specialValue
      }    
    })
    if(event === noticeValue && prompObject.HasChildEntries) {
      this.isAdditionalOptions = true
    }
    if(event !== noticeValue && prompObject.HasChildEntries) {
      this.isAdditionalOptions = false
    }
  }



  /***
   * @description: onclick callToAction
   */
  async callToAction() {
    this.newRegistrationFormObject = this.registrationForm.value;
    this.pageReady = false;
    localStorage.setItem('editmode', 'false');
    const nameValue: string =
      this.registrationForm.value.FullName ||
      this.registrationForm.value.GuestName;
    if (nameValue) {
      this.cookieService.set('cookieCheckName', 'true');
      localStorage.setItem('fullNameAsStored', JSON.stringify(nameValue));
    } else if (nameValue) {
      this.cookieService.set('cookieCheckName', 'true');
      localStorage.setItem('fullNameAsStored', JSON.stringify(nameValue));
    } else {
      localStorage.setItem('fullNameAsStored', '');
    }

    // Update registration data to newRegistrationData and Storing
    const obj: any = {};
    for (const key in this.newRegistrationFormObject) {
      if (this.registrationForm.value[key])
        obj[key] = this.registrationForm.value[key];
    }
    this.newRegistrationFormObject = this.updateObjWithDefaultValues(obj);
    const trimObj = removedTrailingSpaceFromObj(this.newRegistrationFormObject);
    this.pamitvCookieService.updatePamiTvCookie(trimObj);

    let requestData: any = {};
    requestData['IpAddress'] = this.appService.patron.IpAddress;
    // let pamitvLocalObj: any = {}
    let storedGuestId: string = '';
    // String GuestId and Phone from Local Store
    storedGuestId = this.userData.Phone;
    this.isNewGuest(requestData, storedGuestId);

    // Google Analytics code
    this.googleAnalyticsService.event('Clicked_Call_To_Action', 'Registration_Form', 'Call To Action');
  }

  /***
   * @description as default value email, phone, fullname, firstname, lastname considered
   */
  updateObjWithDefaultValues(obj: any) {
    const { Email, FirstName, FullName, Phone, LastName } = obj;
    const { GuestEmail, GuestFirstName, GuestName, GuestPhone, GuestLastName } =
      obj;

    if (!Email) obj.Email = GuestEmail;
    if (!FirstName) obj.FirstName = GuestFirstName;
    if (!FullName) obj.FullName = GuestName;
    if (!Phone) obj.Phone = GuestPhone;
    if (!LastName) obj.LastName = GuestLastName;

    return obj;
  }

  /***
   * @description: The following method checks whether the guest is new or existing
   * @param requestData from local store
   * @param guestId
   */
  private async isNewGuest(requestData: any, guestId: string) {
    // All edit form field copied to requestData
    Object.keys(this.newRegistrationFormObject).forEach((key) => {
      requestData[key] = this.newRegistrationFormObject[key];
    });
    requestData = removedTrailingSpaceFromObj(requestData);

    const requestDataGuestID =
      this.newRegistrationFormObject.Phone ||
      this.newRegistrationFormObject.GuestPhone;

    // To check whether guest available or not
    await this.guestService
      .getGuestData(requestDataGuestID)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (data: any) => {
          data = removedTrailingSpaceFromObj(data);
          const userPhoneNum = data.Phone ? data.Phone : data.GuestPhone;
          this.guestRegistrationOrUpdate(requestData, userPhoneNum);
          this.pamitvCookieService.updatePamiTvCookie(data);
        },
        (error) => {
          if(error.status == 500) {
            // If not found GuestData and only case of 500
            this.router.navigate(['systemError'])
          } else {
            this.guestRegistrationOrUpdate(requestData, guestId);
          }
        }
      );
  }

  /***
   * @description: Following method deside if POST or PATCH
   * @param requestData from local store
   */
  private guestRegistrationOrUpdate(
    requestData: IFormRegistrationFields,
    guestId: string
  ) {
    // As guestId is our phone number
    requestData['GuestId'] = requestData.Phone || requestData.GuestPhone;
    this.commService.guestId = requestData.GuestId ? requestData.GuestId : '';
    requestData['DeviceInfo'] = this.commService.deviceDetails;
    // Add First Name when registration (If not available)
    requestData = whenFirstNLastNamesNotExist(requestData);
    requestData = whenFullNameNotExist(requestData);

    if (
      this.newRegistrationFormObject.Phone !== guestId ||
      this.newRegistrationFormObject.GuestPhone !== guestId
    ) {
      this.guestService
        .postNewGuestData(requestData)
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          async (data: any) => {
            await this.registrationFormService.performCallToAction();
          },
          (error) => {
            console.log(error);
          }
        );
    } else {
      this.guestService
        .updateGuestData(requestData)
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          async (data: any) => {
            await this.registrationFormService.performCallToAction();
          },
          (error) => {
            console.log(error);
          }
        );
    }
  }

  /**
   * @private: Function for callToAction validate   *
   * @description: Validation function for Email And Phone Number
   */
  private validateEmail(email: string): boolean | void {
    if (email.includes('@') && !email.includes(' ')) {
      if (email.match('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,}$')) {
        return true;
      }
    }
  }
  private validatePhone(phone: string): boolean | void {
    if (phone.length == 10 && Number(phone.charAt(0)) > 1) {
      let arr = phone.split('');
      for (let i = 0; i < arr.length; i++) {
        let number = Number(arr[i]);
        if (isNaN(number)) {
          return false;
        }
      }
      return true;
    }
  }

  /**
   * @description: Terms & Conditions
   */
  displayTerms() {
    const dialogRef = this.dialog.open(TermsMasterComponent);
    dialogRef.afterClosed().subscribe((result) => {});

    // Google Analytics code
    this.googleAnalyticsService.event('Clicked_Terms_Of_Use', 'Registration_Form', 'Terms of Use');
  }

  /**
   * @description: On destroy activities will be remove
   */
  ngOnDestroy() {
    const formFontFamily = this.el.nativeElement.querySelector('.clform');
    const btns = this.el.nativeElement.querySelector('button');
    this.renderer.removeStyle(this.document.body, 'background-color');
    this.renderer.removeStyle(formFontFamily, 'font-family');
    this.renderer.removeStyle(formFontFamily, 'font-size');
    this.renderer.removeStyle(btns, 'font-family');

    this.destroy$.next();
    this.destroy$.complete();
  }
}


