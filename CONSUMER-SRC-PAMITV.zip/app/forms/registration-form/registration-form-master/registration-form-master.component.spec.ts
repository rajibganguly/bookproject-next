import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationFormMasterComponent } from './registration-form-master.component';

describe('RegistrationFormMasterComponent', () => {
  let component: RegistrationFormMasterComponent;
  let fixture: ComponentFixture<RegistrationFormMasterComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RegistrationFormMasterComponent]
    });
    fixture = TestBed.createComponent(RegistrationFormMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
