import {
  Component,
  OnInit,
  Renderer2,
  ViewChild,
  Inject,
  ElementRef,
  OnDestroy,
  AfterViewInit,
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { RegistrationFormService } from '../registration-form/registration-form-service';
import { PromptedAttribute } from 'src/app/models/patron/promptedAttribute';
import { GuestAttributeFieldType } from 'src/app/models/patron/patronAttributeFieldType';
import { TermsMasterComponent } from 'src/app/terms/terms-master/terms-master.component';
import { MatDialog } from '@angular/material/dialog';
import { CampaignBrandAttributeFieldType } from 'src/app/models/campaign-brand/campaignBrandAttributeFieldType';
import { GuestAttributeDataType } from 'src/app/models/patron/patronAttributeDataType';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { AppService } from 'src/app/service/app.service';

//RG
import { DOCUMENT } from '@angular/common';
import { CookieService } from 'ngx-cookie-service';
import { PamitvCookiesService } from 'src/app/service/pamitv-cookies.service';
import { GlobalContext } from 'src/app/service/constants.service';
import { InputFormatService } from '../input-format.service';
import { GuestService } from 'src/app/service/guest.service';
import { CommonStoreService } from 'src/app/service/common-store.service';
import { removedTrailingSpaceFromObj, whenFirstNLastNamesNotExist, whenFullNameNotExist } from 'src/app/utility/utility-functions';
import { GoogleAnalyticsService } from 'ngx-google-analytics';

@Component({
  selector: 'app-edit-form',
  templateUrl: './edit-form.component.html',
  styleUrls: ['./edit-form.component.scss']
})
export class EditFormComponent
implements OnInit, AfterViewInit, OnDestroy
{
  editForm!: FormGroup;
  promptedAttributes: PromptedAttribute[] | undefined;
  guestAttributeFieldType: typeof GuestAttributeFieldType =
  GuestAttributeFieldType;
  guestAttributeDataType: typeof GuestAttributeDataType =
  GuestAttributeDataType;
  campaignBrandAttributeFieldType: typeof CampaignBrandAttributeFieldType =
    CampaignBrandAttributeFieldType;
  editFormHeaderImageUrl: any = '';
  ctaButtonText? = 'placeholder';
  ctaButtonTextColor? = 'black';
  ctaButtonBackgroundColor? = 'white';
  editFormTitleText? = 'placeholder';
  editFormTitleTextColor? = 'black';
  registrationTextColor? = 'black';
  registrationPageBackgroundColor? = 'white';
  registrationPageFont? = '';
  registrationPageFontName? = '';
  registrationPageFontSize? = '16px';
  setRequiredField: any[] = []

  private style?: HTMLLinkElement;
  localCookieChkVar: string | null = '';
  formValidFlag: boolean = false;
  emailTestFlag: boolean = false; //true
  emailTestError: string = '';
  nameTestFlag: boolean = false;
  nameTestError: string = '';
  firstnameTestFlag: boolean = false;
  firstnameTestError: string = '';
  lastnameTestFlag: boolean = false;
  lastnameTestError: string = '';
  phoneTestFlag: boolean = false; //true
  phoneTestError: string = '';
  pageReady: boolean = false;
  @ViewChild('formHeaderText') formHeaderText: ElementRef;
  cookieData: any = '';
  url: string = '';
  userDataStr = localStorage.getItem('pamitv');
  userData: any = {}; // editForm container
  pamitvCookie: boolean = false; // as default setup
  requiredFieldsInCurrentForm: any = [];

  errorColor: string = '';
  editFormTextColor: string;
  placeholderTextColor: string;
  currentFormGroup: string = ''

  constructor(
    private appService: AppService,
    private registrationFormService: RegistrationFormService,
    private dialog: MatDialog,
    private renderer: Renderer2,
    private sanitizer: DomSanitizer,
    private el: ElementRef,
    @Inject(DOCUMENT) private document: Document,
    private cookieService: CookieService,
    private pamitvCookieService: PamitvCookiesService,
    private inputFormatMethod: InputFormatService,
    private guestService: GuestService,
    private commService: CommonStoreService,
    private googleAnalyticsService: GoogleAnalyticsService
  ) {
    // Get cookie
    this.localCookieChkVar = localStorage.getItem('fullNameAsStored');
    this.url = this.cookieService.get('url');
    this.cookieData = this.cookieService.get('cookieCheckName');
    this.editFormHeaderImageUrl =
        this.sanitizer.bypassSecurityTrustUrl('assets/pamitv_logo_hort_grad_blk.png')
    if(this.userDataStr) this.userData = JSON.parse(this.userDataStr);
  }

  async ngOnInit() {
    this.editForm =
      this.registrationFormService.toRegistrationDetailFormGroup();
    this.promptedAttributes = this.commService.guestRegistrationFormAttributes;
    this.ctaButtonText =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationCtaButtonText
      );
    this.editFormTitleText =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationFormTitleText
      );
    this.registrationTextColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationTextColor
      );
    this.editFormTitleTextColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationFormTitleTextColor
      );
    this.ctaButtonTextColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationCtaTextColor
      );
    this.ctaButtonBackgroundColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationCtaBackgroundColor
      );
    this.errorColor = this.registrationFormService.campaignBrandTemplateAttributeValue(
      this.campaignBrandAttributeFieldType.ErrorTextFontColor
    );
    // this.editFormTextColor = this.registrationFormService.campaignBrandTemplateAttributeValue(
    //   this.campaignBrandAttributeFieldType.RegistrationFormTextColor
    // );
    this.editFormTextColor = this.ifAvailableColorNotFound(
      this.campaignBrandAttributeFieldType.RegistrationFormTextColor,
      'black'
    );
    this.placeholderTextColor = this.ifAvailableColorNotFound(
      this.campaignBrandAttributeFieldType.PlaceholderTextColor,
      '#666'
    );

    this.registrationPageBackgroundColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationPageBackgroundColor
      );
    this.registrationPageFont =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationPageFont
      );
    this.registrationPageFontName =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationFontName
      );
    this.registrationPageFontSize =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationFontSize
      );

    this.pageReady = true; // loader
    // const activeOffer = this.appService.offerTemplate.Active; //offer

    
    /***
      * Set Required field
      * send to service for check
      * Also form will check and active submit button
      */
    this.promptedAttributes?.filter((f) => {
      if(f.Required === true) {
        this.requiredFieldsInCurrentForm.push(f.DataFieldName)
      }
    })

    this.currentFormGroup = this.commService.dataFieldNameForAdditionalAttribute
    this.editForm.addControl(this.currentFormGroup, this.registrationFormService.toAdditionalDetailFormGroup());

     if (this.userData) {
       const updateValue = this.pamitvCookieService.bindCookiesDataIntoForm(
         this.editForm.value,
         this.userData
       );
       
       this.editForm.setValue(updateValue);
       this.emailTestFlag = this.phoneTestFlag = false; // Set flag for required flag

     } else {
     }

    
  }

  GuestDataFieldName(name: string) {
    return name;
  }


  /***
     * @description: If color not defined in brandAttributes
     */
  ifAvailableColorNotFound(
    brandAttributeFieldTypeName: number,
    defaultColor: string
  ) {
    let color: any =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        brandAttributeFieldTypeName
      );
    if (color.includes('Not Found')) {
      color = defaultColor;
    }
    return color;
  }


  ngAfterViewInit(): void {
    const imageUrl =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationHeaderImageUrl
      );
    this.renderer.setStyle(
      this.document.body,
      'background-color',
      this.registrationPageBackgroundColor
    );
    if (imageUrl) {
      this.editFormHeaderImageUrl =
        this.sanitizer.bypassSecurityTrustUrl(imageUrl);
    }


    // Dynamic Font-size setup
    const formFontSize = this.el.nativeElement.querySelector('.editform');
    this.renderer.setStyle(formFontSize, 'font-size', this.registrationPageFontSize);

    // Dynamic font size set for Form Header Text
    const formFont = this.el.nativeElement.querySelector('#formHeaderText');
    this.renderer.setStyle(formFont, 'font-size', '20px');

    const link = this.registrationPageFont;
    if (link) {
      const btns = this.el.nativeElement.querySelector('button');
      const formFontFamily = this.el.nativeElement.querySelector('.editform');
      this.renderer.setStyle(
        formFontFamily,
        'font-family',
        this.registrationPageFontName
      );
      this.renderer.setStyle(btns, 'font-family', this.registrationPageFontName);
    }


  }



/**
 * @description: usesDropdownInputFormat for dropdown
 * @description: usesTelephoneInputFormat for Phone number component
 * @description: usesCheckBoxInputFormat for checkbox
 * @description: usesEmailInputFormat for Email number component
 * @description: usesStandarInputFormat for all type input type
*/

  usesDropdownInputFormat(key: GuestAttributeDataType) {
    return this.inputFormatMethod.usesDropdownInputFormat(key)
  }
  usesTelephoneInputFormat(key: GuestAttributeDataType) {
    return this.inputFormatMethod.usesTelephoneInputFormat(key)
  }
  usesCheckBoxInputFormat(key: GuestAttributeDataType) {
    return this.inputFormatMethod.usesCheckBoxInputFormat(key)
  }
  usesEmailInputFormat(key: GuestAttributeDataType) {
    return this.inputFormatMethod.usesEmailInputFormat(key)
  }
  usesStandarInputFormat(key: GuestAttributeDataType) {
    return this.inputFormatMethod.usesStandarInputFormat(key)
  }

  GuestAttributeFieldName(key: number) {
    return this.guestAttributeFieldType[key];
  }

  /**
   * @description: input string validation
   * @input user input i.e. name, pincode
   */
  getOtherStringInput(ev: any) {
    console.log(!!this.editForm.value[this.setRequiredField[0]])
    if(ev.target.value == '') {
      this.nameTestFlag = true;
    } else {
      this.nameTestFlag = false;
    }
    this.validateFormFunc();
  }

  /**
   * @description: Email validation
   * @input email ID user input
   */
  getEmailInput() {
    const emailTest = this.validateEmail(this.editForm.value.Email);
    if (emailTest) {
      this.emailTestFlag = false;
    } else {
      this.emailTestFlag = true;
      this.emailTestError = GlobalContext.email_error_message
    }
    this.validateFormFunc();
  }

  /**
   * @description: phone Number validation
   * @input phone number
   */
  getPhoneInput() {
    const phoneNumTest = this.validatePhone(
      this.editForm.value.Phone
    );
    if (phoneNumTest) {
      this.phoneTestFlag = false;
    } else {
      this.phoneTestFlag = true;
      this.phoneTestError = GlobalContext.phone_error_message;
    }
    this.validateFormFunc();
  }

  /**
   * @description: Validate form overall
   * @input phone number
   */
  validateFormFunc() {
    if(!this.emailTestFlag && !this.phoneTestFlag) {
      if(this.editForm.value[this.setRequiredField[0]] !== '') {
        this.formValidFlag = true;
      } else {
        this.formValidFlag = false;
      }
    }
    return this.formValidFlag
  }





  /***
   * @description: onclick callToEditAction
   */
  async callToEditAction() {
    this.pageReady = false;
    localStorage.setItem('editmode', 'false');
    if (this.editForm.value.FullName) {
      this.cookieService.set('cookieCheckName', 'true');
      localStorage.setItem(
        'fullNameAsStored',
        JSON.stringify(this.editForm.value.FullName)
      );
    } else if (this.editForm.value.FirstName) {
      this.cookieService.set('cookieCheckName', 'true');
      localStorage.setItem(
        'fullNameAsStored',
        JSON.stringify(this.editForm.value.FirstName)
      );
    } else {
    }

    // Storing userdata to storage
    const obj: any = {};
    for (const key in this.editForm.value) {
      if (this.editForm.value[key])
        obj[key] = this.editForm.value[key];
    }

    let requestData: any = {}
    requestData["IpAddress"] = this.appService.patron.IpAddress
    let pamitvLocalObj: any = {}
    // String GuestId and Phone1 from Local Store
    if(this.userDataStr) {
      pamitvLocalObj = JSON.parse(this.userDataStr)
      requestData["GuestId"] = pamitvLocalObj.Phone
    }
    
   
    // All edit form field copied to requestData
    Object.keys(this.editForm.value).forEach(key => {
      if(!this.editForm.value.phone) {
        requestData[key] = this.editForm.value[key];
      }
    });

    // Mandatory checks for data value and removing trailing spaces  
      requestData = whenFirstNLastNamesNotExist(requestData);
      requestData = whenFullNameNotExist(requestData)
      requestData = removedTrailingSpaceFromObj(requestData)
      this.pamitvCookieService.updatePamiTvCookie(requestData)
      await this.guestService.updateGuestData(requestData).subscribe((data: any) => {  
        this.registrationFormService.performCallToAction()
      })
  }

  /***
   * @description: onclick goToWebsite
   */
  goToWebsite(): void {
    // Expected code for website visit
    this.appService.redirectUser();
  }


  
  



  /**
   * @private: Function for callToAction validate   *
   * @description: Validation function for Email And Phone Number
   */
  private validateEmail(email: string): boolean | void {
    if (email.includes('@') && !email.includes(' ')) {
      if(email.match('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')) {
        return true;
      }
    }
  }
  private validatePhone(phone: string): boolean | void {
    if (phone.length == 10 && Number(phone.charAt(0)) > 1) {
      let arr = phone.split('');
      for (let i = 0; i < arr.length; i++) {
        let number = Number(arr[i]);
        if (isNaN(number)) {
          return false;
        }
      }
      return true;
    }
  }

  displayTerms() {
    const dialogRef = this.dialog.open(TermsMasterComponent);
    dialogRef.afterClosed().subscribe((result) => {});

    // Google Analytics code
    this.googleAnalyticsService.event('Clicked_Terms_Of_Use', 'Profile page', 'Terms of Use');
  }

  /**
   * @description: On destroy activities will be remove
   */
  ngOnDestroy() {
    const formFontFamily = this.el.nativeElement.querySelector('.editform');
    const btns = this.el.nativeElement.querySelector('button');
    this.renderer.removeStyle(this.document.body, 'background-color');
    this.renderer.removeStyle(formFontFamily, 'font-family');
    this.renderer.removeStyle(formFontFamily, 'font-size');
    this.renderer.removeStyle(btns, 'font-family');
  }
}



