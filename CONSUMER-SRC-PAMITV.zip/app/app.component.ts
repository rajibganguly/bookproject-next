import { Component, OnInit, Renderer2 } from '@angular/core';
import { Location } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { TermsMasterComponent } from './terms/terms-master/terms-master.component';
import {
  BehaviorSubject,
} from 'rxjs';
import { AppService } from './service/app.service';
import { CommonStoreService } from './service/common-store.service';
import { CookieService } from 'ngx-cookie-service';
import { EngageService } from './service/engage.service';
import { detailsAboutDeviceNVersion } from './utility/browser-device';
import { ValidationService } from './service/validation.service';

import { NavigationEnd, Router } from '@angular/router';
import { GoogleAnalyticsService } from 'ngx-google-analytics';
import { environment } from 'src/environment';

declare const gtag: Function;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  storageGroup = '';
  defaultStorageGroup = '00';

  url: string;
  segments: string[];
  appReady = false;
  offerLoaded = new BehaviorSubject<boolean>(false);
  offerLoaded$ = this.offerLoaded.asObservable();
  guestDataTemplateLoaded = false;
  campaignBrandTemplateLoaded = false;

  isErrorScreen: boolean = true;

  constructor(
    private appService: AppService,
    private location: Location,
    private dialog: MatDialog,
    private commService: CommonStoreService,
    private cookieService: CookieService,
    private engageService: EngageService,
    private validationService: ValidationService,
    public router: Router,
    private googleAnalyticsService: GoogleAnalyticsService,
    private renderer: Renderer2
  ) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        gtag('config', environment.GoogleAnalyticsId, { 'page_path': event.urlAfterRedirects });
      }      
    })

  }

  async ngOnInit() { 
    // Google Analytics script for embeded into header
    this.addGoogleAnalyticsScript();
    this.url = this.location.path();
    this.cookieService.set('returningGuest', 'false')
    this.segments = this.url.split('/');
    this.segments.splice(0, 1);
    if (this.segments.length > 0) {
      switch (this.segments.length) {
        case 1:
          this.storageGroup = this.defaultStorageGroup;
          this.appService.requestId = this.segments[0];
          break;
        case 2:
          this.storageGroup = this.segments[0];
          this.appService.requestId = this.segments[1];
          break;
        default:
          this.storageGroup = this.segments[0];
          this.appService.requestId = this.segments[1];
          break;
      }
    } else {
      console.warn('no segments in URL');
      this.appReady = true;
      this.isErrorScreen = false;
    }


    if(this.appService.requestId) {
      this.validationService.GetValidationRequest(this.appService.requestId).subscribe((each: any) => {
        this.appService.requestId = each.RequestId;
        this.appService.validatedRequest = each;
        this.getEngagementRequestDetail(each.DisplayOfferId);
      }, (error) => {
        if(error.status === 500) {
          this.appReady = true;
          this.router.navigate(['systemError'])
        } else {
          this.appReady = true;
          this.isErrorScreen = false;
        }
      })
    }

      

      this.offerLoaded$.subscribe((offerLoaded) => {
        if (offerLoaded) {
          const guestTemplateId =
          this.appService.offer.UserDataCaptureTemplate;
          const template: any = this.commService.engageDetailsObject;
          this.appReady = true;
          this.guestDataTemplateLoaded = true;
          this.appService.guestDataTemplate = {
            Description: "",
            Enabled: template.Enabled,
            GuestDataTemplateId: "",
            Name: "",
            OtherAttributes: null,
            PromptedAttributes: template.GuestRegistrationFormAttributes
          };
          this.appReady  = this.guestDataTemplateLoaded && this.campaignBrandTemplateLoaded;

          this.campaignBrandTemplateLoaded = true;
          this.appService.campaignBrandTemplate = {
            Attributes: template.BrandAttributes,
            CampaignBrandTemplateId: template.CampaignBrandTemplateId,
            Description: "",
            Enabled: template.Enabled,
            Name: ""
          }
          this.appReady  = this.guestDataTemplateLoaded && this.campaignBrandTemplateLoaded;


        }
      });

      
    // Store device details
    this.commService.deviceDetails = detailsAboutDeviceNVersion()

    // Google Analytics code
    this.googleAnalyticsService.pageView('/', 'App Page')
  }

  async getEngagementRequestDetail(displayOfferId: string): Promise<boolean> {
    if (this.appService.validatedRequest) {
         
      await this.engageService.getEngageDetails(displayOfferId).subscribe((data: any) => {
        this.commService.engageDetailsObject = data;
        this.commService.offerId = data.OfferId;
        this.commService.displayOfferId = data.DisplayOfferId;
        this.commService.offerParametersForQuickConnect = data.OfferParameters
        this.commService.guestRegistrationFormAttributes = data.GuestRegistrationFormAttributes
        this.commService.brandAttributes = data.BrandAttributes
        this.commService.activeOffer = data.Active
        this.commService.engageDetailsObject = data;
        this.commService.offerParametersForQuickConnect = data.OfferParameters
        this.appService.patron.IpAddress = data.IpAddress;
        this.offerServiceResponse();
        if(data.GuestRegistrationFormAttributes) {
          // Execute additional values and store in common-store service
          for(let i=0; i<data.GuestRegistrationFormAttributes.length; i++) {
            if(data.GuestRegistrationFormAttributes[i]?.Options) {
              let arr:any = data.GuestRegistrationFormAttributes[i]?.Options;
              if(arr && arr.length > 0) {
                for(let j=0; j<arr.length; j++) {
                  if(arr[j]['Attributes'] && arr[j]['Attributes'].length > 0) {
                    this.commService.dataFieldNameForAdditionalAttribute = arr[j].DataFieldName;
                    let arr2: any = arr[j];
                    arr2['specialValue'] = arr2.Value;
                    this.commService.additionalBrandAttributes = arr2.Attributes;
                  }
                }
              }
            }
          }
        }
      }, (error) => {
        this.appReady = true;
        if(error.status === 500) {
          this.router.navigate(['systemError'])
        } else {
          this.isErrorScreen = false;
          throw new Error("getEngageDetails error:", error);
        }
      })
    }
    return false;
  }

  /***
   * Google Analytics script
   */
  private addGoogleAnalyticsScript() {
    const script = this.renderer.createElement('script');
    const googleAnalyticsId = environment.GoogleAnalyticsId;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${googleAnalyticsId}`;
    script.async = true;
  
    this.renderer.appendChild(document.head, script);
  
    // Create and append the inline script
    const inlineScript = this.renderer.createText(`
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', '${googleAnalyticsId}');
    `);
  
    this.renderer.appendChild(document.head, inlineScript);
  }

  offerServiceResponse() {
    let offerTemplateResp1 = {
      Active: this.commService.activeOffer,
      Attributes: this.commService.guestRegistrationFormAttributes,
      CampaignId: this.commService.engageDetailsObject.CampaignId,
      Description: "",
      Name: "",
      OfferTemplateId: this.commService.engageDetailsObject.OfferTemplateId,
      OfferTemplateParams: {},
      OfferType: this.commService.engageDetailsObject.CampaignOfferType
    }
    this.appService.offerTemplate = offerTemplateResp1;

    const offerResp = {
      Active: this.commService.activeOffer,
      Attributes: this.commService.guestRegistrationFormAttributes,
      CampaignBrandTemplateId: this.commService.engageDetailsObject.CampaignBrandTemplateId,
      CampaignOfferType: this.commService.engageDetailsObject.CampaignOfferType,
      Name: "",
      OfferId: this.commService.engageDetailsObject.OfferId,
      OfferTemplateId: this.commService.engageDetailsObject.OfferTemplateId,
      Params: "",
      RedirectBaseUrl: "",
      UserDataCaptureTemplate: this.commService.engageDetailsObject.UserDataCaptureTemplateId
    }
    
    this.appService.offer = offerResp;
    this.offerLoaded.next(true);
  }

  displayTerms() {
    const dialogRef = this.dialog.open(TermsMasterComponent);
    dialogRef.afterClosed().subscribe((result) => {
    });

    // Google Analytics code
    this.googleAnalyticsService.event('Clicked_Terms_Of_Use', 'App', 'Terms of Use');
  }



}