import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TermsMasterComponent } from './terms-master.component';

describe('TermsMasterComponent', () => {
  let component: TermsMasterComponent;
  let fixture: ComponentFixture<TermsMasterComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TermsMasterComponent]
    });
    fixture = TestBed.createComponent(TermsMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
