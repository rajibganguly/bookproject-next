import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-terms-master',
  templateUrl: './terms-master.component.html',
  styleUrls: ['./terms-master.component.scss']
})
export class TermsMasterComponent {
  constructor() {}



}
