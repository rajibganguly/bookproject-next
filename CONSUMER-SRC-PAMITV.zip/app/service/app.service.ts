import { CommonStoreService } from 'src/app/service/common-store.service';
import { Injectable } from '@angular/core';
import { CampaignBrandTemplate } from '../models/campaign-brand/campaignBrandTemplate';
import { GuestDataTemplate } from '../models/patron/patronDataTemplate';
import { Patron } from '../models/patron/patron';
import { CouponService } from './coupon.service';
import { CampaignOfferType, RequestParamValueType } from './constants.service';
import { Router, ActivatedRoute } from '@angular/router';
import { QuickConnectService } from './quick-connect.service';

@Injectable()
export class AppService {
  couponFound = false;
  showSpinner = false;
  gettingCoupon = false;

  requestId = '';
  validatedRequest: any = undefined;
  displayOffer: any = undefined;
  offerTemplate: any = undefined;
  offer: any = undefined;
  guestDataTemplate: GuestDataTemplate | undefined;
  campaignBrandTemplate: CampaignBrandTemplate | undefined;
  CampaignOfferType = CampaignOfferType;
  RequestParamValueType = RequestParamValueType;

  patron: Patron = {
    GuestId: '',
    FirstName: '',
    LastName: '',
    Phone1: '',
    Email: '',
    StreetAddress: {
      Address1: '',
      Address2: '',
      City: '',
      State: '',
      PostalCode: '',
      Country: '',
    },
    IpAddress: ''
  };

  scanDetail = {
    Phone: '',
    displayOfferId: '',
    OfferId: '',
  };
  constructor(
    private couponService: CouponService,
    private quickConnectService: QuickConnectService,
    private router: Router,
    private route: ActivatedRoute,
    private commService: CommonStoreService
  ) {
  }

  async getCoupon() {
    this.showSpinner = true;
    this.gettingCoupon = true;
    const offerId = this.commService.offerId;
    if (
      this.offerTemplate.OfferType == CampaignOfferType.SingleUseBasicCoupon
    ) {      
      await this.couponService
        .GetSingleUseBasicCoupon(
          offerId,
          this.commService.guestId || this.patron.Phone1
        )
        .subscribe((resp) => {
          this.couponService.currentCoupon = resp;
          console.table('got coupon,', this.couponService.currentCoupon);
          this.couponFound = true;
          this.showSpinner = false;
          this.gettingCoupon = false;
          this.router.navigate(['coupon']);
        });
    }
  }


  async makeQuickConnect() {
    const offerId = this.commService.offerId;
    const displayOfferId = this.commService.displayOfferId;
    const guestId = this.patron.Phone1 ?  this.patron.Phone1 : this.commService.guestId;
    await this.quickConnectService
      .PerformQuickConnect(offerId, guestId, displayOfferId, this.requestId)
      .subscribe((resp) => {
        if (resp.requestId !== '') {
          this.router.navigate(['quickconnectrequest']);
        }
      }),
      (error: any) => {
        console.log('error', error);
      };
  } 

  async savePatronScanDetails() {
    this.scanDetail.Phone = this.patron.Phone1;
    this.scanDetail.displayOfferId = this.commService.displayOfferId;
    this.scanDetail.OfferId = this.commService.offerId;
  }

  async redirectUser() {
    if (this.offerTemplate.OfferType == CampaignOfferType.CaptureThenRedirect) {
      //const targetUrl = this.offer.RedirectBaseUrl;
      let getRedirectionUrl = "";
      this.commService.engageDetailsObject.OfferParameters?.find((redirect: any) => {
        if(redirect.Key == "RedirectBaseUrl") {
          getRedirectionUrl = redirect.Value
        }
      })
      const targetUrl = getRedirectionUrl
      const finalUrl = `${targetUrl}${this.defineRedirectRequestArguments()}`;
      window.location.href = finalUrl;
    }
  }

  defineRedirectRequestArguments() {
    var requestArgs = '';
    let i = 0;
    this.offer.Params = this.commService.offerParametersForQuickConnect;
    this.offer.Params.forEach((redirectParam: any) => {
      if (i == 0) {
        requestArgs = '?';
        i++;
      } else {
        requestArgs = requestArgs + '&';
      }
      switch (redirectParam.Type) {
        case RequestParamValueType.DisplayOfferId:
          requestArgs = requestArgs + redirectParam.Key + '=' + this.requestId;
          break;
        case RequestParamValueType.StaticValue:
          requestArgs =
            requestArgs + redirectParam.Key + '=' + redirectParam.Value;
          break;
        case RequestParamValueType.FirstName:
          requestArgs =
            requestArgs + redirectParam.Key + '=' + this.patron.FirstName;
          break;
        case RequestParamValueType.LastName:
          requestArgs =
            requestArgs + redirectParam.Key + '=' + this.patron.LastName;
          break;
        case RequestParamValueType.Phone:
          requestArgs =
            requestArgs + redirectParam.Key + '=' + this.patron.Phone1;
          break;
          case RequestParamValueType.Email:
            requestArgs =
              requestArgs + redirectParam.Key + '=' + this.patron.Email;
            break;
      }
    });

    return requestArgs;
  }
}
