import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { IEngageSchema } from '../models/pamitv.interface';



@Injectable({
  providedIn: 'root',
})
export class CommonStoreService {
  offerParametersForQuickConnect: any[];
  engageDetailsObject: IEngageSchema;
  brandAttributes: any[];
  additionalBrandAttributes: any[];
  guestRegistrationFormAttributes: any[];
  offerId: string;
  displayOfferId: string;
  activeOffer: boolean;
  deviceDetails: {Device: string, Browser: string};
  guestId: string = "";
  dataFieldNameForAdditionalAttribute: string = ''


  requiredFields() {
    const requiredDataFieldNames: string[] = [];
    this.guestRegistrationFormAttributes.forEach((each: any) => {
      if(each.Required === true) requiredDataFieldNames.push(each.DataFieldName)
    })
    return requiredDataFieldNames;
  }

  
}
