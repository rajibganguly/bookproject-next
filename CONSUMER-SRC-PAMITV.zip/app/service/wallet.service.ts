import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppConfigService } from './app-config.service';

@Injectable()
export class WalletService {

    consumerTextUrl =  this.cfgSvc.appConfig.consumerTextUrl;  
    locatorFuncKey = this.cfgSvc.appConfig.locatorFuncKey;
    currentCoupon : any = undefined;

    constructor(private http: HttpClient, private cfgSvc: AppConfigService) { }

    PostPatronCouponLinkTextRequest(requestData: any) : Observable<any> {    
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
          })
        };
        return this.http.post(this.consumerTextUrl, requestData, httpOptions);
      }
}