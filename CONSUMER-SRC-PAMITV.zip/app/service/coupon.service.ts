import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CampaignOfferType } from './constants.service';
import { Observable } from 'rxjs';
import { AppConfigService } from './app-config.service';

@Injectable()
export class CouponService {
  createCouponUrl = this.cfgSvc.appConfig.createCouponUrl; // 'https://localhost:5007/api/CreateCoupon'; // 'http://localhost:7120/api/CreateCoupon';
  createCouponFuncKey = this.cfgSvc.appConfig.createCouponFuncKey;
  currentCoupon: any = undefined;
  currentPhone = '';

  constructor(private http: HttpClient, private cfgSvc: AppConfigService) {}

  GetSingleUseBasicCoupon(
    offerId: string,
    patronPhone: string
  ): Observable<any> {
    const createCouponRequest = {
      GuestId: patronPhone,
      OfferId: offerId,
      CampaignOfferType: CampaignOfferType.SingleUseBasicCoupon,
    };
    return this.PostCouponRequest(this.createCouponUrl, createCouponRequest);
  }

  PostCouponRequest(url: string, requestData: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.createCouponFuncKey,
        pamitvkey: this.createCouponFuncKey,
      }),
    };
    return this.http.post(url, requestData, httpOptions); //'http://localhost:5000/coupon'
  }
}
