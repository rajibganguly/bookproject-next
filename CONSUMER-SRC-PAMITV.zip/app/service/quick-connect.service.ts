import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppConfigService } from './app-config.service';

@Injectable()
export class QuickConnectService {
  quickConnectUrl = this.cfgSvc.appConfig.quickConnectUrl;
  quickConnectFuncKey = this.cfgSvc.appConfig.quickConnectFuncKey;
  currentCoupon: any = undefined;

  constructor(private http: HttpClient, private cfgSvc: AppConfigService) {}

  PerformQuickConnect(
    offerId: string,
    guestPhone: string,
    displayOfferId: string,
    requestId: string
  ): Observable<any> {
    const quickConnectRequest = {
      GuestId: guestPhone,
      OfferId: offerId,
      DisplayOfferId: displayOfferId,
      RequestId: requestId,
    };
    return this.PostQuickConnectRequest(
      this.quickConnectUrl,
      quickConnectRequest
    );
  }

  PostQuickConnectRequest(url: string, requestData: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.quickConnectFuncKey,
        'pamitvkey': this.quickConnectFuncKey,
      }),
    };
    return this.http.post(url, requestData, httpOptions);
  }
}
