import { Injectable } from '@angular/core';

import { GuestAttributeFieldType } from './../models/patron/patronAttributeFieldType'
import { CookieService } from 'ngx-cookie-service';
import { AvailableFieldsUsedPamiTv } from './constants.service';
import { IDataFieldSchema } from './../models/pamitv.interface'
import { whenFirstLastNamesNotAvailable } from '../utility/utility-functions';

@Injectable({
  providedIn: 'root',
})
export class PamitvCookiesService {
  localPamiTvData = localStorage.getItem('pamitv');
  pamiTvData: IDataFieldSchema;



/**
  * Available parameter
  * DataField pulled from GuestAttributeFieldType
*/

  dataFieldNames: any = AvailableFieldsUsedPamiTv;

  dFNames: any = []
  frameObj: any = {}


  constructor(private cookieService: CookieService) {
    this.frameObj = Object.entries(this.dataFieldNames)
    for(let i=0; i<this.frameObj.length; i++) {
      this.dFNames.push(this.frameObj[i][0])
    }
  }


  /**
   *
   * @param formdata
   * @param arr
   * @returns pamitv true/false based on cookie pamitv data
   */
  pamiTvExistingUserData(formdata: IDataFieldSchema, arr: any[]): boolean {
    if (this.localPamiTvData) {
      this.pamiTvData = JSON.parse(this.localPamiTvData)
    }
    let formsTest = this.requiredDatafieldMap(arr)
    const requiredFieldString = formsTest.join(" && ");
    console.log('True: ', formsTest)
    if (this.pamiTvData) {
      // Condition based on API request
      if(requiredFieldString == "FirstName && LastName && Phone") {
        return this.isMobileEmailFullNameORFirstnameOrLastNameTrue(
          this.pamiTvData.FirstName, this.pamiTvData.LastName, this.pamiTvData.Phone, this.pamiTvData.Email
        );
      }
      if(requiredFieldString == "FullName && Phone" || requiredFieldString == "FullName && Email && Phone") {
        return this.isFullNameMobileNEmailTrue(
          this.pamiTvData.FullName, this.pamiTvData.Phone, this.pamiTvData.Email
        );
      }
      return false
    } else {
      return false;
    }
  }

  /**
   * @description check dataField name with formname and map
   */
  requiredDatafieldMap(arr:any) {
    let newArr: any[] = []
    arr.filter((names: unknown):any => {
      switch (names) {
        case 'GuestEmail':
          newArr.push('Email')
          break;
        case 'GuestPhone':
          newArr.push('Phone')
          break;
        case 'GuestFirstName':
          newArr.push('FirstName')
          break;
        case 'GuestLastName':
          newArr.push('LastName')
          break;
        case 'GuestName':
          newArr.push('FullName')
          break;
        default:
          break;
      }
      return newArr
    })
    return newArr
  }

  /**
   *
   * @param firstname
   * @param lastname
   * @param fullname
   * @param phone
   * @param email
   * @returns
   */
  private isMobileEmailFullNameORFirstnameOrLastNameTrue(
    firstname?: string,
    lastname?: string,
    phone?: string,
    email?: string
  ): boolean {
    if(phone != '' && email != '' && (firstname != '' || lastname != '')) {
      return true
    } else {
      return false
    }
  }

  /**
   *
   * @param phone
   * @param email
   * @returns
   */
  private isFullNameMobileNEmailTrue(
    firstname?: string,
    phone?: string,
    email?: string
  ): boolean {
    if(firstname != '' && phone != '' && email != '' ) {
      return true
    } else {
      return false
    }
  }


  /**
   *
   * @param email, phone, fullname
   * @param firstname || lastname
   * @returns Setting ReturningGuest and update cookie
   */
    returningGuestSet(email: string, phone: string, fullname: string) {
      this.cookieService.set('returningGuest', 'false')
  }


  /**
   *
   * @param form
   * @returns Update cookie
   */
  updatePamiTvCookie(formObj: any) {
    let localObjpamiTv: any;
    if (this.localPamiTvData !== null) {
      localObjpamiTv = JSON.parse(this.localPamiTvData);    
    }

    const mergedObjWithSameKey = {
      ...this.dataFieldNames,
      ...localObjpamiTv,
      ...formObj,
    };

    const mergedObject = whenFirstLastNamesNotAvailable(mergedObjWithSameKey)
    const { GuestId, IpAddress, ...updatedObject } = mergedObject;
    localStorage.setItem('fullNameAsStored', JSON.stringify(mergedObject.FullName))
    localStorage.setItem('pamitv', JSON.stringify(updatedObject));
  }

  /**
   * @param destination
   * @param fromCookieData
   * @returns Bind Cookies data to registration Form
   */
  bindCookiesDataIntoForm(destination: any, fromCookieData: any) {
    let arr = [];
    let localObj: any = {};
    for (const [key, value] of Object.entries(destination)) {
      arr.push(key);
    }

    arr.forEach((each: any) => {
      localObj[each] = fromCookieData[each] ? fromCookieData[each] : '';
    });
    return localObj;
  }
}

