import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppConfigService } from './app-config.service';

@Injectable({
  providedIn: 'root'
})
export class ValidationService {
  validationHostUrl = this.cfgSvc.appConfig.getValidatedRequest;
  getValidatedFuncKey = this.cfgSvc.appConfig.getValidatedRequestToken;
  validationEndPoint = this.cfgSvc.appConfig.getValidateRequestEndPoint;
  validationUrl = `${this.validationHostUrl}${this.validationEndPoint}`
  

  constructor(private http: HttpClient, private cfgSvc: AppConfigService) {}

  /***
   * @description Validation API
   * @param requestId
   */
  GetValidationRequest(requestId: string): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.getValidatedFuncKey,
        'pamitvkey': this.getValidatedFuncKey,
      }),
    };
    
    return this.http.get(`${this.validationUrl}/${requestId}`, httpOptions);
  }
}
