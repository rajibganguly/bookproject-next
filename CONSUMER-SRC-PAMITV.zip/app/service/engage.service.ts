import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppConfigService } from './app-config.service';
import { IEngageSchema } from '../models/pamitv.interface';

@Injectable({
  providedIn: 'root'
})
export class EngageService {
  host = this.cfgSvc.appConfig.hostApi;
  engageApiUrl = `${this.host}${this.cfgSvc.appConfig.engageApiEndPoint}`
  engageApiFuncKey = this.cfgSvc.appConfig.engageApiFuncKey;
  pamitvkey = this.cfgSvc.appConfig.pamitvkey;

  constructor(private http: HttpClient, private cfgSvc: AppConfigService) { }

  /***
   * @description EngageApi
   * @param displayOfferId
   */
  getEngageDetails(displayOfferId: string) {
    const fullUrl = `${this.engageApiUrl}/${displayOfferId}`

    const headers = {
      'Content-Type': 'application/json',
      'x-functions-key': this.engageApiFuncKey,
      'pamitvkey': this.pamitvkey,
    };
    
    return this.http.get(fullUrl, {headers});
  }

}


