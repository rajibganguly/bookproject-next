import { Injectable } from '@angular/core';

/**
 * Constant used throughout application
 */
export const GlobalContext: any = {
  thank_you: 'Thank You',
  what_would_you_like_to_do: 'What would you like to do?',
  add_to_wallet: 'Add to Wallet',
  go_to_our_website: 'Go to our website',
  an_agent_will_contact_you_shortly: 'An agent will contact you shortly!',
  SnackBarMsg: 'New contact request SMS send to mobile number...',
  UpdateProfile: 'Profile is updated now',
  welcomeBack : 'Welcome back',
  phone_error_message: 'Please enter your phone number (e.g., 3035551212)',
  email_error_message: 'Please enter your email (e.g., name@example.com)',
  coupon_not_available: 'Coupon not available'
}

export const AvailableFieldsUsedPamiTv = {
    FirstName: '',
    LastName: '',
    Email: '',
    FullName: '',
    Phone: '',
    PostalCode: '',
    OpenHouseMailingList: '',
    SpecialsSignup: ''
}

export enum CampaignOfferType {
    SimpleRedirect = '1',
    SingleUseBasicCoupon = '2',
    CaptureThenRedirect = '3',
    QuickConnect = '4'
}

export enum RequestParamValueType
{
    DisplayOfferId = 1,
    StaticValue = 2,
    FirstName = 3,
    LastName = 4,
    Phone = 5,
    Email = 6
}

export enum RequestOfferParamValueType
{
  DisplayOfferId = 1,
  offerid = 2,
  FirstName = 3,
  LastName = 4,
  Phone = 5,
  Email = 6
}

@Injectable()
export class ConstantsService {

}

