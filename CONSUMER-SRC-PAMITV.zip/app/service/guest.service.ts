import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppConfigService } from './app-config.service';

@Injectable()
export class GuestService {
    host = this.cfgSvc.appConfig.hostApi;
    getGuestUrl = `${this.host}${this.cfgSvc.appConfig.guestApiEndPoint}`
    pamitvkey = this.cfgSvc.appConfig.pamitvkey;    
    
    constructor(private http: HttpClient, private cfgSvc: AppConfigService) {}

    // To change formValue Names (FirstName, LastName, FullName) in Capitalize
    capitalize_names(obj: Record<string, any>): Record<string, any> {
      for (const key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key) && key.includes('Name')) {
            const name = obj[key]
            const wd: [string] = name.split(" ")
            const capitalWd: any = wd.map((word: string) => word.charAt(0).toUpperCase() + word.slice(1))
            const result: string = capitalWd.join(" ")
            obj[key] = result;
          }
      }
      return obj;
    }

    getGuestData(guestId: string) {
      const url: string = `${this.getGuestUrl}/${guestId}`;
        const headers = {
            'Content-Type': 'application/json',
            'pamitvkey': this.pamitvkey,
          };
          return this.http.get(url, {headers}); 
    }

    postNewGuestData(requestData: any) : Observable<any> {
      const request = this.capitalize_names(requestData)
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'pamitvkey': this.pamitvkey,
          })
        };

        return this.http.post(this.getGuestUrl, request, httpOptions); 
    }

    updateGuestData(requestData: any) : Observable<any> {
      const request = this.capitalize_names(requestData)
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'pamitvkey': this.pamitvkey,
          })
        };
        return this.http.patch(this.getGuestUrl, request, httpOptions); 
    }
}
