import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

// Material Modules add here

import { MaterialExampleModule } from 'src/material.module';


// Third party modules here
import { CookieModule } from 'ngx-cookie';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CookieModule,
    MaterialExampleModule
  ],
  exports: [
    MaterialExampleModule
  ]
})


export class SharedModule { }
