import { Component, OnInit, Renderer2, Inject } from '@angular/core';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { RegistrationFormService } from 'src/app/forms/registration-form/registration-form-service';
import { CampaignBrandAttributeFieldType } from 'src/app/models/campaign-brand/campaignBrandAttributeFieldType';
import { AppService } from 'src/app/service/app.service';
import { GlobalContext } from 'src/app/service/constants.service';
import { CouponService } from 'src/app/service/coupon.service';
import { WalletService } from 'src/app/service/wallet.service';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-coupon-master',
  templateUrl: './coupon-master.component.html',
  styleUrls: ['./coupon-master.component.scss'],
})
export class CouponMasterComponent implements OnInit {
  showSpinner = false;
  couponSent = false;
  ctaButtonTextColor? = 'black';
  ctaButtonBackgroundColor? = 'white';
  campaignBrandAttributeFieldType: typeof CampaignBrandAttributeFieldType =
    CampaignBrandAttributeFieldType;
  couponFormHeaderImageUrl: SafeUrl = '';
  couponUsedOrExpired: boolean = false
  couponUsedTemplate: SafeUrl = '';
  pageBackgroundColor: string = "white";
  pageFontSize: string = '1rem';
  globalContext = GlobalContext



  constructor(
    private couponService: CouponService,
    private walletService: WalletService,
    private sanitizer: DomSanitizer,
    private router: Router,
    private registrationFormService: RegistrationFormService,
    private renderer: Renderer2,
    @Inject(DOCUMENT) private document: Document,
  ) {}

  ngOnInit() {
    this.ctaButtonTextColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationCtaTextColor
      );
    this.ctaButtonBackgroundColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationCtaBackgroundColor
      );
      const imageUrl =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationHeaderImageUrl
      );
    if (imageUrl) {
      this.couponFormHeaderImageUrl =
        this.sanitizer.bypassSecurityTrustUrl(imageUrl);
    }

    this.pageBackgroundColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationPageBackgroundColor
    );

    this.renderer.setStyle(
      this.document.body,
      'background-color',
      this.pageBackgroundColor
      );
    this.renderer.setStyle(
      this.document.body,
      'font-size',
      this.pageFontSize
      );

    /**
     * If coupon used or expired
     */
    this.couponUsedTemplate =
    this.registrationFormService.campaignBrandTemplateAttributeValue(
      this.campaignBrandAttributeFieldType.CouponUsedOrExpiredTemplate
    );
    

    if (
      this.couponService.currentCoupon.RemainingRedemptions == 1 &&
      this.couponService.currentCoupon.Active == true
    ) {
      this.couponUsedOrExpired = true;
    } else {
      this.couponUsedOrExpired = false;
    }
  }

  /***
   * @description: AddToWallet
   */
  async addToWallet() {
    const msgText =
      "Here's the link to your coupon: " +
      this.couponService.currentCoupon.HtmlUrl;
    const textRequest = {
      requestType: 'CouponLink',
      phone: '+1' + this.couponService.currentPhone,
      text: msgText,
    };
    this.showSpinner = true;
    this.walletService
      .PostPatronCouponLinkTextRequest(textRequest)
      .subscribe((resp) => {
        this.showSpinner = false;
        this.couponSent = true;
      });
    this.router.navigate(['singlecoupon']);
  }


  /**
   * @description: On destroy activities will be remove
   */
  ngOnDestroy() {
    this.renderer.removeStyle(this.document.body, 'background-color');
    this.renderer.removeStyle(this.document.body, 'font-size');
  }
}
