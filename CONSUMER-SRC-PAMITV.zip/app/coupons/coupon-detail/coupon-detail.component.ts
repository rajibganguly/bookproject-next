import { Component, OnInit } from '@angular/core';
import { CouponService } from 'src/app/service/coupon.service';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { RegistrationFormService } from 'src/app/forms/registration-form/registration-form-service';
import { AppService } from 'src/app/service/app.service';
import { CampaignBrandAttributeFieldType } from 'src/app/models/campaign-brand/campaignBrandAttributeFieldType';

@Component({
  selector: 'app-coupon-detail',
  templateUrl: './coupon-detail.component.html',
  styleUrls: ['./coupon-detail.component.scss'],
})
export class CouponDetailComponent implements OnInit {
  couponOfferTitle = 'Coupon Offer Title Here';
  couponOfferTitleTextColor? = 'black';
  campaignBrandAttributeFieldType: typeof CampaignBrandAttributeFieldType =
    CampaignBrandAttributeFieldType;

  constructor(
    public couponService: CouponService,
    private sanitizer: DomSanitizer,
    private registrationFormService: RegistrationFormService,
    private appService: AppService
  ) {}

  ngOnInit(): void {
    this.couponOfferTitle =
      this.appService.offerTemplate.OfferTemplateParams.OfferTitle;
      this.couponOfferTitleTextColor =
      this.registrationFormService.campaignBrandTemplateAttributeValue(
        this.campaignBrandAttributeFieldType.RegistrationFormTitleTextColor
      );
  }

  getSafeHtml(html: string): SafeHtml {
    return this.sanitizer.bypassSecurityTrustHtml(html);
  }
}
