import { Component } from '@angular/core';
import { CouponService } from 'src/app/service/coupon.service';

@Component({
  selector: 'app-coupon-qrcode',
  templateUrl: './coupon-qrcode.component.html',
  styleUrls: ['./coupon-qrcode.component.scss']
})
export class CouponQrcodeComponent {
  constructor(public couponService: CouponService) {}

}
