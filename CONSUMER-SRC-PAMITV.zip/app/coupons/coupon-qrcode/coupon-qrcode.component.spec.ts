import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CouponQrcodeComponent } from './coupon-qrcode.component';

describe('CouponQrcodeComponent', () => {
  let component: CouponQrcodeComponent;
  let fixture: ComponentFixture<CouponQrcodeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CouponQrcodeComponent]
    });
    fixture = TestBed.createComponent(CouponQrcodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
