import { PromptedAttribute } from "./promptedAttribute";

export class GuestDataTemplate {
    constructor(
      public Name: string,
      public Description: string,
      public GuestDataTemplateId: string,
      public Enabled: boolean,
      public OtherAttributes: any,
      public PromptedAttributes: PromptedAttribute[],
    ) {}
  }
