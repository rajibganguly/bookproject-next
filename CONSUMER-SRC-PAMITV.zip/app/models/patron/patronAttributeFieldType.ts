export enum GuestAttributeFieldType
{
    FirstName = 1,
    LastName = 2,
    FullName = 3,
    Phone = 4,
    Email = 5,
    Age = 6,
    DateOfBirth = 7,
    Sex = 8,
    Address1 = 9,
    Address2 = 10,
    City = 11,
    State = 12,
    PostalCode = 13,
    Acknowledgement = 14,
    IpAddress = 15,
    Browser = 16,
    DeviceType = 17,
    GuestCompany = 18
}
