export enum GuestAttributeDataType
{
    String = 1,
    Phone = 2,
    Number = 3,
    Date = 4,
    Bool = 5,
    Email = 6,
    Dropdown = 7
}
