import { GuestAttributeFieldType } from './patronAttributeFieldType';
import { GuestAttributeDataType } from './patronAttributeDataType';
import { PromptSelectOption } from './promptSelectOption';

export class PromptedAttribute {
    constructor(
      public DisplayOrder: number,
      public Label: string,
      public Placeholder: string,
      public GuestAttributeFieldType: GuestAttributeFieldType,
      public GuestAttributeDataType: GuestAttributeDataType,
      public DataFieldName: string,
      public Required?: boolean,
      public HasChildEntries?: boolean,
      public Options?: PromptSelectOption[],
      
    ) {}
  }
