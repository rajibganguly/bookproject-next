import { StreetAddress } from "../address/streetAddress";

export class Patron {
    constructor(
      public GuestId: string,
      public FirstName: string,
      public LastName: string,
      public Email: string,
      public Phone1: string,
      public StreetAddress: StreetAddress,
      public IpAddress: string
    ) {}
  }
