export class PromptSelectOption {
  constructor(public Label: string, public Value: string) {}
}
