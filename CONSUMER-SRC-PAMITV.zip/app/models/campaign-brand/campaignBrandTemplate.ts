
import { CampaignBrandAttribute } from './campaignbrandAttribute';

export class CampaignBrandTemplate {
    constructor(
      public Name: string,
      public Description: string,
      public CampaignBrandTemplateId: string,
      public Enabled: boolean,
      public Attributes: CampaignBrandAttribute[],
    ) {}
  }