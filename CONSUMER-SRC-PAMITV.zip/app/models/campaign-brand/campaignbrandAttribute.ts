import { CampaignBrandAttributeFieldType } from './campaignBrandAttributeFieldType';

export class CampaignBrandAttribute {
    constructor(
      public Key: CampaignBrandAttributeFieldType,
      public Value: string,
    ) {}
  }