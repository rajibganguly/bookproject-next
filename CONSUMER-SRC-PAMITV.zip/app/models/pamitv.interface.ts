
/**
 * An interface is a TypeScript artifact, it is not part of ECMAScript.
 * An interface is a way to define a contract on a function with respect to the arguments and their type.
 */
export interface IDataFieldSchema {
  FirstName?: string;
  LastName?: string;
  Email: string;
  FullName?: string;
  Phone: string;
  PostalCode?: string;
}

export interface IFormRegistrationFields {
  GuestId?: string;
  FirstName?: string;
  LastName?: string;
  Email: string;
  FullName?: string;
  Phone: string;
  PostalCode?: string;
  IpAddress?: string;
  DeviceInfo?: any;
  GuestName?: string;
  GuestPhone?: string;
  GuestEmail?: string;
  Address1?: string;
  City?: string;
  State?: string;
}


export interface IEngageSchema {
  CampaignOfferType?: number;
  Active?: boolean;
  Enabled?: boolean;
  GuestMessage?: string;
  DisplayOfferId?: string;
  UserDataCaptureTemplateId?: string;
  CampaignBrandTemplateId?: string;
  RetailDisplayId? : string;
  OfferTemplateId?: string;
  CampaignId?: string;
  OfferId?: string;
  GuestRegistrationFormAttributes?: IGuestRegistrationFormAttributes[]
  BrandAttributes?: any[]
  OfferParameters?: IOfferParameters[]
}

export interface IGuestRegistrationFormAttributes {
  DisplayOrder: number;
  Label: string;
  Placeholder: string;
  GuestAttributeFieldType: number;
  GuestAttributeDataType: number;
  DataFieldName: string;
  Required?: boolean;
  HasChildEntries?: boolean;
  Options?: any
}
export interface IBrandAttributes {
  Key: number;
  Value: string;
}

export interface IOfferParameters {
  Index: number;
  Key: string;
  Type: number;
  Value: string
}

