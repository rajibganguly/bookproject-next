import { IFormRegistrationFields } from '../models/pamitv.interface';

/***
 * @description All utility function
 */
// First and Last name if not available
export function whenFirstNLastNamesNotExist(obj: any): IFormRegistrationFields {
  if(obj['GuestName']) obj['FullName'] = obj['GuestName']
  // If object doesn`t exist FirstName property
  if (!obj.hasOwnProperty('FirstName')) {
    obj['FirstName'] = '';
  }
  // If object doesn`t exist LastName property
  if (!obj.hasOwnProperty('LastName') || obj.hasOwnProperty('LastName') == undefined) {
    obj['LastName'] = '';
  }

  //If object has empty property value
  if ((obj.FirstName === ''  || obj.FirstName === undefined) && (obj.LastName === '' || obj.LastName === undefined)) {
    const [firstName, ...remaining] = obj.FullName.split(' ');
    obj.FirstName = obj.FullName.split(' ')[0]; 
    obj.LastName = obj.FullName.split(' ').splice(1).join(' ') || '';
  }
  return obj;
}

// Full name if not available
export function whenFullNameNotExist(obj: any): IFormRegistrationFields {
  // If object doesn`t exist FirstName property
  if (!obj.hasOwnProperty('FullName')) {
    obj['FullName'] = '';
  }

  if(obj['GuestName']) obj['FullName'] = obj['GuestName']

  // If object has empty property value
  if (obj.FullName === '' || obj.FullName == undefined ) {
    const firstname = obj.FirstName.trim();
    const lastname = obj.LastName.trim();
    obj['FullName'] = `${firstname} ${lastname}`;
  }
  return obj;
}

export function whenFirstLastNamesNotAvailable(obj: any) {
  if (
    obj.FirstName &&
    obj.LastName
    ) {
      obj[
        'FullName'
      ] = `${obj.FirstName} ${obj.LastName}`;
    }
    
    if (obj.FullName !== '') {
      obj.FirstName = obj.FullName.split(' ')[0]; 
      obj.LastName = obj.FullName.split(' ').splice(1).join(' ') || '';
    }
  return obj;
}


export function removedTrailingSpaceFromObj(obj: any) {
  const trimmedObject = Object.fromEntries(
    Object.entries(obj).map(([key, value]) => [key, typeof value === 'string' ? value.trim() : value])
  );
  return trimmedObject;
}


