export const environment = {
  GoogleAnalyticsId: 'G-2J5GFM7JT6',
};
