import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatStepperModule } from '@angular/material/stepper';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AppBannerComponent } from './core/app-banner/app-banner.component';
import { HomeComponent } from './core/home/home.component';
import { AppConfigService } from './core/services/app-config.service';
import { APP_INITIALIZER } from '@angular/core';
import { AuthService } from './core/services/auth.service';
import { HttpClientModule } from '@angular/common/http';
import { NavigationBarComponent } from './core/navigation-bar/navigation-bar.component';
import { RetailersMasterComponent } from './config/retailers/retailers-master/retailers-master.component';
import { AdvertisersMasterComponent } from './config/advertisers/advertisers-master/advertisers-master.component';
import { LandingComponent } from './core/landing/landing.component';
import { RetailersTableComponent } from './config/retailers/retailers-table/retailers-table.component';
import { MatTableModule } from '@angular/material/table';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatTabsModule } from '@angular/material/tabs';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatExpansionModule } from '@angular/material/expansion';
import { RetailerDataService } from './config/services/retailer-data.service';
import { MatSortModule } from '@angular/material/sort';
import { AdvertisersTableComponent } from './config/advertisers/advertisers-table/advertisers-table.component';
import { RetailLocationsTableComponent } from './config/retailers/retail-locations-table/retail-locations-table.component';
import { RetailDisplaysTableComponent } from './config/retailers/retail-displays-table/retail-displays-table.component';
import { CampaignsMasterComponent } from './config/campaigns/campaigns-master/campaigns-master.component';
import { AdvertiserDataService } from './config/services/advertiser-data.service';
import { CampaignsTableComponent } from './config/campaigns/campaigns-table/campaigns-table.component';
import { CampaignDataService } from './config/services/campaign-data.service';
import { AdAgencyDataService } from './config/services/adAgency-data.service';
import { CampaignOfferTemplatesComponent } from './config/campaigns/campaign-offer-templates/campaign-offer-templates.component';
import { OfferDataService } from './config/services/offer-data.service';
import { CampaignOffersTableComponent } from './config/campaigns/campaign-offers-table/campaign-offers-table.component';
import { DisplayOfferDataService } from './config/services/displayOffer-data.service';
import { BlobService } from './core/services/blob.service';
import { RetailDisplayOffersTableComponent } from './config/retailers/retail-display-offers-table/retail-display-offers-table.component';
import { RetailAvailableOffersTableComponent } from './config/retailers/retail-available-offers-table/retail-available-offers-table.component';
import { RetailerWizardComponent } from './config/retailers/retailer-wizard/retailer-wizard.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RetailersService } from './config/retailers/retailers.service';
import { CampaignWizardComponent } from './config/campaigns/campaign-wizard/campaign-wizard.component';
import { CampaignsService } from './config/campaigns/campaigns.service';
import { ConfirmationDialogComponent } from './core/confirmation-dialog/confirmation-dialog.component';
import { ApplyOfferConfirmationDialogComponent } from './config/retailers/apply-offer-confirmation-dialog/apply-offer-confirmation-dialog.component';
import { RetailDisplayOfferDetailComponent } from './config/retailers/retail-display-offer-detail/retail-display-offer-detail.component';
import { RetailLocationAddDialogComponent } from './config/retailers/retail-location-add-dialog/retail-location-add-dialog.component';
import { RetailLocationDetailComponent } from './config/retailers/retail-location-detail/retail-location-detail.component';
import { LoginComponent } from './core/login/login.component';
import { AdvertisersService } from './config/advertisers/advertisers.service';
import { AdvertisersWizardComponent } from './config/advertisers/advertisers-wizard/advertisers-wizard.component';
import { VideosMasterComponent } from './config/videos/videos-master/videos-master.component';
import { VideoDataService } from './config/services/video-data.service';
import { VideosTabbedMasterComponent } from './config/videos/videos-tabbed-master/videos-tabbed-master.component';
import { VideosInputTableComponent } from './config/videos/videos-input-table/videos-input-table.component';
import { VideosOutputTableComponent } from './config/videos/videos-output-table/videos-output-table.component';
import { VideoDetailDialogComponent } from './config/videos/video-detail-dialog/video-detail-dialog.component';
import { TemplatesDataService } from './config/services/templates-data.service';
import { VideosOverlayTemplatesTableComponent } from './config/videos/videos-overlay-templates-table/videos-overlay-templates-table.component';
import { ApplyOffersToVideoDialogComponent } from './config/retailers/apply-offers-to-video-dialog/apply-offers-to-video-dialog.component';
import { AuthGuard } from './core/services/auth-guard.service';
import { VideosUploadWizardComponent } from './config/videos/videos-upload-wizard/videos-upload-wizard.component';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { ErrorSnackbarComponent } from './config/retailers/error-snackbar/error-snackbar.component';
import { CampaignTabbedMasterComponent } from './config/campaigns/campaign-tabbed-master/campaign-tabbed-master.component';
import { MatCardModule } from '@angular/material/card';
import { MatTooltipModule } from '@angular/material/tooltip';
import { CampaignBrandTemplateComponent } from './config/campaigns/campaign-brand-template/campaign-brand-template.component';
import { ActionCompletedDialogComponent } from './core/action-completed-dialog/action-completed-dialog.component';
import { GuestInfoTemplateMasterComponent } from './config/guest-info-template/guest-info-template-master/guest-info-template-master.component';
import { GuestInfoTemplatesTableComponent } from './config/guest-info-template/guest-info-templates-table/guest-info-templates-table.component';
import { GuestInfoTemplateDetailsComponent } from './config/guest-info-template/guest-info-template-details/guest-info-template-details.component';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { CampaignOfferDetailComponent } from './config/campaigns/campaign-offer-detail/campaign-offer-detail.component';
import { PhoneNumberFormatPipe } from './core/phone-number-format.pipe';

@NgModule({
  declarations: [
    AppComponent,
    AppBannerComponent,
    HomeComponent,
    NavigationBarComponent,
    RetailersMasterComponent,
    AdvertisersMasterComponent,
    LandingComponent,
    RetailersTableComponent,
    AdvertisersTableComponent,
    RetailLocationsTableComponent,
    RetailDisplaysTableComponent,
    CampaignsMasterComponent,
    CampaignsTableComponent,
    CampaignOfferTemplatesComponent,
    CampaignOffersTableComponent,
    RetailDisplayOffersTableComponent,
    RetailAvailableOffersTableComponent,
    RetailerWizardComponent,
    CampaignWizardComponent,
    ConfirmationDialogComponent,
    ApplyOfferConfirmationDialogComponent,
    RetailDisplayOfferDetailComponent,
    RetailLocationAddDialogComponent,
    RetailLocationDetailComponent,
    LoginComponent,
    AdvertisersWizardComponent,
    VideosMasterComponent,
    VideosTabbedMasterComponent,
    VideosInputTableComponent,
    VideosOutputTableComponent,
    VideoDetailDialogComponent,
    VideosOverlayTemplatesTableComponent,
    ApplyOffersToVideoDialogComponent,
    VideosUploadWizardComponent,
    ErrorSnackbarComponent,
    CampaignTabbedMasterComponent,
    CampaignOfferDetailComponent,
    CampaignBrandTemplateComponent,
    ActionCompletedDialogComponent,
    GuestInfoTemplateMasterComponent,
    GuestInfoTemplatesTableComponent,
    GuestInfoTemplateDetailsComponent,
    PhoneNumberFormatPipe
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatCheckboxModule,
    MatDialogModule,
    MatGridListModule,
    MatSlideToggleModule,
    MatStepperModule,
    MatIconModule,
    MatInputModule,
    MatButtonModule,
    MatMenuModule,
    MatSortModule,
    MatSelectModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatTableModule,
    MatToolbarModule,
    MatTabsModule,
    MatListModule,
    MatExpansionModule,
    MatProgressBarModule,
    MatCardModule,
    MatTooltipModule,
    MatFormFieldModule,
    MatAutocompleteModule
  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      multi: true,
      deps: [AppConfigService],
      useFactory: (appConfigService: AppConfigService) => {
        return () => {
          return appConfigService.loadAppConfig();
        };
      }
    },
    AuthGuard,
    AdAgencyDataService,
    AuthService,
    AdvertiserDataService,
    AdvertisersService,
    BlobService,
    CampaignDataService,
    CampaignsService,
    DisplayOfferDataService,
    OfferDataService,
    RetailerDataService,
    RetailersService,
    TemplatesDataService,
    VideoDataService,
    PhoneNumberFormatPipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
