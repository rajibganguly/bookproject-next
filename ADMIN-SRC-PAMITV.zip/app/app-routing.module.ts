import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './core/home/home.component';
import { RetailersMasterComponent } from './config/retailers/retailers-master/retailers-master.component';
import { AdvertisersMasterComponent } from './config/advertisers/advertisers-master/advertisers-master.component';
import { LandingComponent } from './core/landing/landing.component';
import { CampaignsMasterComponent } from './config/campaigns/campaigns-master/campaigns-master.component';
import { RetailerWizardComponent } from './config/retailers/retailer-wizard/retailer-wizard.component';
import { CampaignWizardComponent } from './config/campaigns/campaign-wizard/campaign-wizard.component';
import { AdvertisersWizardComponent } from './config/advertisers/advertisers-wizard/advertisers-wizard.component';
import { AdvertisersTableComponent } from './config/advertisers/advertisers-table/advertisers-table.component';
import { VideosMasterComponent } from './config/videos/videos-master/videos-master.component';
import { AuthGuard } from './core/services/auth-guard.service';
import { GuestInfoTemplateMasterComponent } from './config/guest-info-template/guest-info-template-master/guest-info-template-master.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    children: [
      { path: '', component: LandingComponent },
      { path: 'Home', component: LandingComponent },
      {
        path: 'Retailers',
        component: RetailersMasterComponent,
        children: [{ path: 'Wizard', component: RetailerWizardComponent }],
        canActivate: [AuthGuard]
      },
      {
        path: 'Campaigns',
        component: CampaignsMasterComponent,
        children: [{ path: 'Wizard', component: CampaignWizardComponent }],
        canActivate: [AuthGuard]
      },
      {
        path: 'Advertisers',
        component: AdvertisersMasterComponent,
        children: [
          { path: '', component: AdvertisersTableComponent },
          { path: 'Wizard', component: AdvertisersWizardComponent }
        ],
        canActivate: [AuthGuard]
      },
      {
        path: 'Videos',
        component: VideosMasterComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'GuestTemplates',
        component: GuestInfoTemplateMasterComponent,
        canActivate: [AuthGuard]
      }
    ]
  },
  {
    path: 'Home',
    component: LandingComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      anchorScrolling: 'enabled',
      scrollPositionRestoration: 'enabled'
    })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
