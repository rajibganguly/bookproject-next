import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AppConfigService } from './app-config.service';

@Injectable()
export class AuthService {
  navTitle = 'Home';
  currentUser = {
    Name: '',
    Email: '',
    Admin: false
  };
  pswSuffix = this.cfgSvc.appConfig.pswSuffix;

  loggedIn = false;
  authorized = false;

  constructor(
    private http: HttpClient,
    private cfgSvc: AppConfigService
  ) {}

  isLoggedIn(): boolean {
    return this.loggedIn;
  }

  isAuthorized(): boolean {
    return this.authorized;
  }

  login(userId: string, psw: string): boolean {
    const i = userId.toUpperCase().indexOf('@PAMITV.COM');
    let loggedIn = true;
    if (i < 0) {
      loggedIn = false;
    }
    if (psw !== this.theCurrentPsw()) {
      loggedIn = false;
    }
    if (!loggedIn) {
      alert('Login failed.');
    }
    if (loggedIn) {
      this.loggedIn = true;
      this.authorized = true;
      this.currentUser.Email = userId;
    } else {
      this.loggedIn = false;
      this.authorized = false;
    }
    return loggedIn;
  }

  theCurrentPsw(): string {
    const date = new Date();
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
    const day = String(date.getDate()).padStart(2, '0');
    const year = String(date.getFullYear());

    return `${month}${day}${year}${this.pswSuffix}`;
  }
}
