import { AnonymousCredential, BlobServiceClient } from '@azure/storage-blob';

import { Injectable } from '@angular/core';

@Injectable()
export class BlobService {
  constructor() {}

  async GetJsonBlob(
    storageAcctUrl: string,
    storageAcctToken: string,
    containerName: string,
    blobName: string
  ) {
    try {
      const anonymousCredential = new AnonymousCredential();
      const blobServiceClient = new BlobServiceClient(
        storageAcctUrl + storageAcctToken,
        anonymousCredential
      );
      const containerClient =
        blobServiceClient.getContainerClient(containerName);
      const blobClient = containerClient.getBlobClient(blobName);
      const response = await blobClient.download();
      const blobBody = (await response.blobBody) as Blob;
      const contentString = await this.readBlobAsString(blobBody);
      const jsonObject = JSON.parse(contentString);
      return jsonObject;
    } catch (error) {
      console.error('GetJsonBlob:', error);
    }
    return undefined;
  }

  readBlobAsString(blob: Blob): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const contentString = reader.result as string;
        resolve(contentString);
      };
      reader.onerror = reject;
      reader.readAsText(blob);
    });
  }

  async SaveJsonBlob(
    storageAcctUrl: string,
    storageAcctToken: string,
    containerName: string,
    blobName: string,
    blobData: any
  ) {
    try {
      const anonymousCredential = new AnonymousCredential();
      const blobServiceClient = new BlobServiceClient(
        storageAcctUrl + storageAcctToken,
        anonymousCredential
      );
      const containerClient =
        blobServiceClient.getContainerClient(containerName);
      const containerExists = await containerClient.exists();
      if (!containerExists) {
        const createdContainer = await blobServiceClient.createContainer(
          containerName
        );
      }
      const blobClient = containerClient.getBlockBlobClient(blobName);
      const blobexists = await blobClient.exists();
      if (!blobexists) {
        const blobStringData = JSON.stringify(blobData);
        const stringBlob = new Blob([blobStringData], { type: 'text/plain' });
        const response = await blobClient.uploadData(stringBlob);
      }
      return blobClient.url;
    } catch (error) {
      console.error('SaveJsonBlob:', error);
    }
    return undefined;
  }

  getFormattedUTCTime(): string {
    const currentDate = new Date();
    const year = currentDate.getUTCFullYear();
    const month = this.padZero(currentDate.getUTCMonth() + 1);
    const day = this.padZero(currentDate.getUTCDate());
    const hours = this.padZero(currentDate.getUTCHours());
    const minutes = this.padZero(currentDate.getUTCMinutes());
    const seconds = this.padZero(currentDate.getUTCSeconds());
    const milliseconds = this.padZero(currentDate.getUTCMilliseconds(), 3);

    return `${year}${month}${day}${hours}${minutes}${seconds}${milliseconds}Z`;
  }

  padZero(value: number, length = 2): string {
    return value.toString().padStart(length, '0');
  }
}
