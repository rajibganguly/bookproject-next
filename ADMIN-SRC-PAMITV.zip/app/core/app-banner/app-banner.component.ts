import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-app-banner',
  templateUrl: './app-banner.component.html',
  styleUrls: ['./app-banner.component.scss'],
})
export class AppBannerComponent {
  constructor(public authService: AuthService, private router: Router,) {}

  navHome() {
    this.router.navigate(['']);
  }
}
