import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-navigation-bar',
  templateUrl: './navigation-bar.component.html',
  styleUrls: ['./navigation-bar.component.scss']
})
export class NavigationBarComponent {
  constructor(
    private router: Router,
    public authService: AuthService
  ) {}

  go(target: string, value: string) {
    console.log('navigate to:' + target);
    this.authService.navTitle = value;
    this.router.navigate([target]);
  }
}
