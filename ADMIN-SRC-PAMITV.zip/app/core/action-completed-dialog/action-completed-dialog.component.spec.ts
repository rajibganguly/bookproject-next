import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActionCompletedDialogComponent } from './action-completed-dialog.component';

describe('ActionCompletedDialogComponent', () => {
  let component: ActionCompletedDialogComponent;
  let fixture: ComponentFixture<ActionCompletedDialogComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ActionCompletedDialogComponent]
    });
    fixture = TestBed.createComponent(ActionCompletedDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
