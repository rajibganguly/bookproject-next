import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-action-completed-dialog',
  templateUrl: './action-completed-dialog.component.html',
  styleUrls: ['./action-completed-dialog.component.scss']
})
export class ActionCompletedDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<ActionCompletedDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { name: string; buttonText: string }
  ) {}
  onOkClick(): void {
    this.dialogRef.close('stay');
  }
  onTransferClick() {
    this.dialogRef.close('transfer');
    console.log(true);
  }
}
