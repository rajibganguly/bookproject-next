export function filterPhoneNumber(phoneNumber: string): string {
  const digitsOnly = phoneNumber.replace(/\D/g, '');
  return digitsOnly.slice(digitsOnly.length - 10);
}
