import { Component, OnInit } from '@angular/core';
import { AuthService } from './core/services/auth.service';
import { CampaignDataService } from './config/services/campaign-data.service';
import { RetailerDataService } from './config/services/retailer-data.service';
import { AdvertiserDataService } from './config/services/advertiser-data.service';
import { TemplatesDataService } from './config/services/templates-data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  title = 'portal';

  constructor(
    private authService: AuthService,
    private campaignDataService: CampaignDataService,
    private retailerDataService: RetailerDataService,
    private advertiserDataService: AdvertiserDataService,
    private templatesDataService: TemplatesDataService,
  ) {}

  ngOnInit() {
    this.authService.currentUser.Admin = true;
    this.authService.currentUser.Name = 'Rob J';
    this.retailerDataService.initialize();
    this.campaignDataService.initialize();
    this.advertiserDataService.initialize();
    this.templatesDataService.initialize();
  }
}
