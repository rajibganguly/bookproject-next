export class DisplayOfferLink {
  constructor(
    public DisplayOfferId: string,
    public OfferId: string,
    public DisplayOfferUrl: string,
    public QrCodeUrl: string,
    public RetailDisplayId: string
  ) {}
}
