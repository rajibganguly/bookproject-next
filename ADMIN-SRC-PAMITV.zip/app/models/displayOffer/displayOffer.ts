export class DisplayOffer {
    constructor(
      public DisplayOfferId: string,
      public RetailDisplayId: string,
      public OfferTemplateId: string,
      public AdvertiserId: string,
      public CampaignId: string,
      public OfferId: string,
      public CampaignOfferType: string,
      public Enabled: boolean,
      public QrCodeUrl: string,
      public RedirectUrl: string,
      public HttpRequestType: number
    ) {}
  }
  