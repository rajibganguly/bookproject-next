export interface IPostRedirectReqObject {
  name: string;
  RedirectBaseUrl: string;
  CampaignBrandTemplateId: string;
  UserDataCaptureTemplate: string;
  CampaignOfferType: number;
  HttpRequestType: string;
  Active: boolean;
  Params: [
    {
      Index: number;
      Type: number;
      Key: string;
      Value: string;
    }
  ];
}

export interface IPutEditRedirectReqObject {
  CampaignId: string;
  OfferTemplateId: string;
  OfferId: string;
  CampaignOfferType: number;
  Name: string;
  Active: boolean;
  HttpRequestType: string;
  RedirectBaseUrl: string;
  Params: [
    {
      Index: number;
      Type: number;
      Key: string;
      Value: string;
    }
  ];
  CouponPosCode?: string;
  CouponTemplate?: string;
  CouponExpiresText?: string;
  Expires: unknown;
  UserDataCaptureTemplate?: string;
  CampaignBrandTemplateId?: string;
}

export interface IEditDeleteFormData {
  clicked: string;
  formValue: IEditDeleteFormValueData;
}

export interface IEditDeleteFormValueData {
  activeCheckBox: boolean;
  campaignBrandTemplateId: string;
  displayOfferId: string;
  guestDataTemplateId: string;
  name: string;
  offerId: string;
  param1Key: string;
  redirectUrl: string;
}
