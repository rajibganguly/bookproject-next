export class CampaignBrandTemplate {
  constructor(
    public CampaignBrandTemplateId: string,
    public CampaignId: string,
    public Description: string,
    public Enabled: boolean,
    public Name: string,
    public Attributes: Array<Attributes>
  ) {}
}

class Attributes {
  constructor(
    public Key: number,
    public Value: string,
    public Type: string
  ) {}
}
