import { OfferTemplate } from '../offer/offer-template';

export class Campaign {
  constructor(
    public Name: string,
    public Description: string,
    public CampaignId: string,
    public AdvertiserId: string,
    public AdAgencyId: string,
    public RetailerId: string,
    public Active: boolean,
    public AllRetailers: boolean
  ) {}

  public OfferTemplates: OfferTemplate[] = [];
}
