export const OfferNameLists = [
  'Facebook',
  'Website',
  'Instagram',
  'GrubHub',
  'Doordash',
  'UberEats',
  'Yelp'
];
