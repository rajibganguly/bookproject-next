export enum CampaignOfferType {
  SimpleRedirect = 'Simple Redirect',
  SingleUseBasicCoupon = 'Single Use Coupon',
  CaptureThenRedirect = 'Connect and Redirect',
  QuickConnect = 'Quick Connect'
}
