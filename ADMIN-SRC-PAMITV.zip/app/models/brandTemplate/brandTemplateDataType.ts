export enum BrandTemplateDataType {
  String = '1',
  ImageUrl = '2',
  Color = '3',
  FontFamily = '4',
  FontName = '5',
  FontSize = '6',
  // Dropdown = '7',
  WebPageUrl = '8',
  Html = '9'
}
