import { CampaignBrandAttributeFieldType } from './campaignBrandAttributeFieldType';

export const CampaignBrandAttributeFieldStringMap: Record<number, string> = {
  [CampaignBrandAttributeFieldType.RegistrationHeaderImage]: 'Header Image',
  [CampaignBrandAttributeFieldType.RegistrationFormTitleText]: 'Title Text',
  [CampaignBrandAttributeFieldType.RegistrationFormTitleTextColor]:
    'Registration Form Title Text Color',
  [CampaignBrandAttributeFieldType.RegistrationBackgroundColor]:
    'Registration Form Background Color',
  [CampaignBrandAttributeFieldType.RegistrationTextColor]:
    'Registration Form Text Color',
  [CampaignBrandAttributeFieldType.RegistrationCtaButtonText]:
    'Registration Form Call To Action Button Text',
  [CampaignBrandAttributeFieldType.RegistrationCtaTextColor]:
    'Registration Form Call To Action Text Color',
  [CampaignBrandAttributeFieldType.RegistrationCtaBackgroundColor]:
    'Registration Form Call To Action Background Color',
  [CampaignBrandAttributeFieldType.RegistrationPageBackgroundColor]:
    'Registration Page Call To Action Background Color',
  [CampaignBrandAttributeFieldType.RegistrationPageFont]:
    'Registration Page Font',
  [CampaignBrandAttributeFieldType.RegistrationFontSize]:
    'Registration Font Size',
  [CampaignBrandAttributeFieldType.RegistrationFontName]:
    'Registration Font Name',
  [CampaignBrandAttributeFieldType.LandingSubtitle]: 'Landing Page Sub title',
  [CampaignBrandAttributeFieldType.LandingCtaButtonText]:
    'Landing Page Call To Action Button Text',
  [CampaignBrandAttributeFieldType.LandingCtaButtonUrl]:
    'Landing Page Call To Action Button URL',
  [CampaignBrandAttributeFieldType.UpdateProfileButtonText]:
    'Update Profile Button Text',
  [CampaignBrandAttributeFieldType.QuickConnectRequestedFormTitleText]:
    'Quick Connect Requested Form Title Text',
  [CampaignBrandAttributeFieldType.QuickConnectRequestedFormSubTitleText]:
    'Quick Connect Requested Form Sub Title Text',
  [CampaignBrandAttributeFieldType.QuickConnectCtaButtonText]:
    'Quick Connect CTA Button Text',
  [CampaignBrandAttributeFieldType.ReturningGuestFormTitleText]:
    'Returning Guest Form Title Text',
  [CampaignBrandAttributeFieldType.CouponUsedOrExpiredTemplate]:
    'Coupon Used/Expired Template',
  [CampaignBrandAttributeFieldType.ErrorTextFontColor]: 'Error Text Font Color',
  [CampaignBrandAttributeFieldType.RegistrationFormTextColor]:
    'Registration Form Text Color',
  [CampaignBrandAttributeFieldType.PlaceholderTextColor]:
    'Placeholder Text Color',
  [CampaignBrandAttributeFieldType.RegistrationHeaderImageRedirectUrl]:
    'Header Image Redirect URL'
};
// export const CampaignBrandAttributeFieldStringMap = [
//   'Header Image URL',
//   'Title Text',
//   'Registration Form Title Text Color',
//   'Registration Form Background Color',
//   'Registration Form Text Color',
//   'Registration Form Call To Action Button Text',
//   'Registration Form Call To Action Text Color',
//   'Registration Form Call To Action Background Color',
//   'Registration Page Call To Action Background Color',
//   'Registration Page Font',
//   'Registration Font Size',
//   'Registration Font Name',
//   'Landing Page Sub title',
//   'Landing Page Call To Action Button Text',
//   'Landing Page Call To Action Button URL',
//   'Update Profile Button Text',
//   'Quick Connect Requested Form Title Text',
//   'Quick Connect Requested Form Sub Title Text',
//   'Quick Connect CTA Button Text',
//   'Returning Guest Form Title Text',
//   'Coupon Used/Expired Template',
//   'Error Text Font Color',
//   'Registration Form Text Color',
//   'Placeholder Text Color'
// ];
