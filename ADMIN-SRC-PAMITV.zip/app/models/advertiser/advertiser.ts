import { StreetAddress } from '../address/streetAddress';

export class Advertiser {
  constructor(
    public Name: string,
    public Description: string,
    public AdvertiserId: string,
    public MailingAddress: StreetAddress,
    public Phone1: string,
    public Active: boolean
  ) {}
}
