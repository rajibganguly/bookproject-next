export class VideoOverlayTemplate {
    constructor(
      public VideoOverlayTemplateId: string,
      public Name: string,
      public Description: string,
      public X: number,
      public Y: number,
      public Width: number,
      public Height: number,
      public Phone1: string,
      public Enabled: boolean,
    ) {}
  }
  