export class VideoFile {
  constructor(
    public files: string[],
    public campaignName: string,
    public campaignId: string
  ) {}
}
