export const GuestAttributeDataTypeMap = new Map<number, string>([
  [1, 'String'],
  [2, 'Phone'],
  [3, 'Number'],
  [4, 'Date'],
  [5, 'Bool'],
  [6, 'Email'],
  [7, 'Dropdown']
]);

export enum GuestAttributeDataType {
  String = 1,
  Phone = 2,
  Number = 3,
  Date = 4,
  Bool = 5,
  Email = 6,
  Dropdown = 7
}

export enum GuestAttributeFieldType {
  FirstName = 1,
  LastName = 2,
  FullName = 3,
  Phone = 4,
  Email = 5,
  Age = 6,
  DateOfBirth = 7,
  Sex = 8,
  Address1 = 9,
  Address2 = 10,
  City = 11,
  State = 12,
  PostalCode = 13,
  Acknowledgement = 14,
  IpAddress = 15,
  Browser = 16,
  DeviceType = 17,
  GuestCompany = 18
}

export const GuestAttributeFieldTypeMap = new Map<number, string>([
  [1, 'FirstName '],
  [2, 'LastName '],
  [3, 'FullName '],
  [4, 'Phone'],
  [5, 'Email'],
  [6, 'Age'],
  [7, 'DateOfBirth'],
  [8, 'Sex'],
  [9, 'Address1'],
  [10, 'Address2'],
  [11, 'City'],
  [12, 'State'],
  [13, 'PostalCode'],
  [14, 'Acknowledgement'],
  [15, 'IpAddress'],
  [16, 'Browser'],
  [17, 'DeviceType'],
  [18, 'GuestCompany']
]);
