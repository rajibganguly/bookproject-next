export class GuestDataTemplate {
  constructor(
    public GuestDataTemplateId: string,
    public Name: string,
    public Description: string,
    public PromptedAttributes: PromptedAttributes[],
    public OtherAttributes: string | null,
    public Enabled: boolean
  ) {}
}

export class PromptedAttributes {
  constructor(
    public DisplayOrder: number,
    public Label: string,
    public Placeholder: string,
    public GuestAttributeFieldType: number,
    public GuestAttributeDataType: number,
    public DataFieldName: string,
    public Required: boolean,
    public HasChildEntries: boolean,
    public Options: Options[] | undefined
  ) {}
}

export class Options {
  constructor(
    public Label: string,
    public Value: string,
    public InquiryType: string | null,
    public DataFieldName: string | null,
    public Attributes: Attributes[] | undefined
  ) {}
}
class Attributes {
  constructor(
    public DisplayOrder: number,
    public Label: string,
    public Placeholder: string | null,
    public GuestAttributeFieldType: number,
    public GuestAttributeDataType: number,
    public DataFieldName: string,
    public Required: boolean,
    public HasChildEntries: boolean
  ) {}
}
