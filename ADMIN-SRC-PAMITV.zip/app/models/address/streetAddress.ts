export class StreetAddress {
  constructor(
    public Address1: string,
    public Address2: string,
    public City: string,
    public State: string,
    public PostalCode: string,
    public Country: string
  ) {}
}
