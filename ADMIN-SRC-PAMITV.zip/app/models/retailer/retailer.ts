import { StreetAddress } from '../address/streetAddress';
import { RetailLocation } from './retailLocation';

export class Retailer {
  constructor(
    public Name: string,
    public Description: string,
    public RetailerId: string,
    public MailingAddress: StreetAddress,
    public Phone1: string,
    public Active: boolean,
    public RetailLocations: RetailLocation[],
    public SicCode: string
  ) {}
}
