export class RetailDisplay {
  constructor(
    public RetailLocationId: string,
    public RetailLocationName: string,
    public RetailDisplayId: string,
    public DisplayId: string,
    public Description: string,
    public Enabled: boolean,
    public PamiTvDeviceType: string,
    public Orientation: string,
    public IpAddress: string
  ) {}
}
