import { StreetAddress } from '../address/streetAddress';
import { RetailDisplay } from './retailDisplay';

export class RetailLocation {
  constructor(
    public RetailLocationId: string,
    public Name: string,
    public RetailerUnitId: string,
    public RetailerId: string,
    public StreetAddress: StreetAddress,
    public Phone1: string,
    public Active: boolean,
    public RetailDisplays: RetailDisplay[]
  ) {}
}
