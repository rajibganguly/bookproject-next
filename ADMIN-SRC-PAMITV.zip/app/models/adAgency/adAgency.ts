export class AdAgency {
  constructor(public AdAgencyId: string, public Name: string) {}
}
