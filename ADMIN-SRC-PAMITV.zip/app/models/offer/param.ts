export class Param {
  constructor(
    public Index: number,
    public Type: number,
    public Key: string,
    public Value: string
  ) {}
}
