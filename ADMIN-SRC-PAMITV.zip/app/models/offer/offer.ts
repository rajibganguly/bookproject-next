import { Param } from './param';

export class Offer {
  constructor(
    public Name: string,
    public RedirectBaseUrl: string,
    public OfferId: string,
    public OfferTemplateId: string,
    public HttpRequestType: string,
    public CampaignOfferType: string,
    public Active: boolean,
    public Params: Param[],
    public CampaignBrandTemplateId: string,
    public UserDataCaptureTemplate: string
  ) {}
}
// public CouponPosCode: string,
// public Attributes: string[],
// public CouponTemplate: string,
// public CouponExpiresText: string,
// public Expires: Date | null
