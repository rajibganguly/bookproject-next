// import { Offer } from "./offer";

export class OfferTemplate {
  constructor(
    public Name: string,
    public Description: string,
    public CampaignId: string,
    public OfferTemplateId: string,
    public CampaignOfferType: string,
    public Active: boolean,
    public Attributes: string,
    public OfferTemplateParams: string,
    public OfferType?: number
  ) {}

  // public Offers: Offer[] = [];
}
