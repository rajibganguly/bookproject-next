import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CampaignBrandTemplateComponent } from './campaign-brand-template.component';

describe('CampaignBrandTemplateComponent', () => {
  let component: CampaignBrandTemplateComponent;
  let fixture: ComponentFixture<CampaignBrandTemplateComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CampaignBrandTemplateComponent]
    });
    fixture = TestBed.createComponent(CampaignBrandTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
