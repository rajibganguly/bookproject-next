import {
  Component,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { BrandTemplateDataType } from 'src/app/models/brandTemplate/brandTemplateDataType';
import { CampaignBrandTemplate } from 'src/app/models/campaign/campaignBrandTemplate';
import { OfferDataService } from '../../services/offer-data.service';
import { CampaignsService } from '../campaigns.service';
import { CampaignBrandAttributeFieldStringMap } from 'src/app/models/brandTemplate/campaignBrandAttributeFieldStringMap';
import { CampaignBrandAttributeFieldType } from 'src/app/models/brandTemplate/campaignBrandAttributeFieldType';
import { TemplatesDataService } from '../../services/templates-data.service';
import { AuthService } from 'src/app/core/services/auth.service';

type DisplayTemplate = {
  fieldName: string;
  value: string;
  found: boolean;
  type: string;
};

@Component({
  selector: 'app-campaign-brand-template',
  templateUrl: './campaign-brand-template.component.html',
  styleUrls: ['./campaign-brand-template.component.scss']
})
export class CampaignBrandTemplateComponent implements OnInit, OnChanges {
  @Input() campaignId = '';
  @ViewChild('templateSelect') templateSelect!: HTMLSelectElement;
  campaignBrandTemplates: CampaignBrandTemplate[] = [];
  selectedCampaignBrandTemplate: Partial<CampaignBrandTemplate> = {};
  keys: string[] = [];
  types: string[] = [];
  BrandTemplateDataType = BrandTemplateDataType;
  brandTemplateForm: FormGroup;
  editTemplateName = false;
  fontSizes: string[] = [];
  selectedFile: File | null = null;
  constructor(
    public offerDataService: OfferDataService,
    public campaignsService: CampaignsService,
    private fb: FormBuilder,
    private templateDataService: TemplatesDataService,
    public authService: AuthService
  ) {
    this.brandTemplateForm = fb.group({
      Name: '',
      CampaignBrandTemplateId: '',
      CampaignId: '',
      Enabled: true,
      Description: '',
      Attributes: fb.array([])
    });
    for (let i = 8; i < 21; i++) this.fontSizes.push(i + 'px');
  }
  get Attributes() {
    return this.brandTemplateForm.get('Attributes') as FormArray;
  }

  ngOnInit(): void {
    this.keys = Object.keys(CampaignBrandAttributeFieldType).filter(
      (val) => !isNaN(Number(val))
    );
    this.types = Object.keys(BrandTemplateDataType).filter((type) =>
      isNaN(Number(type))
    );
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes) {
      if (this.campaignId !== '') {
        this.campaignBrandTemplates =
          this.templateDataService.getCampaignBrandTemplate(this.campaignId);
      }
      this.brandTemplateForm = this.fb.group({
        Name: '',
        CampaignBrandTemplateId: '',
        CampaignId: '',
        Enabled: true,
        Description: '',
        Attributes: this.fb.array([])
      });
      this.editTemplateName = false;
      this.selectedCampaignBrandTemplate = {};
      if (this.templateSelect) this.templateSelect.value = '';
    }
  }
  updateFormTemplate(template: CampaignBrandTemplate) {
    this.brandTemplateForm.controls['Name'].setValue(template.Name);
    this.brandTemplateForm.controls['Description'].setValue(
      template.Description
    );
    this.brandTemplateForm.controls['CampaignBrandTemplateId'].setValue(
      template.CampaignBrandTemplateId
    );
    this.brandTemplateForm.controls['Enabled'].setValue(template.Enabled);
    this.brandTemplateForm.controls['Name'].setValue(template.Name);
  }
  handleDisplayBrandTemplate(campaignBrandTemplateId: string) {
    this.Attributes.controls = [];
    for (const template of this.campaignBrandTemplates) {
      if (template.CampaignBrandTemplateId === campaignBrandTemplateId) {
        this.selectedCampaignBrandTemplate = template;
        this.selectedCampaignBrandTemplate.Attributes?.sort(
          (r1, r2) => r1.Key - r2.Key
        );
        this.updateFormTemplate(template);
        let j = 0;
        this.keys.forEach((strKey) => {
          if (!this.selectedCampaignBrandTemplate.Attributes) return;
          const key = Number(strKey);
          if (
            j < this.selectedCampaignBrandTemplate.Attributes.length &&
            Number(strKey) ===
              this.selectedCampaignBrandTemplate.Attributes[j].Key
          ) {
            this.Attributes.controls.push(
              this.fb.group({
                fieldName: [CampaignBrandAttributeFieldStringMap[key]],
                value: [this.selectedCampaignBrandTemplate.Attributes[j].Value],
                type: [this.selectedCampaignBrandTemplate.Attributes[j].Type],
                found: [true]
              })
            );
            j++;
          } else {
            this.Attributes.controls.push(
              this.fb.group({
                fieldName: [CampaignBrandAttributeFieldStringMap[key]],
                value: ['NOT FOUND'],
                type: ['NOT FOUND'],
                found: [false]
              })
            );
          }
        });
        break;
      }
    }
  }
  showInputTag(attribute: DisplayTemplate) {
    return !(
      attribute.type === BrandTemplateDataType.ImageUrl ||
      attribute.type === BrandTemplateDataType.Color ||
      attribute.type === BrandTemplateDataType.WebPageUrl
    );
  }
  openLink(url: string | undefined) {
    if (!url) return;
    window.open(url, '_blank');
  }
  onUpdate() {
    console.log(this.brandTemplateForm.getRawValue());
  }
  fileSelect(event: Event) {
    const target = event.target as HTMLInputElement;
    if (!target.files) return;
    console.log(target.files[0]);
    this.selectedFile = target.files[0];

    // To be changed when uploading the image...
    const imgSrc = URL.createObjectURL(this.selectedFile);
    this.Attributes.controls.forEach((attribute) => {
      if (
        CampaignBrandAttributeFieldStringMap[
          CampaignBrandAttributeFieldType.RegistrationHeaderImage
        ] === attribute.get('fieldName')?.value
      ) {
        attribute.get('value')?.setValue(imgSrc);
      }
    });
  }
}
