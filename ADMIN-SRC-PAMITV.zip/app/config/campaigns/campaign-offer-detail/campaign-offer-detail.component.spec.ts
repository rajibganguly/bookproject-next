import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CampaignOfferDetailComponent } from './campaign-offer-detail.component';

describe('CampaignOfferDetailComponent', () => {
  let component: CampaignOfferDetailComponent;
  let fixture: ComponentFixture<CampaignOfferDetailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CampaignOfferDetailComponent]
    });
    fixture = TestBed.createComponent(CampaignOfferDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
