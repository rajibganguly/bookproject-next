import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  Inject,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

import { Campaign } from './../../../models/campaign/campaign';
import { CampaignBrandTemplate } from './../../../models/campaign/campaignBrandTemplate';
import { GuestDataTemplate } from './../../../models/guestDataTemplate/guestDataTemplate';
import { TemplatesDataService } from '../../services/templates-data.service';
import { CommonStoreService } from '../../services/common-store.service';
import { CampaignOfferType } from 'src/app/models/campaign/campaignOfferType';
import { OfferNameLists } from 'src/app/models/campaign/offerNameLists';
import {
  MatAutocomplete,
  MatAutocompleteTrigger
} from '@angular/material/autocomplete';

@Component({
  selector: 'app-campaign-offer-detail',
  templateUrl: './campaign-offer-detail.component.html',
  styleUrls: ['./campaign-offer-detail.component.scss']
})
export class CampaignOfferDetailComponent implements OnInit, AfterViewInit {
  // Added different formgroup names using
  offersForm!: FormGroup; //Newly create form
  offersEditForm!: FormGroup; //View or edit form
  campaignId = '';
  offerTypes: Array<any> = [];
  currentCampaignOfferType = '';
  campaignOfferType = CampaignOfferType;

  nameOptions: string[] = OfferNameLists;

  typesOfForm = '';
  offersEditFormDisable = true;

  allCampaigns: Campaign[] = [];
  advertiserId!: string;
  @Output() saveClicked = new EventEmitter<any>();
  brandTemplates: CampaignBrandTemplate[] = [
    {
      Attributes: [{ Key: 0, Value: '', Type: '' }],
      CampaignBrandTemplateId: 'Create New Template',
      CampaignId: 'Create New Template',
      Description: '',
      Enabled: false,
      Name: 'Create New Template'
    }
  ];
  guestDataTemplates: GuestDataTemplate[] = [
    {
      Name: 'New Guest data',
      GuestDataTemplateId: '',
      PromptedAttributes: [
        {
          DisplayOrder: 0,
          Label: '',
          Placeholder: '',
          GuestAttributeFieldType: 0,
          GuestAttributeDataType: 1,
          DataFieldName: '',
          Required: false,
          HasChildEntries: false,
          Options: []
        }
      ],
      Enabled: false,
      Description: '',
      OtherAttributes: null
    }
  ];

  // For dialogbox appearing
  @ViewChild('updateOfferName') updateOfferName: ElementRef | any;
  @ViewChild(MatAutocompleteTrigger)
  autocompleteTrigger: MatAutocompleteTrigger | any;

  constructor(
    private fb: FormBuilder,
    @Inject(MAT_DIALOG_DATA)
    public data: {
      name: string;
      displayType: string;
      offerType: number;
      editValue: {
        Name: string;
        RedirectBaseUrl: string;
        Active: boolean;
        Params: [{ Index: number; Type: number; Key: string; Value: string }];
        OfferId: string;
        CampaignBrandTemplateId?: string;
        GuestDataTemplateId?: string;
        UserDataCaptureTemplate?: string;
        CampaignOfferType?: number;
        displayOffer: boolean;
      };
    },
    private dialogRef: MatDialogRef<CampaignOfferDetailComponent>,
    private templateDataService: TemplatesDataService,
    private commService: CommonStoreService
  ) {
    this.nameOptions = OfferNameLists.slice();
    this.offersForm = this.fb.group({
      name: ['', Validators.required],
      redirectUrl: [''],
      param1Key: ['pamitv'],
      displayOfferId: ['DisplayOfferId'],
      Active: [true]
    });
    this.offersEditForm = this.fb.group({
      name: ['', Validators.required],
      redirectUrl: [''],
      param1Key: ['pamitv'],
      displayOfferId: ['DisplayOfferId'],
      activeCheckBox: [true],
      campaignBrandTemplateId: '',
      guestDataTemplateId: '',
      offerId: [''],
      displayOffer: ['']
    });
  }

  ngAfterViewInit(): void {
    if (this.data.displayType === 'EditRedirectOffer') {
      this.updateOfferName.nativeElement.focus();
      this.autocompleteTrigger.closePanel();
    }
  }

  ngOnInit(): void {
    this.createOfferTypesList();
    this.templateDataService
      .getGuestDataTemplates()
      .subscribe((templates: GuestDataTemplate[]) => {
        this.guestDataTemplates = templates;
      });

    // Emits Offer form value "View/Edit RedirectOffer"
    if (this.data.displayType === 'EditRedirectOffer') {
      this.offersEditForm = this.fb.group({
        name: this.data.editValue.Name,
        redirectUrl: this.data.editValue.RedirectBaseUrl,
        param1Key: this.data.editValue.Params[0].Key,
        displayOfferId: this.data.editValue.Params[0].Value,
        activeCheckBox: this.data.editValue.Active,
        campaignBrandTemplateId: this.data.editValue.CampaignBrandTemplateId
          ? this.data.editValue.CampaignBrandTemplateId
          : '',
        guestDataTemplateId: this.data.editValue.UserDataCaptureTemplate
          ? this.data.editValue.UserDataCaptureTemplate
          : '',
        offerId: this.data.editValue.OfferId
      });
    }

    //1. Available campaignId
    //2. Fetch data from getCampaignBrandTemplateId
    //2. Fetch data from getGuestDataTemplateId
    /****
     * @description Available guest and brand data
     */
    this.commService
      .getRedirectOffertypeValue()
      .subscribe(
        (val: {
          campaignName?: string;
          campaignId?: string;
          offerTemplateId?: string;
          campaignOfferType?: number;
        }) => {
          this.campaignId = val.campaignId ? val.campaignId : '';
          if (this.campaignId) {
            this.brandTemplates =
              this.templateDataService.getCampaignBrandTemplate(
                this.campaignId
              );
          }
        }
      );

    // When value changed
    const checkofferType = this.data.offerType; // data.editValue.CampaignOfferType;
    if (checkofferType) {
      this.currentCampaignOfferType =
        this.getOfferTypesListName(checkofferType)[0].Name;
    }
    this.offersEditForm.valueChanges.subscribe((changes: SimpleChanges) => {
      if (changes) {
        if (
          this.currentCampaignOfferType === this.campaignOfferType.QuickConnect
        ) {
          if (
            this.offersEditForm.value['campaignBrandTemplateId'] !== '' &&
            this.offersEditForm.value['guestDataTemplateId'] !== ''
          ) {
            this.offersEditFormDisable = false;
          }
        }
        if (
          this.currentCampaignOfferType !== this.campaignOfferType.QuickConnect
        ) {
          this.offersEditFormDisable = false;
        }
      }
    });
  }

  /**
   * @description Private method to create CampaignOfferType list with Id
   * @returns offerTypes
   */
  createOfferTypesList() {
    let i = 1;
    for (const offerType of Object.values(CampaignOfferType)) {
      this.offerTypes.push({ Name: offerType, OfferTypeId: i });
      i++;
    }
  }

  /**
   * @description Private method for filter offerType for name
   * @param offerTypeId
   * @returns
   */
  getOfferTypesListName(offerTypeId: number) {
    return this.offerTypes.filter(
      (offer: { Name: string; OfferTypeId: number }) =>
        offer.OfferTypeId === offerTypeId
    );
  }

  /**
   * On Close button for dialog
   */
  onClose(): void {
    this.dialogRef.close();
  }

  /**
   * On save offer done
   */
  onOfferFormDone() {
    // Emits Offer form value "AddRedirectOffer"
    if (this.data.displayType === 'AddRedirectOffer') {
      this.saveClicked.emit(this.offersForm.value);
    }
    // Emits Offer form value "View/Edit RedirectOffer"
    if (this.data.displayType === 'EditRedirectOffer') {
      const emitedValue = {
        formValue: this.offersEditForm.value,
        clicked: 'edit'
      };
      this.saveClicked.emit(emitedValue);
    }
    this.dialogRef.close();
  }

  onOfferDelete() {
    const emitedValue = {
      formValue: this.offersEditForm.value,
      clicked: 'delete'
    };
    this.saveClicked.emit(emitedValue);
    this.dialogRef.close();
  }
}
