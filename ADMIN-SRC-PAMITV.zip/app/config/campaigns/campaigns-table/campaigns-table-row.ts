export class CampaignsTableRow {
  public CampaignId: string = '';
  public CampaignName: string = '';
  public Description: string = '';
  public AdvertiserId: string = '';
  public AdvertiserName: string = '';
  public RetailerId: string = '';
  public RetailerName: string = '';
  public AdAgencyId: string = '';
  public AdAgencyName: string = '';
  public Active: boolean = false;
  public AllRetailers: boolean = false;

  constructor(initialValues?: Partial<CampaignsTableRow>) {
    if (initialValues) {
      Object.assign(this, initialValues);
    }
  }
}
