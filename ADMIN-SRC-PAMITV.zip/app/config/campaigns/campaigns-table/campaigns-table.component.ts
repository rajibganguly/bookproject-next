import {
  AfterViewInit,
  Component,
  ElementRef,
  NgZone,
  OnInit,
  QueryList,
  ViewChild,
  ViewChildren
} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { AdvertiserDataService } from '../../services/advertiser-data.service';
import { MatSort } from '@angular/material/sort';
import { CampaignsTableRow } from './campaigns-table-row';
import { CampaignDataService } from '../../services/campaign-data.service';
import { AdAgencyDataService } from '../../services/adAgency-data.service';
import { RetailerDataService } from '../../services/retailer-data.service';
import { OfferDataService } from '../../services/offer-data.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CampaignsService } from '../campaigns.service';
import { CommonStoreService } from '../../services/common-store.service';
import { ActionCompletedDialogComponent } from 'src/app/core/action-completed-dialog/action-completed-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { AuthService } from 'src/app/core/services/auth.service';
import { RetailersService } from '../../retailers/retailers.service';

@Component({
  selector: 'app-campaigns-table',
  templateUrl: './campaigns-table.component.html',
  styleUrls: ['./campaigns-table.component.scss']
})
export class CampaignsTableComponent implements OnInit, AfterViewInit {
  displayedColumns: string[] = [
    'name',
    'advertiser',
    'retailer',
    'adAgency',
    'id'
  ];
  dataSource: MatTableDataSource<CampaignsTableRow>;
  selectedRowIndex = '';

  @ViewChild(MatSort) sort!: MatSort;
  @ViewChildren('rowName') rowElements!: QueryList<ElementRef<HTMLElement>>;
  constructor(
    private campaignDataService: CampaignDataService,
    private campaignsService: CampaignsService,
    private retailerDataService: RetailerDataService,
    private advertiserDataService: AdvertiserDataService,
    private adAgencyDataService: AdAgencyDataService,
    private offerDataService: OfferDataService,
    private router: Router,
    private route: ActivatedRoute,
    private ngZone: NgZone,
    private commService: CommonStoreService,
    public dialog: MatDialog,
    private authService: AuthService,
    private retailersService: RetailersService
  ) {
    this.dataSource = new MatTableDataSource();
  }

  ngOnInit(): void {
    this.selectedRowIndex = this.campaignsService.campaignName;
    console.log(this.selectedRowIndex);
    this.dataSource.data = this.getCampaignTableData();
    if (
      this.campaignsService.showSuccessModal &&
      this.selectedRowIndex !== ''
    ) {
      this.campaignsService.showSuccessModal = false;
      this.openSuccessDialog(this.selectedRowIndex);
    }
    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case 'name':
          return item.CampaignName;
        case 'retailer':
          return item.RetailerName;
        case 'advertiser':
          return item.AdvertiserName;
        case 'adAgency':
          return item.AdAgencyName;
        default:
          return item.CampaignName;
      }
    };
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.ngZone.runOutsideAngular(() => {
      setTimeout(() => {
        this.sort.sort({ id: 'name', start: 'asc', disableClear: false });
        this.dataSource.sort = this.sort;
        if (this.selectedRowIndex !== '') {
          this.scrollToElement();
        }
      });
    });
  }

  openSuccessDialog(retailerName: string): void {
    const dialogRef = this.dialog.open(ActionCompletedDialogComponent, {
      data: { name: retailerName, buttonText: 'Return to Retailer' }
    });
    dialogRef.afterClosed().subscribe((value) => {
      if (value === 'transfer') {
        this.authService.navTitle = 'Retailers';
        this.router.navigate(['/Retailers']);
      } else if (value === 'stay') {
        this.retailersService.retailerId = '';
        this.retailersService.retailerName = '';
        this.retailersService.showRetailerSuccessModal = true;
      }
    });
  }
  scrollToElement(): void {
    console.log(
      this.rowElements
        .toArray()
        .find((element) => element.nativeElement.id === this.selectedRowIndex)
    );
    this.rowElements
      .toArray()
      .find((element) => element.nativeElement.id === this.selectedRowIndex)
      ?.nativeElement.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
        inline: 'center'
      });
  }

  getCampaignTableData(): CampaignsTableRow[] {
    const campaigns = this.campaignDataService.getAuthorizedCampaigns();
    const campaignTableData: CampaignsTableRow[] = [];
    campaigns.forEach((campaign) => {
      const tableRow = new CampaignsTableRow({
        CampaignName: campaign.Name,
        Active: campaign.Active,
        AdAgencyId: campaign.AdAgencyId,
        RetailerId: campaign.RetailerId,
        CampaignId: campaign.CampaignId,
        AdvertiserId: campaign.AdvertiserId,
        AllRetailers: campaign.AllRetailers
      });

      if (tableRow.AllRetailers) {
        tableRow.RetailerName = 'ALL';
      } else {
        const retailer = this.retailerDataService.getRetailer(
          campaign.RetailerId
        );
        if (retailer) {
          tableRow.RetailerName = retailer.Name;
        } else {
          tableRow.RetailerName = 'N/A';
        }
      }
      const adAgency = this.adAgencyDataService.getAdAgency(
        campaign.AdAgencyId
      );
      if (adAgency) {
        tableRow.AdAgencyName = adAgency.Name;
      } else {
        tableRow.AdAgencyName = 'N/A';
      }
      const advertiser = this.advertiserDataService.getAdvertiser(
        campaign.AdvertiserId
      );
      if (advertiser) {
        tableRow.AdvertiserName = advertiser.Name;
      } else {
        tableRow.AdvertiserName = 'N/A';
      }

      campaignTableData.push(tableRow);
    });
    return campaignTableData;
  }

  selectCampaign(campaign: CampaignsTableRow) {
    this.selectedRowIndex = campaign.CampaignName;
    this.campaignsService.campaignId = campaign.CampaignId;
    this.offerDataService.offerTemplateId = '';
    this.commService.setRedirectOffertypeFlag(true);
    this.commService.setAdvertiserId(campaign.AdvertiserId);
  }

  /***
   * @description add new campaign page
   */
  addCampaign() {
    console.log('addCampaign');
    this.router.navigate(['Wizard'], { relativeTo: this.route });
    this.campaignsService.displayWizard = true;
  }
}

export interface IOfferTemplates {
  OfferTemplateId: string;
  Name: string;
  Description: string;
  CampaignId: string;
  OfferType: number;
  Active: boolean;
  OfferTemplateParams: any;
  Attributes: '[]';
}
