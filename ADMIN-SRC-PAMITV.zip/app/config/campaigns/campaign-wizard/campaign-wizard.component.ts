import { Component, EventEmitter, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AdAgencyDataService } from '../../services/adAgency-data.service';
import { AdvertiserDataService } from '../../services/advertiser-data.service';
import { CampaignDataService } from '../../services/campaign-data.service';
import { RetailerDataService } from '../../services/retailer-data.service';
import { CampaignsService } from '../campaigns.service';
import { Retailer } from 'src/app/models/retailer/retailer';
import { StreetAddress } from 'src/app/models/address/streetAddress';
import { CampaignOfferType } from 'src/app/models/campaign/campaignOfferType';
import { ConfirmationDialogComponent } from 'src/app/core/confirmation-dialog/confirmation-dialog.component';
import { Campaign } from 'src/app/models/campaign/campaign';
import { OfferTemplate } from 'src/app/models/offer/offer-template';
import { Offer } from 'src/app/models/offer/offer';
import { Param } from 'src/app/models/offer/param';
import { Observable, concatMap, forkJoin, map } from 'rxjs';
import { OfferDataService } from '../../services/offer-data.service';
import { Advertiser } from 'src/app/models/advertiser/advertiser';
import { CampaignBrandTemplate } from 'src/app/models/campaign/campaignBrandTemplate';
import { GuestDataTemplate } from 'src/app/models/guestDataTemplate/guestDataTemplate';
import { TemplatesDataService } from '../../services/templates-data.service';
import { RetailersService } from '../../retailers/retailers.service';

@Component({
  selector: 'app-campaign-wizard',
  templateUrl: './campaign-wizard.component.html',
  styleUrls: ['./campaign-wizard.component.scss']
})
export class CampaignWizardComponent implements OnInit {
  campaignForm!: FormGroup;
  templateForm!: FormGroup;
  offersForm!: FormGroup;
  retailers!: Array<Retailer>;
  advertisers!: Array<Advertiser>;
  offerTypes: Array<{ name: string; offerTypeId: string }> = [];
  campaign!: Campaign;
  adAgencyId!: string;
  advertiserId!: string;
  retailerId!: string;
  offerTypeId!: string;
  allRetailers = false;
  offerTemplate!: OfferTemplate;
  offers: Offer[] = [];
  offerCount = 1;
  newWizard: string[] = [
    'Single Use Coupon',
    'Connect and Redirect',
    'Quick Connect'
  ];
  selectedBrandTemplate: Partial<CampaignBrandTemplate> = {};
  selectedGuestTemplate: Partial<GuestDataTemplate> = {};
  brandTemplates: CampaignBrandTemplate[] = [
    {
      Attributes: [{ Key: 0, Value: '', Type: '' }],
      CampaignBrandTemplateId: 'Create New Template',
      CampaignId: 'Create New Template',
      Description: '',
      Enabled: false,
      Name: 'Create New Template'
    }
  ];
  guestDataTemplates: GuestDataTemplate[] = [];
  allCampaigns: Campaign[] = [];
  isBrandTemplatesLoading = false;
  isOfferLoading = false;
  constructor(
    private fb: FormBuilder,
    private dialog: MatDialog,
    public retailerDataService: RetailerDataService,
    private campaignDataService: CampaignDataService,
    public campaignsService: CampaignsService,
    public advertiserDataService: AdvertiserDataService,
    public adAgencyDataService: AdAgencyDataService,
    private offerDataService: OfferDataService,
    private router: Router,
    private templateDataService: TemplatesDataService,
    private retailerService: RetailersService
  ) {}

  ngOnInit() {
    this.loadAllCampaigns();
    this.loadAllGuestDataTemplates();
    this.createRetailerList();
    this.createAdvertiserList();
    this.createOfferTypesList();
    this.campaignForm = this.fb.group({
      campaignName: [
        this.campaignDataService.retailerName,
        Validators.required
      ],
      description: [''],
      adAgency: ['', Validators.required],
      advertiser: ['', Validators.required],
      retailer: ['', Validators.required]
    });
    this.templateForm = this.fb.group({
      templateName: ['', Validators.required],
      description: [''],
      offerType: ['', Validators.required],
      offerCount: [this.offerCount, Validators.required],
      brandTemplate: [{ value: '', disabled: true }, Validators.required],
      guestDataTemplate: [{ value: '', disabled: true }, Validators.required]
    });
    this.offersForm = this.fb.group({
      offerControls: this.fb.array([])
    });
    if (this.campaignDataService.retailerId !== '') {
      this.retailerId = this.campaignDataService.retailerId;
      this.allRetailers = false;
      this.campaignForm.controls['retailer'].setValue(this.retailerId);
    }
  }

  get offerControls() {
    return this.offersForm.get('offerControls') as FormArray;
  }

  createAdvertiserList() {
    this.advertisers = this.advertiserDataService
      .getAuthorizedAdvertisers()
      .sort((a, b) => a.Name.toUpperCase().localeCompare(b.Name.toUpperCase()));
  }

  createRetailerList() {
    this.retailers = this.retailerDataService
      .getAuthorizedRetailers()
      .sort((a, b) => a.Name.toUpperCase().localeCompare(b.Name.toUpperCase()));
    const allRetailer = new Retailer(
      'ALL RETAILERS',
      '',
      'ALL',
      new StreetAddress('', '', '', '', '', ''),
      '',
      true,
      [],
      ''
    );
    this.retailers.unshift(allRetailer);
    return this.retailers;
  }

  createOfferTypesList() {
    this.offerTypes = Object.values(CampaignOfferType).map(
      (offerType, index) => ({
        name: offerType,
        offerTypeId: (index + 1).toString()
      })
    );
  }

  onOfferTypeChange(event: string) {
    console.log(this.offerTypes);
    const selectedOffer = this.offerTypes.find((x) => x.offerTypeId == event);
    if (!selectedOffer) return;
    this.templateForm.controls['brandTemplate'].disable();
    this.templateForm.controls['guestDataTemplate'].disable();
    this.newWizard.forEach((offer: string) => {
      if (selectedOffer.name === offer) {
        this.templateForm.controls['brandTemplate'].enable();
        this.templateForm.controls['guestDataTemplate'].enable();
      }
    });
    this.offerTypeId = selectedOffer.offerTypeId;
    this.templateForm.get('templateName')?.setValue(selectedOffer.name);
  }

  onAdAgencyChange(event: string) {
    this.adAgencyId = event;
  }

  onAdvertiserChange(event: EventEmitter<string>) {
    let campaigns: Campaign[] = [];
    this.advertiserId = event.toString();
    campaigns = this.allCampaigns.filter((campaign) => {
      return campaign.AdvertiserId === this.advertiserId;
    });
    this.isBrandTemplatesLoading = true;
    this.brandTemplates = [];
    this.templateDataService
      .getAllCampaignBrandTemplates()
      .subscribe((brands) => {
        if (brands) {
          this.brandTemplates = [
            {
              Attributes: [{ Key: 0, Value: '', Type: '' }],
              CampaignBrandTemplateId: 'Create New Template',
              CampaignId: 'Create New Template',
              Description: '',
              Enabled: false,
              Name: 'Create New Template'
            }
          ];
          campaigns.forEach((campaign) => {
            this.brandTemplates = [
              ...brands.filter(
                (brand) => brand.CampaignId === campaign.CampaignId
              ),
              ...this.brandTemplates
            ];
          });
          this.isBrandTemplatesLoading = false;
        }
      });
  }
  onRetailerChange(retailerId: string) {
    if (retailerId === 'ALL') {
      this.allRetailers = true;
      this.retailerId = '';
      this.retailerService.retailerName = '';
    } else {
      this.allRetailers = false;
      this.retailerId = retailerId;
      this.retailerService.showRetailerSuccessModal = false;
      this.retailerService.retailerId = retailerId;
    }
  }

  cancelWizard() {
    this.campaignsService.displayWizard = false;
    this.router.navigate(['Campaigns']);
  }

  onTemplateFormDone() {
    console.log('onTemplateFormDone', this.templateForm.value);
    this.offerCount = parseInt(this.templateForm.value['offerCount'], 10);
    for (let i = this.offerControls.controls.length; i < this.offerCount; i++) {
      const offer = new Offer('', '', '', '', '', '', true, [], '', '');
      this.addOffer(offer);
    }
  }

  addOffer(offer: Offer) {
    const offerGroup = this.fb.group({
      offerName: [offer.Name, Validators.required],
      redirectUrl: [offer.RedirectBaseUrl, Validators.required],
      param1Key: ['pamitv', Validators.required],
      param1Value: ['DisplayOfferId', Validators.required]
    });
    this.offerControls.push(offerGroup);
  }

  onOfferFormDone() {
    const i = this.offerControls.controls.length;
    const message = `Add this campaign with ${i} offer(s)?`;
    this.dialog
      .open(ConfirmationDialogComponent, {
        width: '300px',
        data: {
          message: message,
          header: 'Confirm Action',
          cancelBtnName: 'Cancel',
          confirmBtnName: 'Confirm'
        }
      })
      .afterClosed()
      .subscribe((result) => {
        if (result) {
          this.createCampaignElements();
        }
      });
  }

  createCampaignElements() {
    this.isOfferLoading = true;
    this.createCampaignData();
    this.campaignDataService
      .postCampaign(this.campaign)
      .pipe(
        concatMap((campaignResponse) => {
          console.log(
            'campaigns res->',
            campaignResponse,
            this.campaignsService
          );
          this.campaignsService.campaignName = campaignResponse.Name;
          this.campaignsService.campaignId = campaignResponse.CampaignId;
          this.campaign.CampaignId = campaignResponse.CampaignId;
          this.selectedBrandTemplate.CampaignId = campaignResponse.CampaignId;
          return forkJoin([
            this.templateDataService.postBrandTemplate(
              this.selectedBrandTemplate
            ),
            this.campaignDataService.postCampaignOfferTemplate(
              campaignResponse.CampaignId,
              this.offerTemplate
            )
          ]);
        }),
        concatMap(([campaignBrandResponse, offerTemplateResponse]) => {
          this.campaignsService.offerTemplateName = offerTemplateResponse.Name;
          this.offerDataService.offerTemplateId =
            offerTemplateResponse.OfferTemplateId;
          this.templateDataService.campaignBrandTemplates.push(
            campaignBrandResponse
          );
          const offerRequests: Observable<any>[] = [];
          this.offers.forEach((offer) => {
            offer.CampaignBrandTemplateId =
              campaignBrandResponse.CampaignBrandTemplateId;
            offerRequests.push(
              this.campaignDataService.postCampaignOffer(
                offerTemplateResponse.CampaignId,
                offerTemplateResponse.OfferTemplateId,
                offer
              )
            );
          });

          return forkJoin(offerRequests).pipe(
            map((offerResponses) => {
              let i = 0;
              offerResponses.forEach((offerResponse) => {
                if (offerResponse && offerResponse.OfferId) {
                  this.offers[i].OfferId = offerResponse.OfferId;
                }
                i++;
              });
              return true;
            })
          );
        })
      )
      .subscribe(
        (offerResp) => {
          const retailer = this.retailerDataService.getRetailer(
            this.retailerService.retailerId
          );
          if (retailer) {
            this.retailerService.retailerName = retailer.Name;
          }
          console.log('createCampaignElements', offerResp);
          this.campaignDataService.campaigns.push(this.campaign);
          this.offerDataService.offerTemplates.push(this.offerTemplate);
          this.offerDataService.offers = [
            ...this.offerDataService.offers,
            ...this.offers
          ];
          this.isOfferLoading = false;
          this.campaignsService.displayWizard = false;
          this.campaignsService.showSuccessModal = true;
          console.log('createCampaignElements', this.campaign);
          this.router.navigate(['Campaigns']);
        },
        (error) => {
          console.log('createCampaignElements', error);
          this.isOfferLoading = false;
        }
      );
  }

  createCampaignData() {
    this.campaign = new Campaign(
      this.campaignForm.value['campaignName'],
      this.campaignForm.value['description'],
      '',
      this.advertiserId,
      this.adAgencyId,
      this.retailerId,
      true,
      this.allRetailers
    );
    this.offerTemplate = new OfferTemplate(
      this.templateForm.value['templateName'],
      this.templateForm.value['description'],
      '',
      '',
      this.offerTypeId,
      true,
      '',
      ''
    );
    this.offers = [];
    this.offerControls.controls.forEach((offerForm) => {
      const param = new Param(
        1,
        1,
        offerForm.value['param1Key'],
        offerForm.value['param1Value']
      );
      const params: Param[] = [];
      params.push(param);
      const offer = new Offer(
        offerForm.value['offerName'],
        offerForm.value['redirectUrl'],
        '',
        '',
        '1',
        this.offerTypeId,
        true,
        params,
        '',
        this.selectedGuestTemplate.GuestDataTemplateId
          ? this.selectedGuestTemplate.GuestDataTemplateId
          : ''
      );
      this.offers.push(offer);
    });
  }
  loadAllCampaigns() {
    this.campaignDataService
      .loadAuthorizedCampaigns()
      .subscribe((campaigns: Campaign[]) => {
        this.allCampaigns = campaigns;
      });
  }
  onBrandTemplateChange(brandTemplateId: string) {
    this.templateForm.controls['brandTemplate'].setValue(brandTemplateId);
    if (brandTemplateId === 'Create New Template') {
      this.templateDataService
        .getDefaultBrandTemplateAttributes()
        .subscribe((res: CampaignBrandTemplate) => {
          this.selectedBrandTemplate = res;
        });
    } else {
      this.brandTemplates.forEach((template) => {
        if (template.CampaignBrandTemplateId === brandTemplateId) {
          this.selectedBrandTemplate = template;
          this.selectedBrandTemplate.Name +=
            '-' +
            (new Date().getMonth() + 1) +
            '/' +
            new Date().getDate() +
            '/' +
            new Date().getFullYear();
        }
      });
    }
  }
  loadAllGuestDataTemplates() {
    this.templateDataService
      .getGuestDataTemplates()
      .subscribe((templates: GuestDataTemplate[]) => {
        this.guestDataTemplates = templates;
      });
  }
  onGuestDataTemplateChange(guestDataTemplateId: string) {
    this.templateForm.controls['guestDataTemplate'].setValue(
      guestDataTemplateId
    );
    this.guestDataTemplates.forEach((template) => {
      if (template.GuestDataTemplateId === guestDataTemplateId) {
        this.selectedGuestTemplate = template;
      }
    });
  }
}
