import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CampaignOffersTableComponent } from './campaign-offers-table.component';

describe('CampaignOffersTableComponent', () => {
  let component: CampaignOffersTableComponent;
  let fixture: ComponentFixture<CampaignOffersTableComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CampaignOffersTableComponent]
    });
    fixture = TestBed.createComponent(CampaignOffersTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
