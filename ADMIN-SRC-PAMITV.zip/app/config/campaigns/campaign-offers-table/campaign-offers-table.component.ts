import {
  AfterViewInit,
  Component,
  Input,
  NgZone,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Offer } from 'src/app/models/offer/offer';
import { OfferDataService } from '../../services/offer-data.service';
import { CampaignsService } from '../campaigns.service';
import { Param } from 'src/app/models/offer/param';
import { CommonStoreService } from '../../services/common-store.service';
import { MatDialog } from '@angular/material/dialog';
import { AuthService } from 'src/app/core/services/auth.service';
import { CampaignOfferDetailComponent } from './../../campaigns/campaign-offer-detail/campaign-offer-detail.component';
import { ConfirmationDialogComponent } from 'src/app/core/confirmation-dialog/confirmation-dialog.component';
import { DisplayOfferDataService } from '../../services/displayOffer-data.service';
import {
  IEditDeleteFormData,
  IPostRedirectReqObject,
  IPutEditRedirectReqObject
} from 'src/app/models/campaign/campaign-offer.interface';
import { CampaignOfferType } from 'src/app/models/campaign/campaignOfferType';

@Component({
  selector: 'app-campaign-offers-table',
  templateUrl: './campaign-offers-table.component.html',
  styleUrls: ['./campaign-offers-table.component.scss']
})
export class CampaignOffersTableComponent
  implements OnInit, AfterViewInit, OnChanges
{
  @Input() offerTemplateId = '';
  // eslint-disable-next-line @typescript-eslint/no-inferrable-types
  hideOffer: boolean | undefined = true;
  campaignName = '';
  campaign: {
    campaignName: string;
    campaignId: string;
    campaignOfferType: number;
  } = {
    campaignName: '',
    campaignId: '',
    campaignOfferType: 0
  };

  displayedColumns: string[] = ['Name', 'RedirectUrl', 'Params'];
  dataSource: MatTableDataSource<Offer>;

  offerTypes: Array<any> = [];
  clickedRowsFl = new Set<{
    Active: boolean;
    Attributes: [];
    CampaignBrandTemplateId: string;
    CampaignOfferType: number;
    Name: string;
    OfferId: string;
    OfferTemplateId: string;
    Params: [];
    RedirectBaseUrl: string;
    UserDataCaptureTemplate: string;
  }>();

  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    private offerDataService: OfferDataService,
    private campaignsService: CampaignsService,
    private ngZone: NgZone,
    private commService: CommonStoreService,
    private dialog: MatDialog,
    private authService: AuthService,
    private displayOfferDataService: DisplayOfferDataService
  ) {
    this.dataSource = new MatTableDataSource();
  }

  ngOnInit(): void {
    this.createOfferTypesList();
    this.dataSource.data = this.offerDataService.getTemplateOffers(
      this.offerTemplateId
    );
    this.dataSource.sort = this.sort;

    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case 'Name':
          return item.Name;
        case 'RedirectUrl':
          return item.RedirectBaseUrl;
        default:
          return item.Name;
      }
    };

    // Header Offer button, true/false
    this.commService
      .getRedirectOffertypeValue()
      .subscribe(
        (val: {
          campaignName?: string;
          campaignId?: string;
          offerTemplateId?: string;
          campaignOfferType?: number;
        }) => {
          this.campaign.campaignName = val.campaignName ? val.campaignName : '';
          this.campaign.campaignId = val.campaignId ? val.campaignId : '';
          this.offerTemplateId = val.offerTemplateId ? val.offerTemplateId : '';
          this.campaign.campaignOfferType = val.campaignOfferType
            ? val.campaignOfferType
            : 0;
        }
      );
    this.commService.getRedirectOffertypeFlag().subscribe((val: boolean) => {
      this.hideOffer = val;
    });
  }

  ngAfterViewInit(): void {
    this.ngZone.runOutsideAngular(() => {
      setTimeout(() => {
        this.sort.sort({ id: 'Name', start: 'asc', disableClear: false });
        this.dataSource.sort = this.sort;
      });
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    this.dataSource = new MatTableDataSource();
    if (changes) {
      this.offerTemplateId = changes['offerTemplateId'].currentValue;
      if (!this.offerTemplateId) {
        this.dataSource.data = [];
      } else {
        this.offerDataService.offerTemplateId = this.offerTemplateId;
        const offers = this.offerDataService.getTemplateOffers(
          this.offerTemplateId
        );
        if (offers.length > 0) {
          this.dataSource.data = offers;
        } else {
          this.offerDataService
            .loadCampaignTemplateOffers(
              this.campaignsService.campaignId,
              this.offerTemplateId
            )
            .subscribe((offers) => {
              // console.log(offers);
              if (offers && offers.length > 0) {
                this.dataSource.data = offers;
              } else {
                this.dataSource.data = [];
              }
            });
        }
      }
      this.dataSource.sort = this.sort;
    }
  }

  formatParams(paramsObject: Param[]): string {
    let paramList = '';
    try {
      const params = paramsObject as Param[];
      params.forEach((param) => {
        if (paramList.length > 0) {
          paramList = paramList + '&';
        }
        paramList = paramList + param.Key + '=' + param.Value;
      });
    } catch (error) {
      console.log(error);
    }
    return paramList;
  }

  /**
   * @description Private method to create CampaignOfferType list with Id
   * @returns offerTypes
   */
  createOfferTypesList() {
    let i = 1;
    for (const offerType of Object.values(CampaignOfferType)) {
      this.offerTypes.push({ Name: offerType, OfferTypeId: i });
      i++;
    }
  }

  /**
   * @description Private method for filter offerType for name
   * @param offerTypeId
   * @returns
   */
  getOfferTypesListName(offerTypeId: number) {
    return this.offerTypes.filter(
      (offer: { Name: string; OfferTypeId: number }) =>
        offer.OfferTypeId === offerTypeId
    );
  }

  /***
   * @description Modal Dialog Box to add new offer
   */
  addOffer() {
    // Type defined multiple layout form template
    const TypeOfForm = 'AddRedirectOffer';
    //open model
    const dialogRef = this.dialog.open(CampaignOfferDetailComponent, {
      width: '600px',
      data: { name: this.campaign.campaignName, displayType: TypeOfForm }
    });

    dialogRef.componentInstance.saveClicked.subscribe((data) => {
      const message = `Offer ${data.name} was created successfully.`;
      // Need to set req object to pass Post simpleRedirectOffer
      const requestObject: IPostRedirectReqObject = {
        name: data.name,
        RedirectBaseUrl: data.redirectUrl,
        CampaignBrandTemplateId: '',
        UserDataCaptureTemplate: '2',
        CampaignOfferType: this.campaign.campaignOfferType,
        HttpRequestType: this.campaign.campaignOfferType.toString(),
        Active: data.Active,
        Params: [
          {
            Index: 1,
            Type: 1,
            Key: data.param1Key,
            Value: data.displayOfferId
          }
        ]
      };
      this.dialogueWithCreateCampaignRedirectOffer(requestObject, message);
    });
  }

  /***
   * @description Modal Dialog Box for View/Edit/Delete offer
   */
  offerDetails(row: IPutEditRedirectReqObject) {
    this.getDisplayOffers(row);
    // Type defined multiple layout form template
    const TypeOfForm = 'EditRedirectOffer';

    //open model
    const dialogRef = this.dialog.open(CampaignOfferDetailComponent, {
      width: '600px',
      data: {
        name: row.Name,
        displayType: TypeOfForm,
        offerType: this.campaign.campaignOfferType,
        editValue: row
      }
    });

    // If user Authorized
    const isAuthorized = this.authService.isAuthorized();

    if (isAuthorized) {
      dialogRef.componentInstance.saveClicked.subscribe((dataFrom) => {
        if (dataFrom.clicked === 'edit') {
          this.onUpdateOffer(row, dataFrom);
        }
        if (dataFrom.clicked === 'delete') {
          const message = `Are you sure want to delete Offer ${row.Name}?`;
          this.dialog
            .open(ConfirmationDialogComponent, {
              width: '300px',
              data: {
                message: message,
                header: 'Confirm Delete Offer',
                cancelBtnName: 'Close',
                confirmBtnName: 'Delete'
              }
            })
            .afterClosed()
            .subscribe((result) => {
              if (result) {
                this.onDeleteOffer(row, dataFrom);
              }
            });
        }
      });
    }
  }

  // When edit offer
  onUpdateOffer(row: IPutEditRedirectReqObject, data: IEditDeleteFormData) {
    const message = `${data.formValue.name} was successfully updated.`;
    // Need to set req object to pass Post simpleRedirectOffer
    const requestObject: IPutEditRedirectReqObject = {
      CampaignId: this.campaignsService.campaignId,
      OfferTemplateId: this.offerTemplateId,
      OfferId: row.OfferId,
      CampaignOfferType: this.campaign.campaignOfferType,
      HttpRequestType: this.campaign.campaignOfferType.toString(),
      Name: data.formValue.name,
      Active: data.formValue.activeCheckBox,
      RedirectBaseUrl: data.formValue.redirectUrl,
      Params: [
        {
          Index: 1,
          Type: 1,
          Key: data.formValue.param1Key,
          Value: data.formValue.displayOfferId
        }
      ],
      Expires: null,
      CouponPosCode: '',
      CouponTemplate: '',
      CouponExpiresText: '',
      UserDataCaptureTemplate: 'Redirect Offer',
      CampaignBrandTemplateId: 'Redirect Offer'
    };

    // If NOT "Redirect OffterType (used for other offertype)"
    const checkofferType = requestObject.CampaignOfferType;
    const currentCampaignOffer: string =
      this.getOfferTypesListName(checkofferType)[0].Name;

    if (currentCampaignOffer !== CampaignOfferType.SimpleRedirect) {
      requestObject['CouponPosCode'] = '';
      requestObject['CouponTemplate'] = '';
      requestObject['CouponExpiresText'] = '';
      requestObject['UserDataCaptureTemplate'] = 'Not Redirect Offer';
      requestObject['CampaignBrandTemplateId'] = 'Not Redirect Offer';
    }
    this.dialogueWithUpdateCampaignRedirectOffer(requestObject, message);
  }

  // When edit offer
  onDeleteOffer(row: IPutEditRedirectReqObject, data: IEditDeleteFormData) {
    // row['displayOffer'] = true;
    this.displayOfferDataService
      .deleteOffer(
        this.campaignsService.campaignId,
        row.OfferTemplateId,
        row.OfferId
      )
      .subscribe((res: any) => {
        const message = `${data.formValue.name} was successfully deleted.`;
        //open model to confirm user
        this.dialog
          .open(ConfirmationDialogComponent, {
            width: '300px',
            data: {
              message: message,
              header: '',
              cancelBtnName: '',
              confirmBtnName: 'OK'
            }
          })
          .afterClosed()
          .subscribe((result) => {
            console.info(result);
            this.offerDataService
              .loadCampaignTemplateOffers(
                this.campaignsService.campaignId,
                this.offerTemplateId
              )
              .subscribe((offers) => {
                if (offers && offers.length > 0) {
                  this.dataSource.data = offers;
                  this.sort.sort({
                    id: 'Name',
                    start: 'asc',
                    disableClear: false
                  });
                  this.dataSource.sort = this.sort;
                } else {
                  this.dataSource.data = [];
                }
              });
          });
      });
  }

  /***
   * @description Create new Redirect offer [+]
   * @param IPutEditRedirectReqObject
   * @param Name
   */
  dialogueWithCreateCampaignRedirectOffer(
    requestObject: IPostRedirectReqObject,
    message: string
  ) {
    this.offerDataService
      .postSimpleRedirectOffer(
        this.campaignsService.campaignId,
        this.offerTemplateId,
        requestObject
      )
      .subscribe((response: any) => {
        console.log(response);
        //open model to confirm user
        this.dialog
          .open(ConfirmationDialogComponent, {
            width: '300px',
            data: {
              message: message,
              header: '',
              cancelBtnName: 'Cancel',
              confirmBtnName: 'Ok'
            }
          })
          .afterClosed()
          .subscribe((result) => {
            if (result) {
              this.commService.setRedirectOffertypeFlag(true);
              // Read offer
              this.offerDataService
                .loadCampaignTemplateOffers(
                  this.campaignsService.campaignId,
                  this.offerTemplateId
                )
                .subscribe((offers) => {
                  if (offers && offers.length > 0) {
                    this.dataSource.data = offers;
                    this.sort.sort({
                      id: 'Name',
                      start: 'asc',
                      disableClear: false
                    });
                    this.dataSource.sort = this.sort;
                  } else {
                    this.dataSource.data = [];
                  }
                });
            }
          });
      });
  }

  /***
   * @description Update Redirect offer [View or Edit Purpose]
   * @param IPutEditRedirectReqObject
   * @param Name
   */
  dialogueWithUpdateCampaignRedirectOffer(
    requestObject: IPutEditRedirectReqObject,
    message: string
  ) {
    this.offerDataService
      .updateCampaignOffers(requestObject)
      .subscribe((response: IPutEditRedirectReqObject) => {
        console.log(response);
        //open model to confirm user
        this.dialog
          .open(ConfirmationDialogComponent, {
            width: '300px',
            data: {
              message: message,
              header: '',
              cancelBtnName: '',
              confirmBtnName: 'OK'
            }
          })
          .afterClosed()
          .subscribe((result) => {
            if (result) {
              // Read offer
              this.offerDataService
                .loadCampaignTemplateOffers(
                  this.campaignsService.campaignId,
                  this.offerTemplateId
                )
                .subscribe((offers) => {
                  if (offers && offers.length > 0) {
                    this.dataSource.data = offers;
                    this.sort.sort({
                      id: 'Name',
                      start: 'asc',
                      disableClear: false
                    });
                    this.dataSource.sort = this.sort;
                  } else {
                    this.dataSource.data = [];
                  }
                });
            }
          });
      });
  }

  /***
   * @description DisplayOffers for offers available in campaignOfferTable
   * @param campaignId
   * @param OfferTemplateId
   * @param OfferId
   */
  getDisplayOffers(row: any) {
    this.displayOfferDataService
      .loadDisplayOfferLinks(
        this.campaignsService.campaignId,
        row.OfferTemplateId,
        row.OfferId
      )
      .subscribe((displayOffers) => {
        if (displayOffers.length > 0) {
          row['displayOffer'] = true;
          return true;
        } else {
          row['displayOffer'] = false;
          return false;
        }
      });
  }
}
