import {
  AfterViewInit,
  Component,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { OfferTemplate } from 'src/app/models/offer/offer-template';
import { OfferDataService } from '../../services/offer-data.service';
import { CampaignsService } from '../campaigns.service';
import { CommonStoreService } from '../../services/common-store.service';

@Component({
  selector: 'app-campaign-offer-templates',
  templateUrl: './campaign-offer-templates.component.html',
  styleUrls: ['./campaign-offer-templates.component.scss']
})
export class CampaignOfferTemplatesComponent
  implements OnInit, AfterViewInit, OnChanges
{
  @Input() campaignId = '';
  displayedColumns: string[] = ['Name', 'Offer Type'];
  dataSource: MatTableDataSource<OfferTemplate>;

  selectedRowIndex = '';

  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    private offerDataService: OfferDataService,
    private campaignsService: CampaignsService,
    private commService: CommonStoreService
  ) {
    this.dataSource = new MatTableDataSource();
  }

  ngOnInit(): void {
    this.dataSource.data = this.offerDataService.getOfferTemplates(
      this.campaignId
    );
    this.dataSource.sort = this.sort;
    this.selectedRowIndex = this.campaignsService.offerTemplateName;
    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case 'Name':
          return item.Name;
        case 'Offer Type':
          return item.CampaignOfferType;
        default:
          return item.Name;
      }
    };
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes) {
      this.campaignId = changes['campaignId'].currentValue;
      if (!this.campaignId) {
        this.dataSource.data = [];
      } else {
        const offerTemplates = this.offerDataService.getOfferTemplates(
          this.campaignId
        );
        if (offerTemplates.length > 0) {
          this.dataSource.data = offerTemplates;
        } else {
          this.offerDataService
            .loadCampaignOfferTemplates(this.campaignId)
            .subscribe((templates) => {
              if (templates.length > 0) {
                this.offerDataService.offerTemplates =
                  this.offerDataService.offerTemplates.concat(templates);
                this.dataSource.data = this.offerDataService.getOfferTemplates(
                  this.campaignId
                );
              }
            });
        }
      }
      this.dataSource.sort = this.sort;
    }
  }

  offerTypeName(offerType: number): string {
    switch (offerType) {
      case 1:
        return 'Redirect';
      case 2:
        return 'Single Use Basic Coupon';
      case 3:
        return 'Capture Then Redirect';
      case 4:
        return 'Quick Connect';
      default:
        return 'N/A';
    }
  }

  selectTemplate(offerTemplate: OfferTemplate) {
    // Set flag for Simple Redirect offer based on Offertype clicked campain name in campaign list
    this.commService.setRedirectOffertypeValue({
      campaignName: offerTemplate.Name,
      campaignId: offerTemplate.CampaignId,
      offerTemplateId: offerTemplate.OfferTemplateId,
      campaignOfferType: offerTemplate.OfferType
    });
    this.campaignsService.campaignId = offerTemplate.CampaignId;
    if (offerTemplate.OfferType === 1) {
      this.commService.setRedirectOffertypeFlag(false);
    } else {
      this.commService.setRedirectOffertypeFlag(true);
    }
    this.selectedRowIndex = offerTemplate.Name;
    this.offerDataService.offerTemplateId = offerTemplate.OfferTemplateId;
    console.log('Selected OfferTemplate: ', offerTemplate);
  }
}
