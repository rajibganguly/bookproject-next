import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CampaignOfferTemplatesComponent } from './campaign-offer-templates.component';

describe('CampaignOfferTemplatesComponent', () => {
  let component: CampaignOfferTemplatesComponent;
  let fixture: ComponentFixture<CampaignOfferTemplatesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CampaignOfferTemplatesComponent]
    });
    fixture = TestBed.createComponent(CampaignOfferTemplatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
