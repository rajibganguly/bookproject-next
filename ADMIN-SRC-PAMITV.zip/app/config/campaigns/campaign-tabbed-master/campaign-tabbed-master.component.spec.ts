import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CampaignTabbedMasterComponent } from './campaign-tabbed-master.component';

describe('CampaignTabbedMasterComponent', () => {
  let component: CampaignTabbedMasterComponent;
  let fixture: ComponentFixture<CampaignTabbedMasterComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CampaignTabbedMasterComponent]
    });
    fixture = TestBed.createComponent(CampaignTabbedMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
