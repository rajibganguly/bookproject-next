import { Component, Input } from '@angular/core';
import { OfferDataService } from '../../services/offer-data.service';
import { CampaignsService } from '../campaigns.service';

@Component({
  selector: 'app-campaign-tabbed-master',
  templateUrl: './campaign-tabbed-master.component.html',
  styleUrls: ['./campaign-tabbed-master.component.scss']
})
export class CampaignTabbedMasterComponent {
  @Input() campaignId = '';
  constructor(
    public offerDataService: OfferDataService,
    public campaignsService: CampaignsService
  ) {}
}
