import { Component } from '@angular/core';
import { CampaignDataService } from '../../services/campaign-data.service';
import { OfferDataService } from '../../services/offer-data.service';
import { CampaignsService } from '../campaigns.service';
import { animate, style, transition, trigger } from '@angular/animations';

@Component({
  selector: 'app-campaigns-master',
  templateUrl: './campaigns-master.component.html',
  styleUrls: ['./campaigns-master.component.scss'],
  host: { class: 'fullscreen' },
  animations: [
    trigger('flyInOut', [
      transition(':enter', [
        style({ transform: 'translateX(100%)' }),
        animate(200),
      ]),
      transition(':leave', [
        animate(200, style({ transform: 'translateX(-100%)' })),
      ]),
    ]),
  ],
})
export class CampaignsMasterComponent {
  constructor(
    public campaignDataService: CampaignDataService,
    public offerDataService: OfferDataService,
    public campaignsService: CampaignsService
  ) {}
}
