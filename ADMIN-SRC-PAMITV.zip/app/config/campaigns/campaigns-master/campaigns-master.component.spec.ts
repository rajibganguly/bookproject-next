import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CampaignsMasterComponent } from './campaigns-master.component';

describe('CampaignsMasterComponent', () => {
  let component: CampaignsMasterComponent;
  let fixture: ComponentFixture<CampaignsMasterComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CampaignsMasterComponent]
    });
    fixture = TestBed.createComponent(CampaignsMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
