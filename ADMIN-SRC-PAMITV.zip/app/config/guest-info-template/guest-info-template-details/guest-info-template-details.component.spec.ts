import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GuestInfoTemplateDetailsComponent } from './guest-info-template-details.component';

describe('GuestInfoTemplateDetailsComponent', () => {
  let component: GuestInfoTemplateDetailsComponent;
  let fixture: ComponentFixture<GuestInfoTemplateDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GuestInfoTemplateDetailsComponent]
    });
    fixture = TestBed.createComponent(GuestInfoTemplateDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
