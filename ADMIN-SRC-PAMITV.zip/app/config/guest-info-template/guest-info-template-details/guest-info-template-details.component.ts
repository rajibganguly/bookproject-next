import {
  AfterViewInit,
  Component,
  Input,
  NgZone,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import {
  GuestDataTemplate,
  PromptedAttributes
} from 'src/app/models/guestDataTemplate/guestDataTemplate';
import { TemplatesDataService } from '../../services/templates-data.service';
import { MatTableDataSource } from '@angular/material/table';
import {
  GuestAttributeDataTypeMap,
  GuestAttributeFieldTypeMap
} from 'src/app/models/guestTemplate/guestAttributeDataType';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-guest-info-template-details',
  templateUrl: './guest-info-template-details.component.html',
  styleUrls: ['./guest-info-template-details.component.scss']
})
export class GuestInfoTemplateDetailsComponent
  implements OnChanges, OnInit, AfterViewInit
{
  @Input() guestDataTemplateId = '';

  @ViewChild(MatSort) sort!: MatSort;
  guestDataTemplate: GuestDataTemplate | undefined = undefined;
  brandTemplateDataTypeMap = GuestAttributeDataTypeMap;
  brandTemplateFieldTypeMap = GuestAttributeFieldTypeMap;
  dataSource: MatTableDataSource<PromptedAttributes>;
  displayedColumns: string[] = [
    'Display Order',
    'Label',
    'Placeholder',
    'GuestAttributeFieldType',
    'GuestAttributeDataType',
    'DataFieldName',
    'Required',
    'Options'
  ];
  constructor(
    private templateDataService: TemplatesDataService,
    private ngZone: NgZone
  ) {
    this.dataSource = new MatTableDataSource();
  }

  ngOnInit(): void {
    if (this.guestDataTemplateId !== '') {
      this.guestDataTemplate = this.templateDataService.getGuestDataTemplate(
        this.guestDataTemplateId
      );
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes) {
      this.guestDataTemplateId = changes['guestDataTemplateId'].currentValue;
      this.guestDataTemplate = this.templateDataService.getGuestDataTemplate(
        this.guestDataTemplateId
      );
      if (this.guestDataTemplate) {
        this.dataSource.data = this.guestDataTemplate?.PromptedAttributes;
        this.dataSource.sortingDataAccessor = (item, property) => {
          switch (property) {
            case 'Display Order':
              return item.DisplayOrder;
            case 'Label':
              return item.Label;
            case 'Placeholder':
              return item.Placeholder;
            case 'GuestAttributeFieldType':
              return item.GuestAttributeFieldType;
            case 'GuestAttributeDataType':
              return item.GuestAttributeDataType;
            case 'DataFieldName':
              return item.DataFieldName;
            default:
              return item.DisplayOrder;
          }
        };
      }

      console.log(this.dataSource.data);
    }
  }
  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.ngZone.runOutsideAngular(() => {
      setTimeout(() => {
        this.sort.sort({
          id: 'DisplayOrder',
          start: 'asc',
          disableClear: false
        });
        this.dataSource.sort = this.sort;
      });
    });
  }
}
