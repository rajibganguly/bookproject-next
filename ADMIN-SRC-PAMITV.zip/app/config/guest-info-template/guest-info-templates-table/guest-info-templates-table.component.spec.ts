import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GuestInfoTemplatesTableComponent } from './guest-info-templates-table.component';

describe('GuestTemplatesTableComponent', () => {
  let component: GuestInfoTemplatesTableComponent;
  let fixture: ComponentFixture<GuestInfoTemplatesTableComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GuestInfoTemplatesTableComponent]
    });
    fixture = TestBed.createComponent(GuestInfoTemplatesTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
