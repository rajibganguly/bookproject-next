import { Component, OnInit, ViewChild } from '@angular/core';
import { TemplatesDataService } from '../../services/templates-data.service';
import { GuestDataTemplate } from 'src/app/models/guestDataTemplate/guestDataTemplate';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-guest-info-templates-table',
  templateUrl: './guest-info-templates-table.component.html',
  styleUrls: ['./guest-info-templates-table.component.scss']
})
export class GuestInfoTemplatesTableComponent implements OnInit {
  displayedColumns: string[] = ['Name', 'Description'];
  dataSource: MatTableDataSource<GuestDataTemplate>;
  selectedRowIndex = '-1';
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private templateDataService: TemplatesDataService) {
    this.dataSource = new MatTableDataSource();
  }

  ngOnInit(): void {
    if (!this.templateDataService.guestDataTemplates) {
      this.loadGuestDataTemplates();
    } else {
      this.dataSource = new MatTableDataSource(
        this.templateDataService.guestDataTemplates
      );
    }
    this.sortData();
  }

  sortData() {
    this.dataSource.sort = this.sort;
    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case 'name':
          return item.Name;
        case 'city':
          return item.Description;
        default:
          return item.Name;
      }
    };
  }
  loadGuestDataTemplates() {
    this.templateDataService.getGuestDataTemplates().subscribe((templates) => {
      this.templateDataService.guestDataTemplates = templates;
      this.dataSource = new MatTableDataSource(templates);
      this.sortData();
      console.log(this.dataSource.data);
    });
  }
  handleRowClick(id: string) {
    this.selectedRowIndex = id;
    this.templateDataService.guestDataTemplateId = id;
  }
}
