import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GuestInfoTemplateMasterComponent } from './guest-info-template-master.component';

describe('GuestTemplateMasterComponent', () => {
  let component: GuestInfoTemplateMasterComponent;
  let fixture: ComponentFixture<GuestInfoTemplateMasterComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GuestInfoTemplateMasterComponent]
    });
    fixture = TestBed.createComponent(GuestInfoTemplateMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
