import { Component } from '@angular/core';
import { TemplatesDataService } from '../../services/templates-data.service';

@Component({
  selector: 'app-info-guest-template-master',
  templateUrl: './guest-info-template-master.component.html',
  styleUrls: ['./guest-info-template-master.component.scss']
})
export class GuestInfoTemplateMasterComponent {
  constructor(public templateDataService: TemplatesDataService) {}
}
