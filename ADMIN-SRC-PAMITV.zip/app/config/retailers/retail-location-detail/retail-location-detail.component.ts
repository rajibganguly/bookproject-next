import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RetailLocation } from 'src/app/models/retailer/retailLocation';
import { RetailersService } from '../retailers.service';
import { RetailerDataService } from '../../services/retailer-data.service';

@Component({
  selector: 'app-retail-location-detail',
  templateUrl: './retail-location-detail.component.html',
  styleUrls: ['./retail-location-detail.component.scss']
})
export class RetailLocationDetailComponent implements OnInit {
  @Input() retailLocation!: RetailLocation;
  retailLocationForm!: FormGroup;
  @Output() retailLocationEvent = new EventEmitter<RetailLocation | null>();
  constructor(
    private fb: FormBuilder,
    public retailersService: RetailersService,
    private retailerDataService: RetailerDataService
  ) {}

  ngOnInit(): void {
    this.initForm();
  }

  initForm() {
    this.retailLocationForm = this.fb.group({
      locationName: [this.retailLocation.Name, Validators.required],
      unitNumber: [this.retailLocation.RetailerUnitId],
      addressLine1: [
        this.retailLocation.StreetAddress.Address1,
        Validators.required
      ],
      addressLine2: [this.retailLocation.StreetAddress.Address2],
      city: [this.retailLocation.StreetAddress.City, Validators.required],
      state: [this.retailLocation.StreetAddress.State, Validators.required],
      postalCode: [
        this.retailLocation.StreetAddress.PostalCode,
        Validators.required
      ],
      phoneNumber: [this.retailLocation.Phone1, Validators.required],
      displayNumber1: [
        this.retailLocation?.RetailDisplays[0]?.RetailDisplayId,
        Validators.required
      ],
      displayNumber2: [''],
      displayNumber3: [''],
      displayNumber4: ['']
    });
    this.retailerDataService
      .loadLocationDisplays(
        this.retailLocation.RetailerId,
        this.retailLocation.RetailLocationId
      )
      .subscribe((retailDisplays) => {
        retailDisplays.forEach((display, index) => {
          if (display.DisplayId) {
            this.retailLocationForm.controls[
              `displayNumber${index + 1}`
            ].setValue(display.DisplayId);
          }
        });
      });
  }

  onAddLocation() {
    this.retailLocation.Name = this.retailLocationForm.value['locationName'];
    this.retailLocation.RetailerUnitId =
      this.retailLocationForm.value['unitNumber'];
    this.retailLocation.StreetAddress.Address1 =
      this.retailLocationForm.value['addressLine1'];
    this.retailLocation.StreetAddress.Address2 =
      this.retailLocationForm.value['addressLine2'];
    this.retailLocation.StreetAddress.City =
      this.retailLocationForm.value['city'];
    this.retailLocation.StreetAddress.State =
      this.retailLocationForm.value['state'];
    this.retailLocation.StreetAddress.PostalCode =
      this.retailLocationForm.value['postalCode'];
    this.retailLocation.Phone1 = this.retailLocationForm.value['phoneNumber'];
    if (this.retailLocationForm.value['displayNumber1'].trim()) {
      this.retailLocation.RetailDisplays.push(
        this.retailersService.newRetailDisplay(
          this.retailLocationForm.value['displayNumber1'].trim()
        )
      );
    }
    if (this.retailLocationForm.value['displayNumber2'].trim()) {
      this.retailLocation.RetailDisplays.push(
        this.retailersService.newRetailDisplay(
          this.retailLocationForm.value['displayNumber2'].trim()
        )
      );
    }
    if (this.retailLocationForm.value['displayNumber3'].trim()) {
      this.retailLocation.RetailDisplays.push(
        this.retailersService.newRetailDisplay(
          this.retailLocationForm.value['displayNumber3'].trim()
        )
      );
    }
    if (this.retailLocationForm.value['displayNumber4'].trim()) {
      this.retailLocation.RetailDisplays.push(
        this.retailersService.newRetailDisplay(
          this.retailLocationForm.value['displayNumber4'].trim()
        )
      );
    }
    this.retailLocationEvent.emit(this.retailLocation);
  }

  cancel() {
    this.retailLocationEvent.emit(null);
    this.initForm();
  }
}
