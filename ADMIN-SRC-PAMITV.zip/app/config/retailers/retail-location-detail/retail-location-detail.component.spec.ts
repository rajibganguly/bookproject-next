import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailLocationDetailComponent } from './retail-location-detail.component';

describe('RetailLocationDetailComponent', () => {
  let component: RetailLocationDetailComponent;
  let fixture: ComponentFixture<RetailLocationDetailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RetailLocationDetailComponent]
    });
    fixture = TestBed.createComponent(RetailLocationDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
