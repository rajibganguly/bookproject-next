import {
  AfterViewInit,
  Component,
  Input,
  NgZone,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { RetailerDataService } from '../../services/retailer-data.service';
import { RetailDisplay } from 'src/app/models/retailer/retailDisplay';
import { RetailersService } from '../retailers.service';
import { forkJoin } from 'rxjs';
import { DisplayOfferDataService } from '../../services/displayOffer-data.service';

@Component({
  selector: 'app-retail-displays-table',
  templateUrl: './retail-displays-table.component.html',
  styleUrls: ['./retail-displays-table.component.scss']
})
export class RetailDisplaysTableComponent
  implements OnInit, AfterViewInit, OnChanges
{
  @Input() retailLocationId: any = undefined;
  displayedColumns: string[] = ['Id', 'Desc'];
  dataSource: MatTableDataSource<RetailDisplay>;
  @Input() selectedRowIndex: any = undefined;

  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    private retailerDataService: RetailerDataService,
    private retailersService: RetailersService,
    private displayOfferDataService: DisplayOfferDataService,
    private ngZone: NgZone
  ) {
    this.dataSource = new MatTableDataSource();
  }

  ngOnInit(): void {
    this.dataSource.data = this.retailerDataService.getRetailDisplays(
      this.retailLocationId
    );
    this.dataSource.sort = this.sort;
    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case 'Id':
          return item.DisplayId;
        case 'Desc':
          return item.Description;
        default:
          return item.DisplayId;
      }
    };
    this.selectedRowIndex = this.retailersService.retailDisplayId;
  }

  ngAfterViewInit(): void {
    this.ngZone.runOutsideAngular(() => {
      setTimeout(() => {
        this.sort.sort({ id: 'Id', start: 'asc', disableClear: false });
        this.dataSource.sort = this.sort;
        this.selectedRowIndex = this.retailersService.retailDisplayId;
      });
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes) {
      if (changes['retailLocationId']) {
        this.selectedRowIndex = this.retailersService.retailDisplayId;
        this.retailLocationId = changes['retailLocationId'].currentValue;
        if (!this.retailLocationId) {
          this.dataSource.data = [];
        } else {
          this.loadDisplaysAndAssociatedOffers();

          this.dataSource.sort = this.sort;
        }
      } else {
        this.selectedRowIndex = this.retailersService.retailDisplayId;
      }
    }
  }

  loadDisplaysAndAssociatedOffers() {
    this.retailerDataService
      .loadLocationDisplays(
        this.retailersService.retailerId,
        this.retailLocationId
      )
      .subscribe((displays) => {
        this.retailerDataService.retailDisplays.push(...displays);
        this.retailerDataService.retailDisplays = this.filterUniqueResults(
          this.retailerDataService.retailDisplays
        );
        this.dataSource.data = this.retailerDataService.getRetailDisplays(
          this.retailLocationId
        );

        const requests = displays.map((display) =>
          this.retailerDataService.loadLocationDisplayOfferLinks(
            this.retailersService.retailerId,
            this.retailLocationId,
            display.RetailDisplayId
          )
        );

        forkJoin(requests).subscribe((results) => {
          results.forEach((result) => {
            this.displayOfferDataService.displayOfferLinks.push(...result);
            this.displayOfferDataService.displayOfferLinks =
              this.filterUniqueResults(
                this.displayOfferDataService.displayOfferLinks
              );
          });
        });
      });
  }

  filterUniqueResults(results: any[]): any[] {
    const uniqueResultsSet = new Set();
    return results.filter((result) => {
      const serializedResult = JSON.stringify(result);
      if (!uniqueResultsSet.has(serializedResult)) {
        uniqueResultsSet.add(serializedResult);
        return true;
      }
      return false;
    });
  }

  selectDisplay(retailDisplay: RetailDisplay) {
    this.selectedRowIndex = retailDisplay.RetailDisplayId;
    this.retailersService.retailDisplayId = retailDisplay.RetailDisplayId;
    console.log('Selected Display: ' + this.retailersService.retailDisplayId);
  }
}
