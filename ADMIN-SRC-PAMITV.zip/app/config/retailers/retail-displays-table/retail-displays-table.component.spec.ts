import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailDisplaysTableComponent } from './retail-displays-table.component';

describe('RetailDisplaysTableComponent', () => {
  let component: RetailDisplaysTableComponent;
  let fixture: ComponentFixture<RetailDisplaysTableComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RetailDisplaysTableComponent]
    });
    fixture = TestBed.createComponent(RetailDisplaysTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
