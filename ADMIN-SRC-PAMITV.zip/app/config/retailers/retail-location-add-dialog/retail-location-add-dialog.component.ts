import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ApplyOfferConfirmationDialogComponent } from '../apply-offer-confirmation-dialog/apply-offer-confirmation-dialog.component';
import { RetailLocation } from 'src/app/models/retailer/retailLocation';
import { StreetAddress } from 'src/app/models/address/streetAddress';
import { FormBuilder, FormGroup } from '@angular/forms';
import { RetailersService } from '../retailers.service';

@Component({
  selector: 'app-retail-location-add-dialog',
  templateUrl: './retail-location-add-dialog.component.html',
  styleUrls: ['./retail-location-add-dialog.component.scss']
})
export class RetailLocationAddDialogComponent {
  retailLocation: RetailLocation;
  retailLocationForm!: FormGroup;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { retailerId: string },
    private dialogRef: MatDialogRef<ApplyOfferConfirmationDialogComponent>,
    private fb: FormBuilder,
    private retailersService: RetailersService
  ) {
    retailersService.showRetailLocationAdd = true;
    const retailerId = data.retailerId;
    const address = new StreetAddress('', '', '', '', '', '');
    this.retailLocation = new RetailLocation(
      '',
      '',
      '',
      retailerId,
      address,
      '',
      true,
      []
    );
  }
  onAddLocation(retailerLocation: RetailLocation | null) {
    this.dialogRef.close(retailerLocation);
    this.retailersService.showRetailLocationAdd = false;
  }

  cancel() {
    this.dialogRef.close();
    this.retailersService.showRetailLocationAdd = false;
  }
}
