import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailLocationAddDialogComponent } from './retail-location-add-dialog.component';

describe('RetailLocationAddDialogComponent', () => {
  let component: RetailLocationAddDialogComponent;
  let fixture: ComponentFixture<RetailLocationAddDialogComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RetailLocationAddDialogComponent]
    });
    fixture = TestBed.createComponent(RetailLocationAddDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
