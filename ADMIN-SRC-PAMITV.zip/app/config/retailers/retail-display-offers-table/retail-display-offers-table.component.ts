import {
  AfterViewInit,
  Component,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { DisplayOfferDataService } from '../../services/displayOffer-data.service';
import { RetailDisplayOfferDetail } from './retail-display-offer-detail';
import { RetailersService } from '../retailers.service';
import { AdvertiserDataService } from '../../services/advertiser-data.service';
import { MatDialog } from '@angular/material/dialog';
import { RetailDisplayOfferDetailComponent } from '../retail-display-offer-detail/retail-display-offer-detail.component';
import { RetailerDataService } from '../../services/retailer-data.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-retail-display-offers-table',
  templateUrl: './retail-display-offers-table.component.html',
  styleUrls: ['./retail-display-offers-table.component.scss']
})
export class RetailDisplayOffersTableComponent
  implements OnInit, AfterViewInit, OnChanges, OnDestroy
{
  @Input() retailerId: any = undefined;
  @Input() retailLocationId: any = undefined;
  @Input() retailDisplayId: any = undefined;
  displayedColumns: string[] = ['CampaignName', 'OfferName'];
  dataSource: MatTableDataSource<RetailDisplayOfferDetail>;
  loading = false;
  selectedRowIndex: any = undefined;
  private displaySubscription: Subscription;

  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    private advertiserDataService: AdvertiserDataService,
    private retailerDataService: RetailerDataService,
    private dialog: MatDialog,
    private retailersService: RetailersService
  ) {
    this.dataSource = new MatTableDataSource();
    this.displaySubscription =
      this.retailersService.displayOffersCreated.subscribe(() => {
        this.retailersService
          .getDisplayOfferDetail(
            this.retailerId,
            this.retailLocationId,
            this.retailDisplayId
          )
          .subscribe(
            (data) => {
              this.dataSource.data = data;
              this.loading = false;
            },
            (error) => {
              this.loading = false;
            },
            () => {
              this.loading = false;
            }
          );
      });
  }

  ngOnInit(): void {
    this.loading = true;
    this.dataSource.data = [];
    this.retailersService
      .getDisplayOfferDetail(
        this.retailerId,
        this.retailLocationId,
        this.retailDisplayId
      )
      .subscribe(
        (data) => {
          this.dataSource.data = data;
          this.loading = false;
        },
        (error) => {
          this.loading = false;
        },
        () => {
          this.loading = false;
        }
      );
    this.dataSource.sort = this.sort;

    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case 'CampaignName':
          return item.CampaignName;
        case 'OfferName':
          return item.OfferName;
        default:
          return item.CampaignId;
      }
    };
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
  }

  ngOnDestroy() {
    this.displaySubscription.unsubscribe();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes) {
      if (Object.prototype.hasOwnProperty.call(changes, 'retailerId')) {
        this.retailerId = changes['retailerId'].currentValue;
        this.retailDisplayId = '';
      }
      if (Object.prototype.hasOwnProperty.call(changes, 'retailLocationId')) {
        this.retailLocationId = changes['retailLocationId'].currentValue;
        this.retailDisplayId = '';
      }
      if (Object.prototype.hasOwnProperty.call(changes, 'retailDisplayId')) {
        this.retailDisplayId = changes['retailDisplayId'].currentValue;
      }
      this.loading = true;
      this.dataSource.data = [];
      this.retailersService
        .getDisplayOfferDetail(
          this.retailerId,
          this.retailLocationId,
          this.retailDisplayId
        )
        .subscribe(
          (data) => {
            this.dataSource.data = data;
            this.loading = false;
          },
          (error) => {
            this.loading = false;
          },
          () => {
            this.loading = false;
          }
        );
      this.dataSource.sort = this.sort;
    }
  }

  onRowClick(selectedDisplayOffer: RetailDisplayOfferDetail) {
    this.selectedRowIndex = selectedDisplayOffer.DisplayOfferId;
    const advertiser = this.advertiserDataService.getAdvertiser(
      selectedDisplayOffer.AdvertiserId
    );
    if (advertiser) selectedDisplayOffer.AdvertiserName = advertiser.Name;
    const retailer = this.retailerDataService.getRetailer(
      selectedDisplayOffer.RetailerId
    );
    if (retailer) selectedDisplayOffer.RetailerName = retailer.Name;
    const retailLocation = this.retailerDataService.getRetailLocation(
      selectedDisplayOffer.RetailLocationId
    );
    if (retailLocation) {
      selectedDisplayOffer.RetailLocationName =
        retailLocation.Name +
        ', ' +
        retailLocation.StreetAddress.City +
        ', ' +
        retailLocation.StreetAddress.State;
      selectedDisplayOffer.RetailLocationUnitId = retailLocation.RetailerUnitId;
    }
    this.dialog
      .open(RetailDisplayOfferDetailComponent, {
        width: '800px',
        data: { displayOffer: selectedDisplayOffer }
      })
      .afterClosed();
  }
}
