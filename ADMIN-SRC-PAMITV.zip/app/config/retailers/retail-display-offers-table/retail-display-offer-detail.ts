export class RetailDisplayOfferDetail {
  public RetailDisplayId: string = '';
  public DisplayId: string = '';
  public DisplayOfferId: string = '';
  public OfferId: string = '';
  public OfferName: string = '';
  public CampaignId: string = '';
  public CampaignName: string = '';
  public AdvertiserId: string = '';
  public AdvertiserName: string = '';
  public RetailerId: string = '';
  public RetailerName: string = '';
  public RetailLocationName: string = '';
  public RetailLocationId: string = '';
  public RetailLocationUnitId: string = '';
  public AdAgencyId: string = '';
  public AdAgencyName: string = '';
  public RedirectUrl: string = '';
  public QrCodeUrl: string = '';
  public Enabled: boolean = false;

  constructor(initialValues?: Partial<RetailDisplayOfferDetail>) {
    if (initialValues) {
      Object.assign(this, initialValues);
    }
  }
}
