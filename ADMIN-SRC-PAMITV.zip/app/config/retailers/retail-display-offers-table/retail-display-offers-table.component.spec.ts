import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailDisplayOffersTableComponent } from './retail-display-offers-table.component';

describe('RetailDisplayOffersTableComponent', () => {
  let component: RetailDisplayOffersTableComponent;
  let fixture: ComponentFixture<RetailDisplayOffersTableComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RetailDisplayOffersTableComponent]
    });
    fixture = TestBed.createComponent(RetailDisplayOffersTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
