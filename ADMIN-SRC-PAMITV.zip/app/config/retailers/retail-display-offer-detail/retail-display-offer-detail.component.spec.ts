import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailDisplayOfferDetailComponent } from './retail-display-offer-detail.component';

describe('RetailDisplayOfferDetailComponent', () => {
  let component: RetailDisplayOfferDetailComponent;
  let fixture: ComponentFixture<RetailDisplayOfferDetailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RetailDisplayOfferDetailComponent]
    });
    fixture = TestBed.createComponent(RetailDisplayOfferDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
