import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Clipboard } from '@angular/cdk/clipboard';
import { RetailDisplayOfferDetail } from '../retail-display-offers-table/retail-display-offer-detail';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-retail-display-offer-detail',
  templateUrl: './retail-display-offer-detail.component.html',
  styleUrls: ['./retail-display-offer-detail.component.scss']
})
export class RetailDisplayOfferDetailComponent {
  constructor(
    @Inject(MAT_DIALOG_DATA)
    public data: { displayOffer: RetailDisplayOfferDetail },
    private dialogRef: MatDialogRef<RetailDisplayOfferDetailComponent>,
    private clipboard: Clipboard,
    private httpClient: HttpClient
  ) {}

  copyToClipboard(value: string) {
    this.clipboard.copy(value);
  }

  qrCodeUrl(selected: RetailDisplayOfferDetail): string {
    return selected.QrCodeUrl;
  }
  onDownload(img: string) {
    const imgUrl = img;
    const displayId = this.data.displayOffer.DisplayId.replaceAll(' ', '_');
    const offerName = this.data.displayOffer.OfferName.replaceAll(' ', '_');
    const _img = img.split('.');
    const imgName = `${displayId}-${offerName}.${_img[_img.length - 1]}`;
    this.httpClient
      .get(imgUrl, { responseType: 'blob' as 'json' })
      .subscribe((res) => {
        const file = new Blob([res as Blob], { type: (res as Blob).type });

        const blob = window.URL.createObjectURL(file);
        const link = document.createElement('a');
        link.href = blob;
        link.download = imgName;

        // Version link.click() to work on firefox
        link.dispatchEvent(
          new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window
          })
        );
        setTimeout(() => {
          window.URL.revokeObjectURL(blob);
          link.remove();
        }, 100);
      });
  }
}
