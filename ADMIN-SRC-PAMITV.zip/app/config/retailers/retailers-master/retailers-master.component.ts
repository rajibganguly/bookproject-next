import { Component } from '@angular/core';
import { RetailerDataService } from '../../services/retailer-data.service';
import { RetailersService } from '../retailers.service';
import { animate, style, transition, trigger } from '@angular/animations';

@Component({
  selector: 'app-retailers-master',
  templateUrl: './retailers-master.component.html',
  styleUrls: ['./retailers-master.component.scss'],
  host: { class: 'fullscreen' },
  animations: [
    trigger('flyInOut', [
      transition(':enter', [
        style({ transform: 'translateX(100%)' }),
        animate(200),
      ]),
      transition(':leave', [
        animate(200, style({ transform: 'translateX(-100%)' })),
      ]),
    ]),
  ],
})
export class RetailersMasterComponent {
  constructor(
    public retailerDataService: RetailerDataService,
    public retailersService: RetailersService
  ) {}
}
