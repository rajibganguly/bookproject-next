import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailersMasterComponent } from './retailers-master.component';

describe('RetailersMasterComponent', () => {
  let component: RetailersMasterComponent;
  let fixture: ComponentFixture<RetailersMasterComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RetailersMasterComponent]
    });
    fixture = TestBed.createComponent(RetailersMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
