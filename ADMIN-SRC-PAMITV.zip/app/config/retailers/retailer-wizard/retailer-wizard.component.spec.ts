import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailerWizardComponent } from './retailer-wizard.component';

describe('RetailerWizardComponent', () => {
  let component: RetailerWizardComponent;
  let fixture: ComponentFixture<RetailerWizardComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RetailerWizardComponent]
    });
    fixture = TestBed.createComponent(RetailerWizardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
