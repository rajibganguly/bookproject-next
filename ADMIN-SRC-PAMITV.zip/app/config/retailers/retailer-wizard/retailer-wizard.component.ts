import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { StreetAddress } from 'src/app/models/address/streetAddress';
import { RetailLocation } from 'src/app/models/retailer/retailLocation';
import { Retailer } from 'src/app/models/retailer/retailer';
import { Observable, forkJoin, map, switchMap } from 'rxjs';
import { RetailerDataService } from '../../services/retailer-data.service';
import { RetailersService } from '../retailers.service';
import { Router } from '@angular/router';
import { ConfirmationDialogComponent } from 'src/app/core/confirmation-dialog/confirmation-dialog.component';
import { animate, style, transition, trigger } from '@angular/animations';
import { filterPhoneNumber } from '../../../core/phone-number-functions';
import { PhoneNumberFormatPipe } from 'src/app/core/phone-number-format.pipe';
import { CampaignDataService } from '../../services/campaign-data.service';

@Component({
  selector: 'app-retailer-wizard',
  templateUrl: './retailer-wizard.component.html',
  styleUrls: ['./retailer-wizard.component.scss'],
  animations: [
    trigger('flyInOut', [
      transition(':enter', [
        style({ transform: 'translateX(100%)' }),
        animate(200)
      ]),
      transition(':leave', [
        animate(200, style({ transform: 'translateX(-100%)' }))
      ])
    ])
  ]
})
export class RetailerWizardComponent implements OnInit {
  retailerForm!: FormGroup;
  locationsForm!: FormGroup;
  locationCount = 1;
  retailer!: Retailer;

  constructor(
    private fb: FormBuilder,
    private dialog: MatDialog,
    private retailerDataService: RetailerDataService,
    private retailersService: RetailersService,
    private router: Router,
    private phoneNumberFormat: PhoneNumberFormatPipe,
    private campaignDataService: CampaignDataService
  ) {}

  ngOnInit() {
    this.retailerForm = this.fb.group({
      retailerName: ['', Validators.required],
      description: [''],
      phoneNumber: ['', Validators.required],
      addressLine1: ['', Validators.required],
      addressLine2: [''],
      city: ['', Validators.required],
      state: ['', Validators.required],
      postalCode: ['', Validators.required],
      locationCount: [
        this.locationCount,
        [Validators.required, Validators.pattern(/^\d+$/)]
      ]
    });

    this.locationsForm = this.fb.group({
      phoneNumber: this.retailerForm.value.phoneNumber,
      locationControls: this.fb.array([])
    });
  }

  get locationControls() {
    return this.locationsForm.get('locationControls') as FormArray;
  }

  cancelWizard() {
    this.retailersService.displayWizard = false;
    this.router.navigate(['Retailers']);
  }

  addLocation(retailLocation: RetailLocation) {
    const locationGroup = this.fb.group({
      locationName: [retailLocation.Name, Validators.required],
      unitNumber: [retailLocation.RetailerUnitId],
      addressLine1: [
        retailLocation.StreetAddress.Address1,
        Validators.required
      ],
      addressLine2: [retailLocation.StreetAddress.Address2],
      city: [retailLocation.StreetAddress.City, Validators.required],
      state: [retailLocation.StreetAddress.State, Validators.required],
      postalCode: [
        retailLocation.StreetAddress.PostalCode,
        Validators.required
      ],
      phoneNumber: [
        this.phoneNumberFormat.transform(retailLocation.Phone1),
        Validators.required
      ],
      displayNumber1: ['', Validators.required],
      displayNumber2: [''],
      displayNumber3: [''],
      displayNumber4: ['']
    });
    this.locationControls.push(locationGroup);
  }

  onWizardPage1Next() {
    this.locationCount = parseInt(this.retailerForm.value['locationCount'], 10);
    if (
      this.locationCount >= 1 &&
      this.locationCount > this.locationControls.controls.length
    ) {
      for (
        let i = this.locationControls.controls.length;
        i < this.locationCount;
        i++
      ) {
        if (i == 0) {
          const streetAddress = new StreetAddress(
            this.retailerForm.value['addressLine1'],
            this.retailerForm.value['addressLine2'],
            this.retailerForm.value['city'],
            this.retailerForm.value['state'],
            this.retailerForm.value['postalCode'],
            ''
          );

          const retailLocation = new RetailLocation(
            '',
            this.retailerForm.value['retailerName'],
            '',
            '',
            streetAddress,
            filterPhoneNumber(this.retailerForm.value['phoneNumber']),
            true,
            []
          );
          this.addLocation(retailLocation);
        } else {
          const streetAddress = new StreetAddress('', '', '', '', '', '');
          const retailLocation = new RetailLocation(
            '',
            '',
            '',
            '',
            streetAddress,
            '',
            true,
            []
          );
          this.addLocation(retailLocation);
        }
      }
    }
  }

  onFinalStep() {
    this.retailer = this.buildRetailerData();
    const locCount = this.retailer.RetailLocations.length;
    let dispCount = 0;
    this.retailer.RetailLocations.forEach((location) => {
      dispCount = dispCount + location.RetailDisplays.length;
    });
    const message = `Add ${locCount} locations and ${dispCount} total displays?`;
    this.dialog
      .open(ConfirmationDialogComponent, {
        width: '300px',
        data: {
          message: message,
          header: 'Confirm Action',
          cancelBtnName: 'Cancel',
          confirmBtnName: 'Confirm'
        }
      })
      .afterClosed()
      .subscribe((result) => {
        if (result) {
          this.createRetailerElements();
        }
      });
  }

  createRetailerAndLocations(retailer: Retailer): Observable<Retailer> {
    console.log('createRetailerAndLocations', retailer);
    return this.retailerDataService.postRetailer(retailer).pipe(
      switchMap((createRetailerResp) => {
        this.campaignDataService.retailerId = createRetailerResp.RetailerId;
        this.campaignDataService.retailerName = createRetailerResp.Name;
        retailer.RetailerId = createRetailerResp.RetailerId;
        this.retailersService.retailerId = createRetailerResp.RetailerId;
        const locationRequests: Observable<any>[] = [];
        retailer.RetailLocations.forEach((location) => {
          locationRequests.push(
            this.retailerDataService.postRetailLocation(
              retailer.RetailerId,
              location
            )
          );
        });

        return forkJoin(locationRequests).pipe(
          map((locationResponses) => {
            let i = 0;
            locationResponses.forEach((locationResponse) => {
              if (i == 0) {
                this.retailersService.retailLocationId =
                  locationResponse.RetailLocationId;
                this.retailersService.locationName = locationResponse.Name;
              }
              if (locationResponse && locationResponse.RetailLocationId) {
                retailer.RetailLocations[i].RetailerId =
                  locationResponse.RetailerId;
                retailer.RetailLocations[i].RetailLocationId =
                  locationResponse.RetailLocationId;
              }
              i++;
            });
            return retailer;
          })
        );
      })
    );
  }

  createRetailerLocationsDisplays(retailer: Retailer): Observable<Retailer> {
    return this.createRetailerAndLocations(retailer).pipe(
      switchMap((updatedRetailer) => {
        const displayRequests: Observable<any>[] = [];
        updatedRetailer.RetailLocations.forEach((location) => {
          console.log('location->', location);
          location.RetailDisplays.forEach((retailDisplay) => {
            console.log('Display->', retailDisplay);
            this.retailersService.retailDisplayId =
              retailDisplay.RetailDisplayId;
            displayRequests.push(
              this.retailerDataService.postRetailDisplay(
                retailer.RetailerId,
                location.RetailLocationId,
                retailDisplay
              )
            );
          });
        });

        return forkJoin(displayRequests).pipe(
          map((displayResponses) => {
            let i = 0;
            updatedRetailer.RetailLocations.forEach((location) => {
              location.RetailDisplays.forEach((retailDisplay) => {
                if (i == 0) {
                  this.retailersService.retailDisplayId =
                    retailDisplay.RetailDisplayId;
                }
                retailDisplay.RetailDisplayId =
                  displayResponses[i].RetailDisplayId;
                retailDisplay.RetailLocationId =
                  displayResponses[i].RetailLocationId;
                i++;
              });
            });
            return updatedRetailer;
          })
        );
      })
    );
  }

  createRetailerElements() {
    console.log('createRetailerElements', this.retailer);
    this.createRetailerLocationsDisplays(this.retailer).subscribe(
      (finalRetailer) => {
        this.retailer = finalRetailer;
        console.log('FinalRetailer', this.retailer);
        this.retailerDataService.retailers.push(this.retailer);
        this.retailer.RetailLocations.forEach((location) => {
          this.retailerDataService.retailLocations.push(location);
        });
        this.retailersService.displayWizard = false;
        console.log('createRetailerElementsFINAL', this.retailer);
        this.retailersService.retailerName = finalRetailer.Name;
        this.retailersService.showRetailerSuccessModal = true;
        this.router.navigate(['Retailers']);
      },
      (error) => {
        console.log('createRetailerElements', error);
      }
    );
  }

  buildRetailerData(): Retailer {
    const streetAddress = new StreetAddress(
      this.retailerForm.value['addressLine1'],
      this.retailerForm.value['addressLine2'],
      this.retailerForm.value['city'],
      this.retailerForm.value['state'],
      this.retailerForm.value['postalCode'],
      ''
    );
    const retailer = new Retailer(
      this.retailerForm.value['retailerName'],
      this.retailerForm.value['description'],
      '',
      streetAddress,
      filterPhoneNumber(this.retailerForm.value['phoneNumber']),
      true,
      [],
      ''
    );

    this.locationControls.controls.forEach((locationForm) => {
      const name = locationForm.value['locationName'];
      const unitNumber = locationForm.value['unitNumber'];
      const streetAddress = new StreetAddress(
        locationForm.value['addressLine1'],
        locationForm.value['addressLine2'],
        locationForm.value['city'],
        locationForm.value['state'],
        locationForm.value['postalCode'],
        ''
      );
      const retailLocation = new RetailLocation(
        '',
        name,
        unitNumber,
        '',
        streetAddress,
        filterPhoneNumber(locationForm.value['phoneNumber']),
        true,
        []
      );
      if (locationForm.value['displayNumber1'].trim()) {
        retailLocation.RetailDisplays.push(
          this.retailersService.newRetailDisplay(
            locationForm.value['displayNumber1'].trim()
          )
        );
      }
      if (locationForm.value['displayNumber2'].trim()) {
        retailLocation.RetailDisplays.push(
          this.retailersService.newRetailDisplay(
            locationForm.value['displayNumber2'].trim()
          )
        );
      }
      if (locationForm.value['displayNumber3'].trim()) {
        retailLocation.RetailDisplays.push(
          this.retailersService.newRetailDisplay(
            locationForm.value['displayNumber3'].trim()
          )
        );
      }
      if (locationForm.value['displayNumber4'].trim()) {
        retailLocation.RetailDisplays.push(
          this.retailersService.newRetailDisplay(
            locationForm.value['displayNumber4'].trim()
          )
        );
      }
      retailer.RetailLocations.push(retailLocation);
    });
    return retailer;
  }
}
