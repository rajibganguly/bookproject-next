import {
  AfterContentInit,
  AfterViewInit,
  Component,
  Input,
  NgZone,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { RetailerDataService } from '../../services/retailer-data.service';
import { RetailLocation } from 'src/app/models/retailer/retailLocation';
import { RetailersService } from '../retailers.service';
import { RetailLocationAddDialogComponent } from '../retail-location-add-dialog/retail-location-add-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { Observable, forkJoin, map, of, switchMap } from 'rxjs';
import { Router } from '@angular/router';
import { ActionCompletedDialogComponent } from 'src/app/core/action-completed-dialog/action-completed-dialog.component';

@Component({
  selector: 'app-retail-locations-table',
  templateUrl: './retail-locations-table.component.html',
  styleUrls: ['./retail-locations-table.component.scss']
})
export class RetailLocationsTableComponent
  implements OnInit, AfterViewInit, OnChanges, AfterContentInit
{
  @Input() retailerId = '';
  displayedColumns: string[] = ['Name', 'city', 'state', 'id'];
  dataSource: MatTableDataSource<RetailLocation>;
  selectedRowIndex = '';
  expandedRow = '';
  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    private retailerDataService: RetailerDataService,
    private retailersService: RetailersService,
    private ngZone: NgZone,
    private dialog: MatDialog,
    private router: Router
  ) {
    this.dataSource = new MatTableDataSource();
  }
  ngAfterContentInit(): void {
    this.selectedRowIndex = this.retailersService.locationName;
  }

  ngOnInit(): void {
    if (this.retailerId) {
      this.dataSource.data = this.retailerDataService.getRetailLocations(
        this.retailerId
      );
      this.dataSource.sort = this.sort;
    }

    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case 'name':
          return item.Name;
        case 'city':
          return item.StreetAddress.City;
        case 'state':
          return item.StreetAddress.State;
        default:
          return item.Name;
      }
    };
  }

  ngAfterViewInit(): void {
    this.ngZone.runOutsideAngular(() => {
      setTimeout(() => {
        this.sort.sort({ id: 'Name', start: 'asc', disableClear: false });
        this.dataSource.sort = this.sort;
      });
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes) {
      this.retailerId = changes['retailerId'].currentValue;
      if (!this.retailerId) {
        this.dataSource.data = [];
      } else {
        const retailLocations = this.retailerDataService.getRetailLocations(
          this.retailerId
        );
        if (retailLocations.length > 0) {
          this.dataSource.data = retailLocations;
        } else {
          this.loadRetailerLocations();
        }
      }
      this.dataSource.sort = this.sort;
    }
  }

  loadRetailerLocations(retailerLocationId = '') {
    this.retailerDataService
      .loadRetailerLocations(this.retailerId)
      .subscribe((locations) => {
        if (locations && locations.length > 0) {
          this.retailerDataService.retailLocations = [];
          this.retailerDataService.retailLocations =
            this.retailerDataService.retailLocations.concat(locations);
          this.dataSource.data = this.retailerDataService.getRetailLocations(
            this.retailerId
          );
          if (retailerLocationId !== '') {
            this.retailersService.retailLocationId = retailerLocationId;
          }
        } else {
          this.dataSource.data = [];
        }
      });
  }
  selectDisplays(retailLocation: RetailLocation) {
    this.selectedRowIndex = retailLocation.Name;
    this.retailersService.retailLocationId = retailLocation.RetailLocationId;
    this.retailersService.retailDisplayId = '';
    console.log('Selected Location: ' + this.retailersService.retailLocationId);
  }
  openSuccessDialog(retailerLocation: string): void {
    this.dialog.open(ActionCompletedDialogComponent, {
      data: { name: retailerLocation }
    });
  }
  addLocation() {
    let retailLocation = '';
    this.dialog
      .open(RetailLocationAddDialogComponent, {
        width: '600px',
        data: { retailerId: this.retailersService.retailerId }
      })
      .afterClosed()
      .pipe(
        switchMap((locationToAdd: RetailLocation) => {
          retailLocation = locationToAdd.Name;
          if (!locationToAdd) {
            return of(false);
          }
          return this.addLocationAndDisplays(locationToAdd);
        })
      )
      .subscribe((res) => {
        this.openSuccessDialog(retailLocation);
      });
  }

  addLocationAndDisplays(location: RetailLocation): Observable<boolean> {
    return this.retailerDataService
      .postRetailLocation(this.retailerId, location)
      .pipe(
        switchMap((retailLocation: RetailLocation) => {
          const displayRequests: Observable<any>[] = [];
          location.RetailDisplays.forEach((retailDisplay) => {
            displayRequests.push(
              this.retailerDataService.postRetailDisplay(
                this.retailerId,
                retailLocation.RetailLocationId,
                retailDisplay
              )
            );
          });

          this.retailerDataService.retailLocations.push(retailLocation);
          this.retailersService.retailLocationId =
            retailLocation.RetailLocationId;
          this.dataSource.data = this.retailerDataService.retailLocations;
          this.selectedRowIndex = retailLocation.Name;
          return forkJoin(displayRequests).pipe(
            map((displayResponses) => {
              displayResponses.forEach((displayResponse) => {
                this.retailerDataService.retailDisplays.push(
                  ...displayResponse
                );
              });
              return true;
            })
          );
        })
      );
  }
}
