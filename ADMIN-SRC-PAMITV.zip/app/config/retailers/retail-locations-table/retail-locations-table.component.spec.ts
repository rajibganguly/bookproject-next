import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailLocationsTableComponent } from './retail-locations-table.component';

describe('RetailLocationsTableComponent', () => {
  let component: RetailLocationsTableComponent;
  let fixture: ComponentFixture<RetailLocationsTableComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RetailLocationsTableComponent]
    });
    fixture = TestBed.createComponent(RetailLocationsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
