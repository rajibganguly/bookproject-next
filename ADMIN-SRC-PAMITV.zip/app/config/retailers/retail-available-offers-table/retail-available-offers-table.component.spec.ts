import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailAvailableOffersTableComponent } from './retail-available-offers-table.component';

describe('RetailAvailableOffersTableComponent', () => {
  let component: RetailAvailableOffersTableComponent;
  let fixture: ComponentFixture<RetailAvailableOffersTableComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RetailAvailableOffersTableComponent]
    });
    fixture = TestBed.createComponent(RetailAvailableOffersTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
