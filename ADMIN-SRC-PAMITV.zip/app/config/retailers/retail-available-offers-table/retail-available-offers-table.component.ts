import {
  AfterViewInit,
  Component,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Observable, forkJoin, map, of } from 'rxjs';
import { RetailAvailableOffersDetail } from './retail-available-offers-detail';
import { RetailersService } from '../retailers.service';
import { MatDialog } from '@angular/material/dialog';
import { ApplyOfferConfirmationDialogComponent } from '../apply-offer-confirmation-dialog/apply-offer-confirmation-dialog.component';
import { CampaignDataService } from '../../services/campaign-data.service';
import { AdvertiserDataService } from '../../services/advertiser-data.service';
import { Router } from '@angular/router';
import { ApplyOffersToVideoDialogComponent } from '../apply-offers-to-video-dialog/apply-offers-to-video-dialog.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AuthService } from 'src/app/core/services/auth.service';
import { VideoDataService } from '../../services/video-data.service';
import { RetailerDataService } from '../../services/retailer-data.service';
import { Retailer } from 'src/app/models/retailer/retailer';
import { ActionCompletedDialogComponent } from 'src/app/core/action-completed-dialog/action-completed-dialog.component';

@Component({
  selector: 'app-retail-available-offers-table',
  templateUrl: './retail-available-offers-table.component.html',
  styleUrls: ['./retail-available-offers-table.component.scss']
})
export class RetailAvailableOffersTableComponent
  implements OnInit, AfterViewInit, OnChanges
{
  @Input() retailerId = '';
  @Input() retailLocationId: any = undefined;
  @Input() retailDisplayId: any = undefined;
  displayedColumns: string[] = ['CampaignName', 'OfferName', 'SelectOffer'];
  dataSource: MatTableDataSource<RetailAvailableOffersDetail>;
  isLoading = false;
  selectedOfferId = '';
  retailer?: Retailer;

  @ViewChild(MatSort) sort!: MatSort;

  checkedCount = 0;
  maxChecked = 2;

  constructor(
    private retailersService: RetailersService,
    private retailerDataService: RetailerDataService,
    private dialog: MatDialog,
    private campaignDataService: CampaignDataService,
    private advertiserDataService: AdvertiserDataService,
    private snackBar: MatSnackBar,
    private authService: AuthService,
    private videoDataService: VideoDataService,
    private router: Router
  ) {
    this.dataSource = new MatTableDataSource();
  }

  ngOnInit(): void {
    if (this.retailerId) {
      this.retailersService
        .getRetailerAvailableOfferDetail(this.retailerId, this.retailDisplayId)
        .subscribe((data) => {
          this.dataSource.data = data;
        });
    }
    this.dataSource.sort = this.sort;

    this.checkedCount = 0;

    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case 'CampaignName':
          return item.CampaignName;
        case 'OfferName':
          return item.OfferName;
        default:
          return item.CampaignId;
      }
    };
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes) {
      if (Object.prototype.hasOwnProperty.call(changes, 'retailerId')) {
        this.retailerId = changes['retailerId'].currentValue;
        this.checkedCount = 0;
        this.retailer = this.retailerDataService.getRetailer(this.retailerId);
      }
      if (Object.prototype.hasOwnProperty.call(changes, 'retailLocationId')) {
        this.retailLocationId = changes['retailLocationId'].currentValue;
        this.checkedCount = 0;
      }
      if (Object.prototype.hasOwnProperty.call(changes, 'retailDisplayId')) {
        this.retailDisplayId = changes['retailDisplayId'].currentValue;
        this.checkedCount = 0;
      }
      if (this.retailerId) {
        this.retailersService
          .getRetailerAvailableOfferDetail(
            this.retailerId,
            this.retailDisplayId
          )
          .subscribe((data) => {
            this.dataSource.data = data;
          });
      }
      this.dataSource.sort = this.sort;
    }
  }

  onCheckboxChange(row: RetailAvailableOffersDetail): void {
    if (row.isChecked) {
      this.checkedCount++;
    } else {
      this.checkedCount--;
    }
  }

  getYYYY_MM_DD_HH_MM() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0'); // Month is zero-based
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    return `${year}_${month}_${day}_${hours}_${minutes}`;
  }

  onApplyOffers() {
    this.isLoading = true;
    const offers = this.dataSource.data.filter((x) => x.isChecked == true);
    let availableDisplayOptions: any[] = [];
    const observables = offers.map((offer) =>
      this.retailersService.getDisplaysThatCanTakeOffer(
        this.retailerId,
        offer.OfferId
      )
    );
    forkJoin(observables).subscribe((results) => {
      results.forEach((availableOffersDisplays) => {
        availableOffersDisplays.forEach((availableDisplay) => {
          availableDisplayOptions.push({
            label: `${availableDisplay.RetailLocationName} - ${availableDisplay.DisplayId}`,
            selected: false,
            retailDisplayId: availableDisplay.RetailDisplayId,
            displayId: availableDisplay.DisplayId
          });
        });
      });
      this.isLoading = false;
      availableDisplayOptions = availableDisplayOptions.filter(
        (displayOption, index, self) =>
          self.findIndex(
            (other) => other.retailDisplayId === displayOption.retailDisplayId
          ) === index
      );

      const message = this.retailer?.Name;
      this.dialog
        .open(ApplyOffersToVideoDialogComponent, {
          width: '600px',
          data: { message, availableDisplayOptions, offers }
        })
        .afterClosed()
        .subscribe((overlayRequests) => {
          if (overlayRequests) {
            this.applyOfferToDisplays(
              overlayRequests.offer1,
              overlayRequests.selectedDisplays
            ).subscribe((displayOffers1) => {
              this.applyOfferToDisplays(
                overlayRequests.offer2,
                overlayRequests.selectedDisplays
              ).subscribe((displayOffers2) => {
                const videoServiceRequest: {
                  RequestId: string;
                  Requester: string;
                  VideoOverlayRequests: any[];
                } = {
                  RequestId: `${this.retailer?.Name.replace(
                    ' ',
                    '_'
                  )}_${this.getYYYY_MM_DD_HH_MM()}`,
                  Requester: this.authService.currentUser.Email,
                  VideoOverlayRequests: []
                };
                const displayOffers = displayOffers1.concat(displayOffers2);
                overlayRequests.selectedDisplays.forEach(
                  (selectedDisplay: any) => {
                    const displayOffer1 = displayOffers.find(
                      (x) =>
                        x.RetailDisplayId == selectedDisplay.retailDisplayId &&
                        x.OfferId == overlayRequests.offer1.OfferId
                    );
                    const videoOverlayRequest = {
                      RequestId: `${selectedDisplay.displayId}_${
                        overlayRequests.offer1.OfferName
                      }_${this.getYYYY_MM_DD_HH_MM()}`,
                      InputVideoUrl: overlayRequests.selectedVideo,
                      OutputDirectory: this.retailer?.RetailerId,
                      OverlayImageDetails: [
                        {
                          OverlayTemplateId:
                            overlayRequests.offer1VideoOverlayTemplate,
                          OverlayImageUrl: displayOffer1.QrCodeUrl
                        }
                      ]
                    };
                    if (overlayRequests.offer2) {
                      const displayOffer2 = displayOffers.find(
                        (x) =>
                          x.RetailDisplayId ==
                            selectedDisplay.retailDisplayId &&
                          x.OfferId == overlayRequests.offer2.OfferId
                      );
                      videoOverlayRequest.OverlayImageDetails.push({
                        OverlayTemplateId:
                          overlayRequests.offer2VideoOverlayTemplate,
                        OverlayImageUrl: displayOffer2.QrCodeUrl
                      });
                    }
                    videoServiceRequest.VideoOverlayRequests.push(
                      videoOverlayRequest
                    );
                  }
                );
                const videoRequest = JSON.stringify(videoServiceRequest);
                console.log('videoServiceRequest', videoRequest);
                this.videoDataService
                  .postVideoServiceRequest(videoRequest)
                  .subscribe((request) => {
                    const msg = `Video Service Request ${videoServiceRequest.RequestId} has been queued. ${this.authService.currentUser.Email} will be notified when complete.`;
                    this.snackBar.open(msg, 'Dismiss', {
                      duration: 5000
                    });
                  });
              });
            });
          }
        });
    });
  }

  onApplyOffer() {
    const offers = this.dataSource.data.filter((x) => x.isChecked == true);
    if (offers.length > 1) {
      this.snackBar.open('Only available when 1 offer is selected', 'Close', {
        duration: 3000
      });
      return;
    }
    const offer = offers[0];
    const advertiser = this.advertiserDataService.getAdvertiser(
      offer.AdvertiserId
    );
    const message = `${advertiser?.Name}/${offer.CampaignName}/${offer.OfferName}`;
    this.selectedOfferId = offer.OfferId;
    const availableDisplayOptions: any[] = [];
    this.isLoading = true;
    this.retailersService
      .getDisplaysThatCanTakeOffer(this.retailerId, offer.OfferId)
      .subscribe(
        (availableOffersDisplays) => {
          availableOffersDisplays.forEach((availableDisplay) => {
            availableDisplayOptions.push({
              label: `${availableDisplay.RetailLocationName} - ${availableDisplay.DisplayId}`,
              selected: false,
              retailDisplayId: availableDisplay.RetailDisplayId,
              retailLocation: availableDisplay.RetailLocationName,
              displayId: availableDisplay.DisplayId
            });
          });
          this.isLoading = false;
          this.dialog
            .open(ApplyOfferConfirmationDialogComponent, {
              width: '300px',
              data: { message, availableDisplayOptions }
            })
            .afterClosed()
            .subscribe((selectedDisplays) => {
              if (selectedDisplays) {
                const locationName = selectedDisplays[0].retailLocation;
                const retailDisplayId = selectedDisplays[0].retailDisplayId;
                this.applyOfferToDisplays(offer, selectedDisplays).subscribe(
                  (results) => {
                    console.log('applyOfferToDisplays-returned', results);
                    this.retailersService.locationName = locationName;
                    this.retailersService.retailDisplayId = retailDisplayId;
                    this.openSuccessDialog(
                      this.retailerDataService.getRetailer(this.retailerId)
                        ?.Name
                    );
                    this.retailersService.displayOffersCreated.next(results);
                  }
                );
              }
            });
        },
        (error) => {
          console.log(error);
          this.isLoading = false;
        }
      );
  }

  openSuccessDialog(retailerName = ''): void {
    this.dialog.open(ActionCompletedDialogComponent, {
      data: { name: 'Display offer(s) for ' + retailerName }
    });
  }

  applyOfferToDisplays(offer: RetailAvailableOffersDetail, displayList: any[]) {
    console.log('applyOfferToDisplays', displayList);
    const applyOfferResponses: any[] = [];
    if (!offer) {
      return of(applyOfferResponses);
    }
    const displayOfferRequests: Observable<any>[] = [];
    displayList.forEach((display) => {
      const displayOffer = {
        CampaignId: offer.CampaignId,
        OfferTemplateId: offer.OfferTemplateId,
        OfferId: offer.OfferId,
        RetailDisplayId: display.retailDisplayId
      };
      displayOfferRequests.push(
        this.campaignDataService.postCampaignDisplayOffer(
          offer.CampaignId,
          offer.OfferTemplateId,
          offer.OfferId,
          displayOffer
        )
      );
    });
    return forkJoin(displayOfferRequests).pipe(
      map((displayOfferResponses) => {
        displayOfferResponses.forEach((displayOfferResponse) => {
          displayOfferResponse.displayOffers.forEach((displayResponse: any) => {
            displayResponse.OfferId = offer.OfferId;
            applyOfferResponses.push(displayResponse);
          });
        });
        return applyOfferResponses;
      })
    );
  }
}
