export class RetailAvailableOffersDetail {
    public OfferId: string = '';
    public OfferName: string = '';
    public CampaignId: string = '';
    public CampaignName: string = '';
    public OfferTemplateId: string = '';
    public OfferTemplateName: string = '';
    public AdvertiserId: string = '';
    public AdvertiserName: string = '';
    public RetailerId: string = '';
    public RetailerName: string = '';
    public AdAgencyId: string = '';
    public AdAgencyName: string = '';
    public Enabled: boolean = false;
    isChecked: boolean = false;
  
    constructor(initialValues?: Partial<RetailAvailableOffersDetail>) {
      if (initialValues) {
        Object.assign(this, initialValues);
      }
    }
  }