import { Injectable } from '@angular/core';
import { Observable, Subject, forkJoin, from, map, of, switchMap } from 'rxjs';
import { RetailAvailableOffersDetail } from './retail-available-offers-table/retail-available-offers-detail';
import { CampaignDataService } from '../services/campaign-data.service';
import { OfferDataService } from '../services/offer-data.service';
import { Campaign } from 'src/app/models/campaign/campaign';
import { RetailDisplayOfferDetail } from './retail-display-offers-table/retail-display-offer-detail';
import { DisplayOfferDataService } from '../services/displayOffer-data.service';
import { RetailerDataService } from '../services/retailer-data.service';
import { RetailDisplay } from 'src/app/models/retailer/retailDisplay';

@Injectable()
export class RetailersService {
  showRetailLocationAdd = false;
  displayWizard = false;
  retailerId = '';
  retailLocationId = '';
  retailDisplayId = '';
  retailerName = '';
  locationName = '';
  showRetailerSuccessModal = true;
  displayOffersCreated = new Subject<any>();
  constructor(
    private displayOfferDataService: DisplayOfferDataService,
    private retailerDataService: RetailerDataService,
    private campaignDataService: CampaignDataService,
    private offerDataService: OfferDataService
  ) {}

  getRetailerAvailableOfferDetail(
    retailerId: string,
    retailDisplayId: string
  ): Observable<RetailAvailableOffersDetail[]> {
    return of(this.getOffersForRetailer(retailerId));
  }

  getCampaignsForRetailer(retailerId: string): Campaign[] {
    const campaigns = this.campaignDataService.getAuthorizedCampaigns();
    const retailerCampaigns = campaigns.filter(
      (x) => x.RetailerId === retailerId || x.AllRetailers === true
    );
    return retailerCampaigns;
  }

  getOffersForRetailer(retailerId: string): RetailAvailableOffersDetail[] {
    const retailerCampaigns = this.getCampaignsForRetailer(retailerId);
    const availbleOfferTableRows: RetailAvailableOffersDetail[] = [];
    retailerCampaigns.forEach((retailerCampaign) => {
      const offerTemplates = this.offerDataService.getOfferTemplates(
        retailerCampaign.CampaignId
      );
      offerTemplates.forEach((offerTemplate) => {
        const templateOffers = this.offerDataService.getTemplateOffers(
          offerTemplate.OfferTemplateId
        );
        templateOffers.forEach((templateOffer) => {
          const rowData = {
            CampaignId: retailerCampaign.CampaignId,
            CampaignName: retailerCampaign.Name,
            OfferTemplateId: offerTemplate.OfferTemplateId,
            OfferTemplateName: offerTemplate.Name,
            AdvertiserId: retailerCampaign.AdvertiserId,
            AdvertiserName: 'N/A',
            RetailerId: retailerId,
            RetailerName: 'N/A',
            AdAgencyId: retailerCampaign.AdAgencyId,
            AdAgencyName: 'N/A',
            OfferId: templateOffer.OfferId,
            OfferName: templateOffer.Name,
            Enabled: templateOffer.Active
          };
          const tableRow = new RetailAvailableOffersDetail(rowData);
          availbleOfferTableRows.push(tableRow);
        });
      });
    });
    return availbleOfferTableRows;
  }

  getDisplaysThatCanTakeOffer(
    retailerId: string,
    offerId: string
  ): Observable<RetailDisplay[]> {
    const availableDisplays: RetailDisplay[] = [];
    console.log('getDisplaysThatCanTakeOffer', offerId);
    const displayList =
      this.retailerDataService.getRetailerDisplays(retailerId);
    const retailDisplays: RetailDisplay[] = JSON.parse(
      JSON.stringify(displayList)
    );
    console.log('Target Retail Displays', retailDisplays);
    retailDisplays.forEach((retailDisplay) => {
      const displayOfferLinks =
        this.displayOfferDataService.getDisplayOfferLinks(offerId);
      const offersForThisDisplay = displayOfferLinks.filter(
        (x) => x.RetailDisplayId === retailDisplay.RetailDisplayId
      );
      if (offersForThisDisplay.length === 0) {
        availableDisplays.push(retailDisplay);
      }
    });
    return of(availableDisplays);
  }

  getDisplayOfferDetail(
    retailerId: string,
    retailLocationId: string,
    retailDisplayId: string
  ): Observable<RetailDisplayOfferDetail[]> {
    const displayOfferData: RetailDisplayOfferDetail[] = [];

    if (!retailDisplayId) {
      return of(displayOfferData);
    }

    const retailerOffers = this.getOffersForRetailer(this.retailerId);

    return this.retailerDataService
      .loadLocationDisplayOfferLinks(
        retailerId,
        retailLocationId,
        retailDisplayId
      )
      .pipe(
        switchMap((displayOfferLinks) => {
          //console.log('loadLocationDisplayOfferLinks', displayOfferLinks);
          const displayOfferBlobRequests: Observable<any>[] = [];

          displayOfferLinks.forEach((displayOfferLink) => {
            displayOfferBlobRequests.push(
              from(
                this.displayOfferDataService.loadDisplayOffer(
                  displayOfferLink.DisplayOfferId
                )
              )
            );
          });
          return forkJoin(displayOfferBlobRequests).pipe(
            map((displayOfferBlobResponses) => {
              displayOfferBlobResponses.forEach((displayOfferBlobResponse) => {
                const retailDisplay = this.retailerDataService.getRetailDisplay(
                  displayOfferBlobResponse.RetailDisplayId
                );

                if (retailDisplay) {
                  const retailOfferDetail = retailerOffers.find(
                    (x) => x.OfferId === displayOfferBlobResponse.OfferId
                  );

                  if (displayOfferBlobResponse.hasOwnProperty('QRCodeUrl')) {
                    displayOfferBlobResponse.QrCodeUrl =
                      displayOfferBlobResponse.QRCodeUrl;
                  }

                  displayOfferData.push(
                    new RetailDisplayOfferDetail({
                      DisplayOfferId: displayOfferBlobResponse.DisplayOfferId,
                      OfferId: displayOfferBlobResponse.OfferId,
                      OfferName: retailOfferDetail?.OfferName,
                      CampaignId: displayOfferBlobResponse.CampaignId,
                      CampaignName: retailOfferDetail?.CampaignName,
                      AdvertiserId: displayOfferBlobResponse.AdvertiserId,
                      RedirectUrl: displayOfferBlobResponse.RedirectUrl,
                      QrCodeUrl: displayOfferBlobResponse.QrCodeUrl,
                      RetailerId: this.retailerId,
                      RetailLocationId: retailDisplay?.RetailLocationId,
                      RetailDisplayId: displayOfferBlobResponse.RetailDisplayId,
                      DisplayId: retailDisplay?.DisplayId,
                      Enabled: displayOfferBlobResponse.Enabled
                    })
                  );
                }
              });
              if (retailDisplayId) {
                return displayOfferData.filter(
                  (x) => x.RetailDisplayId === retailDisplayId
                );
              } else {
                return displayOfferData;
              }
            })
          );
        })
      );
  }

  newRetailDisplay(displayId: string): RetailDisplay {
    return new RetailDisplay(
      '',
      '',
      '',
      displayId,
      '',
      true,
      'Device Type 1',
      'Portrait',
      ''
    );
  }
}
