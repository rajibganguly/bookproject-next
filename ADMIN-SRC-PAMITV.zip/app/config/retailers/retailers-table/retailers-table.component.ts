import {
  AfterViewInit,
  Component,
  ElementRef,
  NgZone,
  OnInit,
  QueryList,
  ViewChild,
  ViewChildren
} from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { RetailerDataService } from '../../services/retailer-data.service';
import { Retailer } from 'src/app/models/retailer/retailer';
import { ActivatedRoute, Router } from '@angular/router';
import { RetailersService } from '../retailers.service';
import { FormControl, FormGroup } from '@angular/forms';
import { ChangeDetectorRef } from '@angular/core';
import { RetailLocation } from 'src/app/models/retailer/retailLocation';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ErrorSnackbarComponent } from '../error-snackbar/error-snackbar.component';
import { ActionCompletedDialogComponent } from 'src/app/core/action-completed-dialog/action-completed-dialog.component';
import { CampaignDataService } from '../../services/campaign-data.service';
import { CampaignsService } from '../../campaigns/campaigns.service';
import { AuthService } from 'src/app/core/services/auth.service';
import { ConfirmationDialogComponent } from 'src/app/core/confirmation-dialog/confirmation-dialog.component';

@Component({
  selector: 'app-retailers-table',
  templateUrl: './retailers-table.component.html',
  styleUrls: ['./retailers-table.component.scss']
})
export class RetailersTableComponent implements OnInit, AfterViewInit {
  displayedColumns: string[] = ['Name', 'city', 'state', 'id'];
  dataSource: MatTableDataSource<Retailer>;
  selectedRowIndex = '';
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChildren('rowName') rowElements!: QueryList<ElementRef<HTMLElement>>;

  isLoading = false;
  columnsToDisplay = this.displayedColumns;
  columnsToDisplayWithExpand = [...this.columnsToDisplay];
  expandedElement: string | null = null;
  initialRender = true;
  canDelete = false;
  retailerDetailsForm = new FormGroup({
    Name: new FormControl(''),
    Description: new FormControl(''),
    Active: new FormControl(true),
    SicCode: new FormControl(''),
    Phone1: new FormControl(''),
    RetailerId: new FormControl(''),
    MailingAddress: new FormGroup({
      Address1: new FormControl(''),
      Address2: new FormControl(''),
      City: new FormControl(''),
      State: new FormControl(''),
      PostalCode: new FormControl('')
    })
  });

  constructor(
    private retailerDataService: RetailerDataService,
    public retailersService: RetailersService,
    private router: Router,
    private route: ActivatedRoute,
    private ngZone: NgZone,
    private cdk: ChangeDetectorRef,
    public dialog: MatDialog,
    private _snackBar: MatSnackBar,
    private campaignDataService: CampaignDataService,
    private campaignsService: CampaignsService,
    private authService: AuthService
  ) {
    this.dataSource = new MatTableDataSource();
  }

  sortData() {
    this.dataSource.sort = this.sort;
    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case 'name':
          return item.Name;
        case 'city':
          return item.MailingAddress.City;
        case 'state':
          return item.MailingAddress.State;
        default:
          return item.Name;
      }
    };
  }

  ngOnInit(): void {
    this.dataSource.data = this.retailerDataService.getAuthorizedRetailers();
    this.sortData();
    this.selectedRowIndex = this.retailersService.retailerName;
    console.log(this.selectedRowIndex);
    if (
      this.selectedRowIndex !== '' &&
      this.retailersService.showRetailerSuccessModal
    ) {
      this.retailersService.showRetailerSuccessModal = false;
      this.openSuccessDialog(this.selectedRowIndex);
    }
  }
  ngAfterViewInit(): void {
    this.ngZone.runOutsideAngular(() => {
      setTimeout(() => {
        this.sort.sort({ id: 'Name', start: 'asc', disableClear: false });
        this.dataSource.sort = this.sort;
        if (this.selectedRowIndex !== '') {
          this.scrollToElement();
        }
      });
    });
    this.initialRender = false;
    this.cdk.detectChanges();
  }

  openSuccessDialog(retailerName: string): void {
    const dialogRef = this.dialog.open(ActionCompletedDialogComponent, {
      data: { name: retailerName, buttonText: 'Create Campaign' }
    });
    dialogRef.afterClosed().subscribe((task: string) => {
      if (task === 'transfer') {
        this.campaignsService.displayWizard = true;
        this.router.navigate(['Campaigns/Wizard']);
        this.authService.navTitle = 'Campaigns';
      } else if (task === 'stay') {
        this.campaignDataService.retailerId = '';
        this.campaignDataService.retailerName = '';
      }
    });
  }

  scrollToElement(): void {
    this.rowElements
      .toArray()
      .find((element) => element.nativeElement.id === this.selectedRowIndex)
      ?.nativeElement.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
        inline: 'nearest'
      });
  }

  selectLocations(retailer: Retailer) {
    this.canDelete = false;
    this.updateRetailerDetailsForm(retailer);
    this.selectedRowIndex = retailer.Name;
    if (this.retailersService.retailerId !== retailer.RetailerId) {
      this.retailersService.retailLocationId = '';
      this.retailersService.retailDisplayId = '';
      this.retailerDataService.retailDisplays = [];
    }

    this.retailersService.retailerId = retailer.RetailerId;
    console.log('Selected Retailer: ' + this.retailersService.retailerId);
    this.retailerDataService
      .loadRetailerLocations(retailer.RetailerId)
      .subscribe(
        (res: Array<RetailLocation>) => {
          if (res.length > 0) this.canDelete = false;
          else this.canDelete = true;
        },
        (error) => {
          console.log(error);
        }
      );
  }

  updateRetailerDetailsForm(retailer: Retailer) {
    this.retailerDetailsForm = new FormGroup({
      Name: new FormControl(retailer.Name),
      Description: new FormControl(retailer.Description),
      Active: new FormControl(retailer.Active),
      SicCode: new FormControl(''),
      Phone1: new FormControl(retailer.Phone1),
      RetailerId: new FormControl(retailer.RetailerId),
      MailingAddress: new FormGroup({
        Address1: new FormControl(retailer.MailingAddress.Address1),
        Address2: new FormControl(retailer.MailingAddress.Address2),
        City: new FormControl(retailer.MailingAddress.City),
        State: new FormControl(retailer.MailingAddress.State),
        PostalCode: new FormControl(retailer.MailingAddress.PostalCode)
      })
    });
  }

  addRetailer() {
    console.log('addRetailer');
    this.router.navigate(['Wizard'], { relativeTo: this.route });
    this.retailersService.displayWizard = true;
  }
  handleUpdate() {
    this.isLoading = true;
    const currentRetailer: Retailer = {
      Name: this.retailerDetailsForm.controls['Name'].value!,
      Description: this.retailerDetailsForm.value.Description!,
      Phone1: this.retailerDetailsForm.controls['Phone1'].value!,
      RetailerId: this.retailerDetailsForm.value.RetailerId!,
      Active: this.retailerDetailsForm.value.Active!,
      SicCode: this.retailerDetailsForm.value.SicCode!,
      MailingAddress: {
        Address1: this.retailerDetailsForm.value.MailingAddress!.Address1!,
        Address2: this.retailerDetailsForm.value.MailingAddress!.Address2!,
        City: this.retailerDetailsForm.value.MailingAddress!.City!,
        State:
          this.retailerDetailsForm.value.MailingAddress!.State!.toUpperCase(),
        PostalCode: this.retailerDetailsForm.value.MailingAddress!.PostalCode!,
        Country: ''
      },
      RetailLocations: []
    };
    this.retailerDataService.putRetailerDetail(currentRetailer)?.subscribe(
      (res: Retailer) => {
        this.expandedElement = res.RetailerId;
        this.retailerDataService.loadAuthorizedRetailers().subscribe(
          (res) => {
            if (res) {
              this.dataSource.data = res;
              this.sortData();
              this.retailerDataService.retailers = res;
            }
          },
          (error) => {
            console.log(error);
          }
        );
        this.updateRetailerDetailsForm(res);
      },
      (error) => {
        console.log(error);
      },
      () => {
        this.isLoading = false;
      }
    );
  }
  openDialog(retailer: Retailer) {
    if (!this.canDelete) return;

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: {
        message: `Are you sure you want to Delete ${retailer.Name}?`,
        header: 'Confirm Action',
        cancelBtnName: 'NO',
        confirmBtnName: 'YES'
      }
    });

    dialogRef.afterClosed().subscribe((res) => {
      if (res) {
        this.isLoading = true;
        this.retailerDataService.deleteRetailer(retailer.RetailerId)?.subscribe(
          () => {
            this.expandedElement = null;
            this.retailerDataService.loadAuthorizedRetailers().subscribe(
              (res) => {
                this.dataSource.data = res;
                this.sortData();
                this.retailerDataService.retailers = res;
              },
              (error) => {
                console.log(error);
              }
            );
          },
          (error: Error) => {
            console.log(error);
            this.isLoading = false;
            this._snackBar.openFromComponent(ErrorSnackbarComponent, {
              duration: 5 * 1000,
              data: { msg: error.message }
            });
          },
          () => {
            this.canDelete = false;
            this.isLoading = false;
          }
        );
      }
    });
  }
}
