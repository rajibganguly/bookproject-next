import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailersTableComponent } from './retailers-table.component';

describe('RetailersTableComponent', () => {
  let component: RetailersTableComponent;
  let fixture: ComponentFixture<RetailersTableComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RetailersTableComponent]
    });
    fixture = TestBed.createComponent(RetailersTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
