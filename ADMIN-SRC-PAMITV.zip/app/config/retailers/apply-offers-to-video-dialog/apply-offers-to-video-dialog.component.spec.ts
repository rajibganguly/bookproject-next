import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplyOffersToVideoDialogComponent } from './apply-offers-to-video-dialog.component';

describe('ApplyOffersToVideoDialogComponent', () => {
  let component: ApplyOffersToVideoDialogComponent;
  let fixture: ComponentFixture<ApplyOffersToVideoDialogComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ApplyOffersToVideoDialogComponent]
    });
    fixture = TestBed.createComponent(ApplyOffersToVideoDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
