import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { VideoDataService } from '../../services/video-data.service';
import { VideoOverlayTemplate } from 'src/app/models/video/videoOverlayTemplate';
import { TemplatesDataService } from '../../services/templates-data.service';
import { RetailAvailableOffersDetail } from '../retail-available-offers-table/retail-available-offers-detail';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-apply-offers-to-video-dialog',
  templateUrl: './apply-offers-to-video-dialog.component.html',
  styleUrls: ['./apply-offers-to-video-dialog.component.scss'],
})
export class ApplyOffersToVideoDialogComponent implements OnInit {
  selectedCount = 0;
  availableDisplays: any[] = [];
  videoOverlayTemplates: VideoOverlayTemplate[] = [];
  selectedVideo: string | undefined;
  offer1VideoOverlayTemplate: string | undefined;
  offer2VideoOverlayTemplate: string | undefined;
  offer1: RetailAvailableOffersDetail | undefined;
  offer2: RetailAvailableOffersDetail | undefined;
  videoChoices: any[] = [];
  videoUrl: string | undefined;
  videoSafeUrl: SafeResourceUrl | undefined;
  retailerName: string;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<ApplyOffersToVideoDialogComponent>,
    private videoDataService: VideoDataService,
    private templatesDataService: TemplatesDataService,
    private sanitizer: DomSanitizer
  ) {
    this.retailerName = data.message;
    this.availableDisplays = data.availableDisplayOptions;
    this.offer1 = data.offers[0];
    if (data.offers.length > 1) {
      this.offer2 = data.offers[1];
    }
  }

  async ngOnInit(): Promise<void> {
    const campaignIds: string[] = [];
    if (this.offer1) {
      campaignIds.push(this.offer1.CampaignId);
    }
    if (this.offer2) {
      campaignIds.push(this.offer2.CampaignId);
    }
    await this.videoDataService
      .getInputVideoByCampaigns(campaignIds)
      .then((videos) => { 
        videos.forEach((video) => {
          const parts = video.split("/");
          this.videoChoices.push({
            label: parts[1],
            value: video,
          });
        });
      });
    this.videoOverlayTemplates = this.templatesDataService.getVideoTemplates();
  }

  getSelectedOptions() {
    return this.availableDisplays.filter((option) => option.selected);
  }

  applySelected(row: any) {
    console.log('applySelected', row);
    //row.selected = !row.selected;
    if (row.selected) {
      this.selectedCount++;
    } else {
      this.selectedCount--;
    }
  }

  formValid() {
    let valid =
      this.selectedCount > 0 &&
      this.offer1VideoOverlayTemplate !== undefined &&
      this.videoUrl !== undefined;
    if (valid) {
      if (this.offer2 !== undefined) {
        if (this.offer2VideoOverlayTemplate === undefined) {
          valid = false;
        }
      }
    }
    return valid;
  }

  confirmApply() {
    const selectedDisplays = this.availableDisplays.filter(
      (option) => option.selected
    );
    const videoRequests = {
      selectedVideo: this.videoUrl,
      offer1VideoOverlayTemplate: this.offer1VideoOverlayTemplate,
      offer2VideoOverlayTemplate: this.offer2VideoOverlayTemplate,
      offer1: this.offer1,
      offer2: this.offer2,
      selectedDisplays: selectedDisplays,
    };
    console.log('confirmApply', videoRequests);
    this.dialogRef.close(videoRequests);
  }

  onSelectVideo(event: any): void {
    console.log('Selected video file: ', this.selectedVideo);
    if (this.selectedVideo) {
      this.videoUrl = this.videoDataService.videoUrl(
        this.videoDataService.videoStorageAcctPublicUrl,
        this.videoDataService.inputVideoContainer,
        this.selectedVideo
      );
      this.videoSafeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
        this.videoUrl
      );
    }
  }

  closeDialog() {
    this.dialogRef.close();
  }
}
