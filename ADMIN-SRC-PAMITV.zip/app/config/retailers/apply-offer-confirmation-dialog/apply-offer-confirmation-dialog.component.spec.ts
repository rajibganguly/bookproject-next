import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplyOfferConfirmationDialogComponent } from './apply-offer-confirmation-dialog.component';

describe('ApplyOfferConfirmationDialogComponent', () => {
  let component: ApplyOfferConfirmationDialogComponent;
  let fixture: ComponentFixture<ApplyOfferConfirmationDialogComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ApplyOfferConfirmationDialogComponent]
    });
    fixture = TestBed.createComponent(ApplyOfferConfirmationDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
