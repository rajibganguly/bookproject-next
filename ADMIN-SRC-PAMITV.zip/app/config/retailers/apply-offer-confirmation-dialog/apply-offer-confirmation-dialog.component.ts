import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-apply-offer-confirmation-dialog',
  templateUrl: './apply-offer-confirmation-dialog.component.html',
  styleUrls: ['./apply-offer-confirmation-dialog.component.scss']
})
export class ApplyOfferConfirmationDialogComponent {
  selectedCount = 0;
  checkboxOptions: any[] = [];
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<ApplyOfferConfirmationDialogComponent>
  ) {
    this.checkboxOptions = data.availableDisplayOptions;
  }

  getSelectedOptions() {
    return this.checkboxOptions.filter((option) => option.selected);
  }

  applySelected(row: any) {
    console.log('applySelected', row);
    row.selected = !row.selected;
    if (row.selected) {
      this.selectedCount++;
    } else {
      this.selectedCount--;
    }
  }

  confirmApply() {
    console.log('confirmApply');
    const selectedDisplays = this.checkboxOptions.filter((option) => {
      return option.selected;
    });
    this.dialogRef.close(selectedDisplays);
  }
}
