import { Component, NgZone, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { VideoDataService } from '../../services/video-data.service';
import { VideoDetailDialogComponent } from '../video-detail-dialog/video-detail-dialog.component';
import { MatTableDataSource } from '@angular/material/table';
import { VideoFile } from 'src/app/models/video/videoFile';
import { MatSort } from '@angular/material/sort';
import { AuthService } from 'src/app/core/services/auth.service';
import { RetailerDataService } from '../../services/retailer-data.service';

@Component({
  selector: 'app-videos-output-table',
  templateUrl: './videos-output-table.component.html',
  styleUrls: ['./videos-output-table.component.scss']
})
export class VideosOutputTableComponent implements OnInit {
  videoFiles: string[] = [];
  dataSource: MatTableDataSource<VideoFile>;
  displayedColumns = ['Campaign Name'];
  selectedRowIndex: any = undefined;
  selectedCampaignName = '';
  map: Map<string, string[]>;
  @ViewChild(MatSort) sort!: MatSort;
  isAuthorized = false;
  allVideoFiles: string[] = [];
  constructor(
    private videoDataService: VideoDataService,
    private dialog: MatDialog,
    private ngZone: NgZone,
    private retailerDataService: RetailerDataService,
    private authService: AuthService
  ) {
    this.dataSource = new MatTableDataSource();
    this.map = new Map<string, string[]>();
  }

  async ngOnInit(): Promise<void> {
    this.loadInputVideos();
  }

  selectCampaign(campaignId: string, campaignName: string) {
    this.selectedRowIndex = campaignId;
    this.videoFiles = this.map.get(campaignId)!;
    this.selectedCampaignName = campaignName;
  }

  async loadInputVideos() {
    this.isAuthorized = this.authService.isAuthorized();
    this.allVideoFiles = await this.videoDataService.getOutputVideos();
    this.map = new Map<string, string[]>();
    this.allVideoFiles.forEach((file) => {
      const content = file.split('/');
      if (content.length == 1 || content[0] === '') {
        if (!this.map.has('unknown')) this.map.set('unknown', []);
        this.map.get('unknown')?.push(content[0]);
      } else {
        if (!this.map.has(content[0])) this.map.set(content[0], []);
        this.map.get(content[0])?.push(content[1]);
      }
    });
    const group: VideoFile[] = [];
    for (const [key, value] of this.map) {
      group.push({
        files: value,
        campaignId: key,
        campaignName:
          key === 'unknown'
            ? 'unknown'
            : this.retailerDataService.getRetailer(key)?.Name!
      });
    }
    this.dataSource.data = group;
    this.ngZone.runOutsideAngular(() => {
      setTimeout(() => {
        this.sort.sort({
          id: 'Campaign Name',
          start: 'asc',
          disableClear: false
        });
        this.dataSource.sort = this.sort;
      });
    });
    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case 'Campaign Name':
          return item.campaignName;
        default:
          return item.campaignName;
      }
    };
  }

  selectVideo(videoFileName: string) {
    this.dialog
      .open(VideoDetailDialogComponent, {
        width: '600px',
        height: '800px',
        data: {
          title: 'Processed Video',
          fileName: videoFileName,
          storageAcct: this.videoDataService.videoStorageAcctPublicUrl,
          container: this.videoDataService.outputVideoContainer,
          groupName: this.selectedCampaignName,
          groupId: this.selectedRowIndex
        }
      })
      .afterClosed();
  }
}
