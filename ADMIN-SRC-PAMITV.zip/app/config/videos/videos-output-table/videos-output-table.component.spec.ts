import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VideosOutputTableComponent } from './videos-output-table.component';

describe('VideosOutputTableComponent', () => {
  let component: VideosOutputTableComponent;
  let fixture: ComponentFixture<VideosOutputTableComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VideosOutputTableComponent]
    });
    fixture = TestBed.createComponent(VideosOutputTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
