import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VideosInputTableComponent } from './videos-input-table.component';

describe('VideosInputTableComponent', () => {
  let component: VideosInputTableComponent;
  let fixture: ComponentFixture<VideosInputTableComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VideosInputTableComponent]
    });
    fixture = TestBed.createComponent(VideosInputTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
