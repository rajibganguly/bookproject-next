import { Component, NgZone, OnInit, ViewChild } from '@angular/core';
import { VideoDataService } from '../../services/video-data.service';
import { MatDialog } from '@angular/material/dialog';
import { VideoDetailDialogComponent } from '../video-detail-dialog/video-detail-dialog.component';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { VideoFile } from 'src/app/models/video/videoFile';
import { CampaignDataService } from '../../services/campaign-data.service';
import { AuthService } from 'src/app/core/services/auth.service';
import { VideosUploadWizardComponent } from '../videos-upload-wizard/videos-upload-wizard.component';

@Component({
  selector: 'app-videos-input-table',
  templateUrl: './videos-input-table.component.html',
  styleUrls: ['./videos-input-table.component.scss']
})
export class VideosInputTableComponent implements OnInit {
  videoFiles: string[] = [];
  dataSource: MatTableDataSource<VideoFile>;
  displayedColumns = ['Campaign Name'];
  selectedRowIndex: any = undefined;
  selectedCampaignName = '';
  map: Map<string, string[]>;
  @ViewChild(MatSort) sort!: MatSort;
  isAuthorized = false;
  constructor(
    private videoDataService: VideoDataService,
    private dialog: MatDialog,
    private ngZone: NgZone,
    private campaignDataService: CampaignDataService,
    private authService: AuthService
  ) {
    this.dataSource = new MatTableDataSource();
    this.map = new Map<string, string[]>();
  }

  async ngOnInit(): Promise<void> {
    this.loadInputVideos();
  }

  selectVideo(videoFileName: string) {
    this.dialog
      .open(VideoDetailDialogComponent, {
        width: '600px',
        height: '800px',
        data: {
          title: 'Raw Video',
          fileName: videoFileName,
          storageAcct: this.videoDataService.videoStorageAcctPublicUrl,
          container: this.videoDataService.inputVideoContainer,
          groupName: this.selectedCampaignName,
          groupId: this.selectedRowIndex
        }
      })
      .afterClosed();
  }
  selectCampaign(campaignId: string, campaignName: string) {
    this.selectedRowIndex = campaignId;
    this.selectedCampaignName = campaignName;
    this.videoFiles = this.map.get(campaignId)!;
  }

  async loadInputVideos() {
    this.isAuthorized = this.authService.isAuthorized();
    const allVideoFiles: string[] =
      await this.videoDataService.getInputVideos();
    this.map = new Map<string, string[]>();
    allVideoFiles.map((file) => {
      const content = file.split('/');
      if (content.length == 1 || content[0] === '') {
        if (!this.map.has('unknown')) this.map.set('unknown', []);
        this.map.get('unknown')?.push(content[0]);
      } else {
        if (!this.map.has(content[0])) this.map.set(content[0], []);
        this.map.get(content[0])?.push(content[1]);
      }
    });
    const group: VideoFile[] = [];
    for (const [key, value] of this.map)
      group.push({
        files: value,
        campaignId: key,
        campaignName:
          key === 'unknown'
            ? 'unknown'
            : this.campaignDataService.getCampaign(key)?.Name!
      });
    this.dataSource.data = group;
    this.ngZone.runOutsideAngular(() => {
      setTimeout(() => {
        this.sort.sort({
          id: 'Campaign Name',
          start: 'asc',
          disableClear: false
        });
        this.dataSource.sort = this.sort;
      });
    });
    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case 'Campaign Name':
          return item.campaignName;
        default:
          return item.campaignName;
      }
    };
  }
  handleUploadWizard() {
    const ref = this.dialog.open(VideosUploadWizardComponent, {
      width: '500px',
      height: '500px',
      hasBackdrop: true
    });
    ref.afterClosed().subscribe(async (res) => {
      if (res) {
        await this.loadInputVideos();
        this.selectCampaign(this.selectedRowIndex, this.selectedCampaignName);
      }
    });
  }
}
