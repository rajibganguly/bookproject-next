import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VideoDetailDialogComponent } from './video-detail-dialog.component';

describe('VideoDetailDialogComponent', () => {
  let component: VideoDetailDialogComponent;
  let fixture: ComponentFixture<VideoDetailDialogComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VideoDetailDialogComponent]
    });
    fixture = TestBed.createComponent(VideoDetailDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
