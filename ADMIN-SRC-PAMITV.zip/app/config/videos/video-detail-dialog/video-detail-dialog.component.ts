import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { VideoDataService } from '../../services/video-data.service';

@Component({
  selector: 'app-video-detail-dialog',
  templateUrl: './video-detail-dialog.component.html',
  styleUrls: ['./video-detail-dialog.component.scss']
})
export class VideoDetailDialogComponent {
  videoUrl: SafeResourceUrl;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<VideoDetailDialogComponent>,
    private sanitizer: DomSanitizer,
    private videoDataService: VideoDataService
  ) {
    this.videoUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
      this.videoDataService.videoUrl(
        data.storageAcct,
        data.container,
        data.groupId + '/' + data.fileName
      )
    );
  }
}
