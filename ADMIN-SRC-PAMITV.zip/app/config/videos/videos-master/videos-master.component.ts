import { Component } from '@angular/core';
import { animate, style, transition, trigger } from '@angular/animations';

@Component({
  selector: 'app-videos-master',
  templateUrl: './videos-master.component.html',
  styleUrls: ['./videos-master.component.scss'],
  animations: [
    trigger('flyInOut', [
      transition(':enter', [
        style({ transform: 'translateX(100%)' }),
        animate(200)
      ]),
      transition(':leave', [
        animate(200, style({ transform: 'translateX(-100%)' }))
      ])
    ])
  ]
})
export class VideosMasterComponent {}
