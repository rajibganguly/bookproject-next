import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { CampaignDataService } from '../../services/campaign-data.service';
import { Campaign } from 'src/app/models/campaign/campaign';
import { FileUploadService } from '../file-upload.service';

@Component({
  selector: 'app-videos-upload-wizard',
  templateUrl: './videos-upload-wizard.component.html',
  styleUrls: ['./videos-upload-wizard.component.scss'],
})
export class VideosUploadWizardComponent implements OnInit {
  isUploading = false;
  campaignsAndIds: string[][] = []; // 0-> Name, 1->Id
  selectedCampaignId: string = '';
  selectedFile: File | null = null;
  constructor(
    private dialogRef: MatDialogRef<VideosUploadWizardComponent>,
    private campaignService: CampaignDataService,
    private fileUploadService: FileUploadService
  ) {}

  ngOnInit(): void {
    this.loadAllCampaigns();
  }

  loadAllCampaigns() {
    this.campaignService
      .loadAuthorizedCampaigns()
      .subscribe((res: Campaign[]) => {
        res.map((campaign: Campaign) => {
          this.campaignsAndIds.push([campaign.Name, campaign.CampaignId]);
        });
        this.campaignsAndIds.sort((i1: string[], i2: string[]) => {
          return i1[0].localeCompare(i2[0]);
        });
      });
  }
  onFileSelected(event: any) {
    this.selectedFile = event.target?.files[0];
  }
  onNoClick() {}
  async handleUpload() {
    this.isUploading = true;
    if (this.selectedFile != null) {
      await this.fileUploadService.uploadFile(
        this.selectedFile,
        this.selectedCampaignId
      );
      this.isUploading = false;
      this.dialogRef.close(true);
    } else {
      this.isUploading = false;
      this.dialogRef.close(false);
    }
  }
}
