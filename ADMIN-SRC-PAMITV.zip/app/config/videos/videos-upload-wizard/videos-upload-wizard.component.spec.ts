import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VideosUploadWizardComponent } from './videos-upload-wizard.component';

describe('VideosUploadWizardComponent', () => {
  let component: VideosUploadWizardComponent;
  let fixture: ComponentFixture<VideosUploadWizardComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VideosUploadWizardComponent]
    });
    fixture = TestBed.createComponent(VideosUploadWizardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
