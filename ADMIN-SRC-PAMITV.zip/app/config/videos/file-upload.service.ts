// file-upload.service.ts

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {
  BlobServiceClient,
  ContainerClient,
  BlockBlobClient,
} from '@azure/storage-blob';
import { AppConfigService } from 'src/app/core/services/app-config.service';

@Injectable({
  providedIn: 'root',
})
export class FileUploadService {
  private containerClient: ContainerClient;

  constructor(private cfgSvc: AppConfigService) {
    const connectionString =
      'BlobEndpoint=' +
      cfgSvc.appConfig.videoStorageAcctUrl +
      ';' +
      'SharedAccessSignature=' +
      cfgSvc.appConfig.videoStorageSasToken;
    const containerName = 'input';
    const blobServiceClient =
      BlobServiceClient.fromConnectionString(connectionString);
    this.containerClient = blobServiceClient.getContainerClient(containerName);
  }

  async uploadFile(file: File, id: string): Promise<string> {
    const blobName = id + '/' + file.name;
    const blockBlobClient = this.containerClient.getBlockBlobClient(blobName);

    await blockBlobClient.uploadBrowserData(file);

    const url = blockBlobClient.url;
    return url;
  }
}
