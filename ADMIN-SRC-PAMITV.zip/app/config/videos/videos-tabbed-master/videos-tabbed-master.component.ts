import { Component } from '@angular/core';

@Component({
  selector: 'app-videos-tabbed-master',
  templateUrl: './videos-tabbed-master.component.html',
  styleUrls: ['./videos-tabbed-master.component.scss']
})
export class VideosTabbedMasterComponent {}
