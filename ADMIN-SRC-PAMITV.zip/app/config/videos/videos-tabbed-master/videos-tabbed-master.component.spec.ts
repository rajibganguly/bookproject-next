import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VideosTabbedMasterComponent } from './videos-tabbed-master.component';

describe('VideosTabbedMasterComponent', () => {
  let component: VideosTabbedMasterComponent;
  let fixture: ComponentFixture<VideosTabbedMasterComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VideosTabbedMasterComponent]
    });
    fixture = TestBed.createComponent(VideosTabbedMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
