import { AfterViewInit, Component, NgZone, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { TemplatesDataService } from '../../services/templates-data.service';
import { MatTableDataSource } from '@angular/material/table';
import { VideoOverlayTemplate } from 'src/app/models/video/videoOverlayTemplate';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-videos-overlay-templates-table',
  templateUrl: './videos-overlay-templates-table.component.html',
  styleUrls: ['./videos-overlay-templates-table.component.scss'],
})
export class VideosOverlayTemplatesTableComponent implements OnInit, AfterViewInit {
  dataSource: MatTableDataSource<VideoOverlayTemplate>;

  @ViewChild(MatSort) sort!: MatSort;

  displayedColumns: string[] = [
    'Name',
    'Description',
    'X',
    'Y',
    'Width',
    'Height',
  ];

  constructor(
    private templatesDataService: TemplatesDataService,
    private dialog: MatDialog,
    private ngZone: NgZone 
  ) {
    this.dataSource = new MatTableDataSource();
  }

  ngOnInit() {
    this.dataSource.data = this.templatesDataService.getVideoTemplates();
    this.dataSource.sort = this.sort;

    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case 'Name':
          return item.Name;
        case 'Description':
          return item.Description;
        default:
          return item.Name;
      }
    };
  }

  ngAfterViewInit(): void {
    this.ngZone.runOutsideAngular(() => {
      setTimeout(() => {
        this.sort.sort({ id: 'Name', start: 'asc', disableClear: false });
        this.dataSource.sort = this.sort;
      });
    });
  }
}
