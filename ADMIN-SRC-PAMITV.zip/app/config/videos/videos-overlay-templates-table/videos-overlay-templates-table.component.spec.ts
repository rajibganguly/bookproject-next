import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VideosOverlayTemplatesTableComponent } from './videos-overlay-templates-table.component';

describe('VideosOverlayTemplatesTableComponent', () => {
  let component: VideosOverlayTemplatesTableComponent;
  let fixture: ComponentFixture<VideosOverlayTemplatesTableComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VideosOverlayTemplatesTableComponent]
    });
    fixture = TestBed.createComponent(VideosOverlayTemplatesTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
