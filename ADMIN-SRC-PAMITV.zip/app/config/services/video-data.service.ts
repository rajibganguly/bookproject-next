import { AnonymousCredential, BlobServiceClient } from '@azure/storage-blob';

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppConfigService } from 'src/app/core/services/app-config.service';
import { Observable, of } from 'rxjs';

@Injectable()
export class VideoDataService {
  videoStorageAcctUrl = this.cfgSvc.appConfig.videoStorageAcctUrl;
  videoStorageSasToken = this.cfgSvc.appConfig.videoStorageSasToken;
  videoStorageAcctPublicUrl = this.cfgSvc.appConfig.videoStorageAcctPublicUrl;
  videoServiceApiUrl = this.cfgSvc.appConfig.videoServiceApiUrl;
  videoServiceApiFuncKey = this.cfgSvc.appConfig.videoServiceApiFuncKey;
  inputVideoContainer = 'input';
  outputVideoContainer = 'output';

  constructor(private cfgSvc: AppConfigService, private http: HttpClient) {}

  async getInputVideos(): Promise<string[]> {
    return this.listBlobs(
      this.videoStorageAcctUrl,
      this.videoStorageSasToken,
      this.inputVideoContainer
    );
  }
  
  async getInputVideoByCampaigns(campaignIds: string[]): Promise<string[]> {
    const selectedVideos: string[] = [];
    try {
      const videoFileNames = await this.listBlobs(
        this.videoStorageAcctUrl,
        this.videoStorageSasToken,
        this.inputVideoContainer
      );
  
      campaignIds.forEach((campaignId) => {
        const videosForCampaign = videoFileNames.filter((fileName) =>
          fileName.includes(campaignId)
        );
        selectedVideos.push(...videosForCampaign);
      });
  
      return selectedVideos;
    } catch (error) {
      // Handle error if necessary
      throw new Error("Error in fetching video files: " + error);
    }
  }
  


  async getOutputVideos(): Promise<string[]> {
    return this.listBlobs(
      this.videoStorageAcctUrl,
      this.videoStorageSasToken,
      this.outputVideoContainer
    );
  }

  videoUrl(storageAcct: string, container: string, fileName: string) {
    return `${storageAcct}/${container}/${fileName}`;
  }

  async listBlobs(
    storageAcctUrl: string,
    storageAcctToken: string,
    containerName: string
  ): Promise<string[]> {
    const anonymousCredential = new AnonymousCredential();
    const blobServiceClient = new BlobServiceClient(
      storageAcctUrl + storageAcctToken,
      anonymousCredential
    );
    const containerClient = blobServiceClient.getContainerClient(containerName);

    const blobList = [];
    for await (const blob of containerClient.listBlobsFlat()) {
      blobList.push(blob.name);
    }

    return blobList;
  }

  postVideoServiceRequest(videoServiceRequest: string): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.videoServiceApiFuncKey,
        pamitvkey: this.videoServiceApiFuncKey,
      }),
    };
    const url = `${this.videoServiceApiUrl}/QueueOverlayRequest`;
    return this.http.post(url, videoServiceRequest, httpOptions);
  }
}
