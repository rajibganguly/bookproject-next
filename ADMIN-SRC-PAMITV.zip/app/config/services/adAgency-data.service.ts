import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppConfigService } from '../../core/services/app-config.service';
import { AdAgency } from 'src/app/models/adAgency/adAgency';

@Injectable()
export class AdAgencyDataService {
  adAgencyId: string = '';

  adAgencies: Array<AdAgency> = [
    {
      Name: 'PamiTv',
      AdAgencyId: '001',
    },
  ];

  constructor(private http: HttpClient, private cfgSvc: AppConfigService) {}

  getAuthorizedAdAgencies(): Array<AdAgency> {
    return this.adAgencies;
  }

  getAdAgency(adAgencyId: string): AdAgency | undefined {
    return this.adAgencies.find((x) => x.AdAgencyId == adAgencyId);
  }
}
