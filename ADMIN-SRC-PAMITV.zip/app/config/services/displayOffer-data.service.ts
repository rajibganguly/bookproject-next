import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppConfigService } from '../../core/services/app-config.service';
import { DisplayOfferLink } from 'src/app/models/displayOffer/displayOfferLink';
import { BlobService } from 'src/app/core/services/blob.service';
import { Observable, of } from 'rxjs';
import { DisplayOffer } from 'src/app/models/displayOffer/displayOffer';

@Injectable()
export class DisplayOfferDataService {
  campaignApiUrl = this.cfgSvc.appConfig.campaignApiUrl;
  campaignApiFuncKey = this.cfgSvc.appConfig.campaignApiFuncKey;
  campaignBrandTemplateFuncKey =
    this.cfgSvc.appConfig.campaignBrandTemplateFuncKey;
  displayOffer00StorageAcctUrl =
    this.cfgSvc.appConfig.displayOffer00StorageAcctUrl;
  displayOfferBlob = this.cfgSvc.appConfig.displayOfferBlob;
  displayOffer00StorageSasToken =
    this.cfgSvc.appConfig.displayOffer00StorageSasToken;
  campaignsEndpoint = this.cfgSvc.appConfig.campaignsEndpoint;

  displayOfferLinks: Array<DisplayOfferLink> = [];
  displayOffers: Array<DisplayOffer> = [];

  constructor(
    private http: HttpClient,
    private cfgSvc: AppConfigService,
    private blobService: BlobService
  ) {}

  getDisplayOfferLinks(offerId: string): DisplayOfferLink[] {
    console.log('getDisplayOfferLinks', offerId);
    return this.displayOfferLinks.filter((x) => x.OfferId === offerId);
  }

  loadDisplayOfferLinks(
    campaignId: string,
    offerTemplateId: string,
    offerId: string
  ): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.campaignApiFuncKey,
        pamitvkey: this.campaignApiFuncKey
      })
    };
    const url = `${this.campaignApiUrl}/Campaign/${campaignId}/OfferTemplate/${offerTemplateId}/Offer/${offerId}/DisplayOffers`;
    return this.http.get(url, httpOptions);
  }

  loadDisplayOffer(displayOfferId: string) {
    //console.log('loadDisplayOffer', displayOfferId);
    const displayOffer = this.displayOffers.find(
      (x) => x.DisplayOfferId == displayOfferId
    );
    if (displayOffer) {
      //console.log('loadDisplayOffer - already had it');
      return of(displayOffer);
    }
    return this.blobService
      .GetJsonBlob(
        this.displayOffer00StorageAcctUrl,
        this.displayOffer00StorageSasToken,
        displayOfferId,
        this.displayOfferBlob
      )
      .then((resp) => {
        this.displayOffers.push(resp);
        return resp;
      });
  }

  /***
   * @description Delete offer/s for Campaign offer if no displayOffer
   */
  deleteOffer(campaignId: string, offerTemplateId: string, offerId: string) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.campaignBrandTemplateFuncKey,
        pamitvkey: this.campaignBrandTemplateFuncKey
      })
    };
    const url = `${this.campaignsEndpoint}/${campaignId}/OfferTemplate/${offerTemplateId}/Offer/${offerId}`;
    return this.http.delete(url, httpOptions);
  }
}
