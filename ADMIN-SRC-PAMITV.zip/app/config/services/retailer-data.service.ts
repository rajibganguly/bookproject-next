import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders
} from '@angular/common/http';
import { AppConfigService } from '../../core/services/app-config.service';
import { Retailer } from 'src/app/models/retailer/retailer';
import { RetailLocation } from 'src/app/models/retailer/retailLocation';
import { RetailDisplay } from 'src/app/models/retailer/retailDisplay';
import { Observable, catchError, throwError } from 'rxjs';
import { AuthService } from 'src/app/core/services/auth.service';
import { IRetailerUpdateDetails } from '../types';
import { DisplayOfferLink } from 'src/app/models/displayOffer/displayOfferLink';

@Injectable()
export class RetailerDataService {
  retailerApiUrl = this.cfgSvc.appConfig.retailerApiUrl;
  retailerApiFuncKey = this.cfgSvc.appConfig.retailerApiFuncKey;

  retailers: Array<Retailer> = [];
  retailLocations: Array<RetailLocation> = [];
  retailDisplays: Array<RetailDisplay> = [];

  constructor(
    private http: HttpClient,
    private cfgSvc: AppConfigService,
    private authService: AuthService
  ) {}

  initialize() {
    this.loadAuthorizedRetailers().subscribe((resp) => {
      if (resp) {
        this.retailers = resp;
      }
    });
  }

  getAuthorizedRetailers(): Array<Retailer> {
    return this.retailers;
  }

  loadAuthorizedRetailers(): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.retailerApiFuncKey,
        pamitvkey: this.retailerApiFuncKey
      })
    };
    const url = `${this.retailerApiUrl}/Retailers`;
    return this.http.get(url, httpOptions);
  }

  loadRetailerLocations(retailerId: string): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.retailerApiFuncKey,
        pamitvkey: this.retailerApiFuncKey
      })
    };
    const url = `${this.retailerApiUrl}/Retailer/${retailerId}/Locations`;
    return this.http.get(url, httpOptions);
  }

  loadLocationDisplays(
    retailerId: string,
    locationId: string
  ): Observable<RetailDisplay[]> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.retailerApiFuncKey,
        pamitvkey: this.retailerApiFuncKey
      })
    };
    const url = `${this.retailerApiUrl}/Retailer/${retailerId}/Location/${locationId}/Displays`;
    return this.http.get<RetailDisplay[]>(url, httpOptions);
  }

  loadLocationDisplayOfferLinks(
    retailerId: string,
    locationId: string,
    displayId: string
  ): Observable<DisplayOfferLink[]> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.retailerApiFuncKey,
        pamitvkey: this.retailerApiFuncKey
      })
    };
    const url = `${this.retailerApiUrl}/Retailer/${retailerId}/Location/${locationId}/Display/${displayId}/DisplayOffers`;
    return this.http.get<DisplayOfferLink[]>(url, httpOptions);
  }

  getRetailLocations(retailerId: string): Array<RetailLocation> {
    return this.retailLocations.filter((x) => x.RetailerId == retailerId);
  }

  getRetailDisplays(retailLocationId: string): Array<RetailDisplay> {
    return this.retailDisplays.filter(
      (x) => x.RetailLocationId == retailLocationId
    );
  }

  getRetailDisplay(retailDisplayId: string): RetailDisplay | undefined {
    return this.retailDisplays.find(
      (x) => x.RetailDisplayId == retailDisplayId
    );
  }

  getRetailerDisplays(retailerId: string) {
    const retailerDisplays: RetailDisplay[] = [];
    this.getRetailLocations(retailerId).forEach((location) => {
      this.getRetailDisplays(location.RetailLocationId).forEach(
        (retailDisplay) => {
          retailDisplay.RetailLocationName = location.Name;
          retailerDisplays.push(retailDisplay);
        }
      );
    });
    return retailerDisplays;
  }

  getRetailer(retailerId: string): Retailer | undefined {
    return this.retailers.find((x) => x.RetailerId == retailerId);
  }

  getRetailLocation(retailerLocationId: string): RetailLocation | undefined {
    return this.retailLocations.find(
      (x) => x.RetailLocationId == retailerLocationId
    );
  }

  postRetailer(retailer: Retailer): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.retailerApiFuncKey,
        pamitvkey: this.retailerApiFuncKey
      })
    };
    const url = `${this.retailerApiUrl}/Retailer`;
    return this.http.post(url, retailer, httpOptions);
  }

  postRetailLocation(
    retailerId: string,
    retailLocation: RetailLocation
  ): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.retailerApiFuncKey,
        pamitvkey: this.retailerApiFuncKey
      })
    };
    const url = `${this.retailerApiUrl}/Retailer/${retailerId}/Location`;
    return this.http.post(url, retailLocation, httpOptions);
  }

  postRetailDisplay(
    retailerId: string,
    retailLocationId: string,
    retailDisplay: RetailDisplay
  ): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.retailerApiFuncKey,
        pamitvkey: this.retailerApiFuncKey
      })
    };
    const url = `${this.retailerApiUrl}/Retailer/${retailerId}/Location/${retailLocationId}/Display`;
    return this.http.post(url, retailDisplay, httpOptions);
  }

  putRetailerDetail(
    retailerDetails: IRetailerUpdateDetails
  ): Observable<Retailer> | null {
    if (this.authService.isAuthorized()) {
      const url = `${this.retailerApiUrl}/UpdateRetailer`;
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'x-functions-key': this.retailerApiFuncKey,
          pamitvkey: this.retailerApiFuncKey
        })
      };
      return this.http.put<Retailer>(url, retailerDetails, httpOptions);
    }
    return null;
  }
  deleteRetailer(retailerId: string): Observable<null> {
    if (!this.authService.isAuthorized())
      return throwError(() => new Error('Unauthorized'));
    const url = `${this.retailerApiUrl}/Retailer/${retailerId}`;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-function-key': this.retailerApiFuncKey,
        pamitvkey: this.retailerApiFuncKey
      })
    };
    return this.http.delete<null>(url, httpOptions).pipe(
      catchError(() => {
        return throwError(
          () => new Error('Something bad happened; please try again later.')
        );
      })
    );
  }
}
