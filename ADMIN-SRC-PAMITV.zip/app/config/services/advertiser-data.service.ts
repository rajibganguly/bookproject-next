import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppConfigService } from '../../core/services/app-config.service';
import { Advertiser } from 'src/app/models/advertiser/advertiser';
import { Observable } from 'rxjs';

@Injectable()
export class AdvertiserDataService {
  advertiserId: string = '';
  advertiserApiUrl = this.cfgSvc.appConfig.advertiserApiUrl;
  advertiserApiFuncKey = this.cfgSvc.appConfig.advertiserApiFuncKey;

  advertisers: Array<Advertiser> = [];

  constructor(private http: HttpClient, private cfgSvc: AppConfigService) {}

  initialize() {
    this.loadAuthorizedAdvertisers().subscribe((resp) => {
      if (resp) {
        this.advertisers = resp;
      }
    });
  }

  getAuthorizedAdvertisers(): Array<Advertiser> {
    return this.advertisers;
  }

  loadAuthorizedAdvertisers(): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.advertiserApiFuncKey,
        pamitvkey: this.advertiserApiFuncKey,
      }),
    };
    const url = `${this.advertiserApiUrl}/Advertisers`;
    return this.http.get(url, httpOptions);
  }

  getAdvertiser(advertiserId: string): Advertiser | undefined {
    return this.advertisers.find((x) => x.AdvertiserId == advertiserId);
  }

  postAdvertiser(advertiser: Advertiser): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.advertiserApiFuncKey,
        pamitvkey: this.advertiserApiFuncKey,
      }),
    };
    const url = `${this.advertiserApiUrl}/advertiser`;
    return this.http.post(url, advertiser, httpOptions);
  }
}
