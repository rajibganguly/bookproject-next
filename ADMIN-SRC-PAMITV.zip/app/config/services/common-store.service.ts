/* eslint-disable prettier/prettier */
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

@Injectable({ providedIn: 'root' })
export class CommonStoreService {
  // Initialise container
  private offerTypeRedirectSubject = new BehaviorSubject<object>({});
  private offerTypeRedirectFlag = new BehaviorSubject<boolean>(true);
  private currentAdvertiserId = new BehaviorSubject<string>('');

  setRedirectOffertypeValue(value: {
    campaignName: string;
    campaignId: string;
    offerTemplateId: string;
    campaignOfferType: number | undefined;
  }) {
    this.offerTypeRedirectSubject.next(value);
  }

  getRedirectOffertypeValue() {
    return this.offerTypeRedirectSubject.asObservable();
  }

  /***
   * Selected Offer type flag
   */

  setRedirectOffertypeFlag(value: boolean) {
    this.offerTypeRedirectFlag.next(value);
  }

  getRedirectOffertypeFlag() {
    return this.offerTypeRedirectFlag.asObservable();
  }

  /***
   * Selected Advertiser Id
   */

  setAdvertiserId(value: string) {
    this.currentAdvertiserId.next(value);
  }

  getAdvertiserId() {
    return this.currentAdvertiserId.asObservable();
  }
}
