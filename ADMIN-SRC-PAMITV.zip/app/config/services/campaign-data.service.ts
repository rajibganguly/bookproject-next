import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppConfigService } from '../../core/services/app-config.service';
import { Campaign } from 'src/app/models/campaign/campaign';
import { Observable, concatMap, forkJoin, map } from 'rxjs';
import { OfferTemplate } from 'src/app/models/offer/offer-template';
import { Offer } from 'src/app/models/offer/offer';
import { OfferDataService } from './offer-data.service';
@Injectable()
export class CampaignDataService {
  retailerId = ''; // used for redirect from retailer to campaign wizard
  retailerName = ''; // used for redirect from retailer to campaign wizard

  campaignApiUrl = this.cfgSvc.appConfig.campaignApiUrl;
  campaignApiFuncKey = this.cfgSvc.appConfig.campaignApiFuncKey;

  campaigns: Array<Campaign> = [];

  constructor(
    private http: HttpClient,
    private cfgSvc: AppConfigService,
    private offerDataService: OfferDataService
  ) {}

  initialize() {
    this.loadAuthorizedCampaigns()
      .pipe(
        concatMap((campaigns) => {
          this.campaigns = campaigns;
          const offerTemplateRequests: Observable<any>[] = [];
          campaigns.forEach((campaign: { CampaignId: string }) => {
            offerTemplateRequests.push(
              this.offerDataService.loadCampaignOfferTemplates(
                campaign.CampaignId
              )
            );
          });
          return forkJoin(offerTemplateRequests).pipe(
            map((offerTemplateResponses) => {
              offerTemplateResponses.forEach((offerTemplateResponse) => {
                offerTemplateResponse.forEach((offerTemplate: any) => {
                  this.offerDataService.offerTemplates.push(offerTemplate);
                });
              });
              return offerTemplateResponses;
            }),
            concatMap((offerTemplateResponses) => {
              const offerRequests: Observable<any>[] = [];
              offerTemplateResponses.forEach((offerTemplates) => {
                offerTemplates.forEach((offerTemplate: any) => {
                  offerRequests.push(
                    this.offerDataService.loadCampaignTemplateOffers(
                      offerTemplate.CampaignId,
                      offerTemplate.OfferTemplateId
                    )
                  );
                });
              });
              return forkJoin(offerRequests).pipe(
                map((offerResponses) => {
                  offerResponses.forEach((offerResponse) => {
                    offerResponse.forEach((offer: Offer) => {
                      this.offerDataService.offers.push(offer);
                    });
                  });
                })
              );
            })
          );
        })
      )
      .subscribe();
  }

  getAuthorizedCampaigns(): Array<Campaign> {
    return this.campaigns;
  }

  loadAuthorizedCampaigns(): Observable<Campaign[]> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.campaignApiFuncKey,
        pamitvkey: this.campaignApiFuncKey
      })
    };
    const url = `${this.campaignApiUrl}/Campaigns`;
    return this.http.get<Campaign[]>(url, httpOptions);
  }

  getCampaign(campaignId: string): Campaign | undefined {
    return this.campaigns.find((x) => x.CampaignId == campaignId);
  }

  postCampaign(campaign: Campaign): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.campaignApiFuncKey,
        pamitvkey: this.campaignApiFuncKey
      })
    };
    const url = `${this.campaignApiUrl}/Campaign`;
    return this.http.post(url, campaign, httpOptions);
  }

  postCampaignOfferTemplate(
    campaignId: string,
    offerTemplate: OfferTemplate
  ): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.campaignApiFuncKey,
        pamitvkey: this.campaignApiFuncKey
      })
    };
    const url = `${this.campaignApiUrl}/Campaign/${campaignId}/OfferTemplate`;
    return this.http.post(url, offerTemplate, httpOptions);
  }

  postCampaignOffer(
    campaignId: string,
    offerTemplateId: string,
    offer: Offer
  ): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.campaignApiFuncKey,
        pamitvkey: this.campaignApiFuncKey
      })
    };
    offer.OfferTemplateId = offerTemplateId;
    const url = `${this.campaignApiUrl}/Campaign/${campaignId}/OfferTemplate/${offerTemplateId}/Offer`;
    return this.http.post(url, offer, httpOptions);
  }

  postCampaignDisplayOffer(
    campaignId: string,
    offerTemplateId: string,
    offerId: string,
    displayOffer: any
  ): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.campaignApiFuncKey,
        pamitvkey: this.campaignApiFuncKey
      })
    };
    const url = `${this.campaignApiUrl}/Campaign/${campaignId}/OfferTemplate/${offerTemplateId}/Offer/${offerId}/DisplayOffer`;
    return this.http.post(url, displayOffer, httpOptions);
  }
}
