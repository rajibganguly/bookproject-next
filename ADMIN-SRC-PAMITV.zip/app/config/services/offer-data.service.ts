import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppConfigService } from '../../core/services/app-config.service';
import { OfferTemplate } from 'src/app/models/offer/offer-template';
import { Offer } from 'src/app/models/offer/offer';
import { Observable, catchError, of } from 'rxjs';

@Injectable()
export class OfferDataService {
  offerTemplateId = '';

  campaignApiUrl = this.cfgSvc.appConfig.campaignApiUrl;
  campaignApiFuncKey = this.cfgSvc.appConfig.campaignApiFuncKey;
  simpleRedirectOfferUrl = this.cfgSvc.appConfig.campaignsEndpoint;
  updateCampaignOfferUrl = this.cfgSvc.appConfig.updateCampaignOffer;
  campaignBrandTemplateKey = this.cfgSvc.appConfig.campaignBrandTemplateFuncKey;

  offerTemplates: Array<OfferTemplate> = [];

  offers: Array<Offer> = [];

  constructor(
    private http: HttpClient,
    private cfgSvc: AppConfigService
  ) {}

  getOfferTemplates(campaignId: string): OfferTemplate[] {
    return this.offerTemplates.filter((x) => x.CampaignId == campaignId);
  }

  loadCampaignOfferTemplates(campaignId: string): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.campaignApiFuncKey,
        pamitvkey: this.campaignApiFuncKey
      })
    };
    const url = `${this.campaignApiUrl}/Campaign/${campaignId}/OfferTemplates`;
    return this.http.get(url, httpOptions);
  }

  getOfferTemplate(offerTemplatesId: string): OfferTemplate | undefined {
    return this.offerTemplates.find(
      (x) => x.OfferTemplateId == offerTemplatesId
    );
  }

  getTemplateOffers(offerTemplateId: string): Offer[] {
    return this.offers.filter((x) => x.OfferTemplateId === offerTemplateId);
  }

  loadCampaignTemplateOffers(
    campaignId: string,
    offerTemplateId: string
  ): Observable<Array<Offer>> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.campaignApiFuncKey,
        pamitvkey: this.campaignApiFuncKey
      })
    };
    const url = `${this.campaignApiUrl}/Campaign/${campaignId}/OfferTemplate/${offerTemplateId}/Offers`;
    return this.http.get<Offer[]>(url, httpOptions).pipe(
      catchError((error) => {
        console.log('offertemplate err', error);
        return of([] as Offer[]);
      })
    );
  }

  /***
   * @description: Simple Redirect Offer
   * @param campaignId
   * @param offerTemplateId
   * @param body: addRedirectOffer{}
   * @method: POST
   */
  postSimpleRedirectOffer(
    campaignId: string,
    offerTemplateId: string,
    addRedirectOffer: any
  ): Observable<any> {
    const url = `${this.simpleRedirectOfferUrl}/${campaignId}/OfferTemplate/${offerTemplateId}/Offer`;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        pamitvkey: this.campaignBrandTemplateKey
      })
    };
    return this.http.post(url, addRedirectOffer, httpOptions);
  }

  /***
   * @description: Update Campaign Offer
   * @param body: updateOfferObject{}
   * @method: PUT
   */
  updateCampaignOffers(updateOfferObject: any): Observable<any> {
    const url = `${this.updateCampaignOfferUrl}`;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        pamitvkey: this.campaignBrandTemplateKey
      })
    };
    return this.http.put(url, updateOfferObject, httpOptions);
  }
}
