import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppConfigService } from 'src/app/core/services/app-config.service';
import { Observable } from 'rxjs';
import { VideoOverlayTemplate } from 'src/app/models/video/videoOverlayTemplate';
import { CampaignBrandTemplate } from 'src/app/models/campaign/campaignBrandTemplate';
import { GuestDataTemplate } from 'src/app/models/guestDataTemplate/guestDataTemplate';

@Injectable()
export class TemplatesDataService {
  templatesApiUrl = this.cfgSvc.appConfig.templatesApiUrl;
  templatesApiFuncKey = this.cfgSvc.appConfig.templatesApiFuncKey;

  videoOverlayTemplates: VideoOverlayTemplate[] = [];

  campaignBrandTemplates: CampaignBrandTemplate[] = [];
  campaignBrandTemplateEndpoint =
    this.cfgSvc.appConfig.campaignBrandTemplateEndpoint;
  campaignBrandTemplateFuncKey =
    this.cfgSvc.appConfig.campaignBrandTemplateFuncKey;
  defaultBrandTemplate = this.cfgSvc.appConfig.defaultBrandTemplate;
  guestDataTemplateEndpoint = this.cfgSvc.appConfig.guestDataTemplateEndpoint;
  defaultCampaignBrandAttributesEndpoint =
    this.cfgSvc.appConfig.defaultCampaignBrandAttributesEndpoint;

  guestDataTemplates: GuestDataTemplate[] | null = null;
  guestDataTemplateId = '';
  constructor(
    private cfgSvc: AppConfigService,
    private http: HttpClient
  ) {}

  initialize() {
    this.loadCampaignBrandTemplates();
    this.loadVideoOverlayTemplates().subscribe((resp) => {
      this.videoOverlayTemplates = resp;
    });
  }

  getVideoTemplates(): VideoOverlayTemplate[] {
    return this.videoOverlayTemplates;
  }

  loadVideoOverlayTemplates(): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-functions-key': this.templatesApiFuncKey,
        pamitvkey: this.templatesApiFuncKey
      })
    };
    const url = `${this.templatesApiUrl}/VideoOverlayTemplates`;
    return this.http.get(url, httpOptions);
  }
  getAllCampaignBrandTemplates(): Observable<CampaignBrandTemplate[]> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        pamitvkey: this.campaignBrandTemplateFuncKey
      })
    };
    const url = `${this.campaignBrandTemplateEndpoint}`;
    return this.http.get<CampaignBrandTemplate[]>(url, httpOptions);
  }
  loadCampaignBrandTemplates() {
    this.getAllCampaignBrandTemplates().subscribe(
      (res: CampaignBrandTemplate[]) => {
        this.campaignBrandTemplates = res;
      }
    );
  }
  getCampaignBrandTemplate(id: string) {
    return this.campaignBrandTemplates.filter((res) => {
      return res.CampaignId === id;
    });
  }
  getGuestDataTemplates(): Observable<GuestDataTemplate[]> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        pamitvkey: this.campaignBrandTemplateFuncKey
      })
    };
    const url = `${this.guestDataTemplateEndpoint}`;
    return this.http.get<GuestDataTemplate[]>(url, httpOptions);
  }
  getGuestDataTemplate(id: string) {
    return this.guestDataTemplates?.find(
      (template) => id === template.GuestDataTemplateId
    );
  }
  getDefaultBrandTemplateAttributes(
    campaignId = this.defaultBrandTemplate.campaignId,
    templateId = this.defaultBrandTemplate.templateId
  ): Observable<CampaignBrandTemplate> {
    const url = `${this.defaultCampaignBrandAttributesEndpoint}/${campaignId}/${templateId}`;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        pamitvkey: this.campaignBrandTemplateFuncKey
      })
    };
    return this.http.get<CampaignBrandTemplate>(url, httpOptions);
  }
  postBrandTemplate(
    brandTemplate: Partial<CampaignBrandTemplate>
  ): Observable<CampaignBrandTemplate> {
    const url = `${this.defaultCampaignBrandAttributesEndpoint}`;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        pamitvkey: this.campaignBrandTemplateFuncKey
      })
    };
    delete brandTemplate.CampaignBrandTemplateId;
    return this.http.post<CampaignBrandTemplate>(
      url,
      brandTemplate,
      httpOptions
    );
  }
}
