export interface IRetailerUpdateDetails {
  RetailerId: string;
  Name: string;
  Description: string;
  MailingAddress: {
    Address1: string;
    Address2: string;
    City: string;
    State: string;
    PostalCode: string;
  };
  Active: boolean;
  Phone1: string;
  SicCode: string;
}
