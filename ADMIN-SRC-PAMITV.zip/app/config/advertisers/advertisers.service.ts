import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppConfigService } from 'src/app/core/services/app-config.service';

@Injectable({
  providedIn: 'root'
})
export class AdvertisersService {
  displayWizard = false;

  constructor(private http: HttpClient, private cfgSvc: AppConfigService) {}
}
