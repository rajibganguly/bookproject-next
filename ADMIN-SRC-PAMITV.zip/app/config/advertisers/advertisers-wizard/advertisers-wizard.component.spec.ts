import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvertisersWizardComponent } from './advertisers-wizard.component';

describe('AdvertisersWizardComponent', () => {
  let component: AdvertisersWizardComponent;
  let fixture: ComponentFixture<AdvertisersWizardComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdvertisersWizardComponent]
    });
    fixture = TestBed.createComponent(AdvertisersWizardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
