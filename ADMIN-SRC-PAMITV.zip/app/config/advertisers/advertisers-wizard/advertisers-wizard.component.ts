import { Component, OnInit } from '@angular/core';
import { AdvertisersService } from '../advertisers.service';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators
} from '@angular/forms';
import {
  trigger,
  state,
  style,
  transition,
  animate
} from '@angular/animations';
import { AdvertiserDataService } from '../../services/advertiser-data.service';
import { Advertiser } from 'src/app/models/advertiser/advertiser';
import { StreetAddress } from 'src/app/models/address/streetAddress';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { ActionCompletedDialogComponent } from 'src/app/core/action-completed-dialog/action-completed-dialog.component';
import { filterPhoneNumber } from 'src/app/core/phone-number-functions';
import { PhoneNumberFormatPipe } from 'src/app/core/phone-number-format.pipe';

@Component({
  selector: 'app-advertisers-wizard',
  templateUrl: './advertisers-wizard.component.html',
  styleUrls: ['./advertisers-wizard.component.scss'],
  animations: [
    trigger('flyInOut', [
      // state('in', style({ transform: 'translateX(0)' })),
      transition(':enter', [
        style({ transform: 'translateX(100%)' }),
        animate(200)
      ]),
      transition(':leave', [
        animate(200, style({ transform: 'translateX(-100%)' }))
      ])
    ])
  ]
})
export class AdvertisersWizardComponent implements OnInit {
  advertiserForm!: FormGroup;
  advertiser!: Advertiser;

  constructor(
    private advertiserService: AdvertisersService,
    private advertiserDataService: AdvertiserDataService,
    private fb: FormBuilder,
    private router: Router,
    private dialog: MatDialog,
    private phoneNumberFormat: PhoneNumberFormatPipe
  ) {}

  ngOnInit(): void {
    this.advertiserForm = this.fb.group({
      name: new FormControl('', Validators.required),
      description: new FormControl(''),
      address1: new FormControl('', Validators.required),
      address2: new FormControl(''),
      city: new FormControl('', Validators.required),
      state: new FormControl('', Validators.required),
      postal: new FormControl('', Validators.required),
      phoneNumber: new FormControl('', Validators.pattern('^[0-9]*$'))
    });
  }

  get advertiserName() {
    return this.advertiserForm.get('name');
  }
  get advertiserPhoneNumber() {
    return this.advertiserForm.get('phoneNumber');
  }

  addAdvertiser() {
    this.createAdvertiser();
    const advertiserName = this.advertiserForm.value['name'];
    // Message created
    // const message = `Advertiser ${advertiserName} was successfully created`;
    // Added confirmation dialog
    const ref = this.dialog.open(ActionCompletedDialogComponent, {
      width: '300px',
      data: { name: advertiserName }
    });
    ref.afterClosed().subscribe((res) => {
      if (res) {
        this.advertiserDataService.postAdvertiser(this.advertiser).subscribe(
          (advertiserResp) => {
            console.log('addAdvertiser', advertiserResp);
            this.advertiserDataService.advertisers.push(advertiserResp);
            this.router.navigate(['Advertisers']);
          },
          (error) => {
            console.log('addAdvertiser', error);
          }
        );
      }
    });
  }

  createAdvertiser() {
    this.advertiser = new Advertiser(
      this.advertiserForm.value['name'],
      this.advertiserForm.value['description'],
      '',
      new StreetAddress(
        this.advertiserForm.value['address1'],
        this.advertiserForm.value['address2'],
        this.advertiserForm.value['city'],
        this.advertiserForm.value['state'],
        this.advertiserForm.value['postal'],
        ''
      ),
      filterPhoneNumber(this.advertiserForm.value['phoneNumber']),
      true
    );
  }

  cancelWizard() {
    this.router.navigate(['Advertisers']);
  }
}
