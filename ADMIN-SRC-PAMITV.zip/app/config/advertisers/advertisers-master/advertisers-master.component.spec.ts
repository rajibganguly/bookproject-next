import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvertisersMasterComponent } from './advertisers-master.component';

describe('AdvertisersMasterComponent', () => {
  let component: AdvertisersMasterComponent;
  let fixture: ComponentFixture<AdvertisersMasterComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdvertisersMasterComponent]
    });
    fixture = TestBed.createComponent(AdvertisersMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
