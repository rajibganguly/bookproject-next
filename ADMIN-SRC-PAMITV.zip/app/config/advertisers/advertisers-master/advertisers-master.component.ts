import { Component } from '@angular/core';
import { AdvertiserDataService } from '../../services/advertiser-data.service';
import { AdvertisersService } from '../advertisers.service';

@Component({
  selector: 'app-advertisers-master',
  templateUrl: './advertisers-master.component.html',
  styleUrls: ['./advertisers-master.component.scss']
})
export class AdvertisersMasterComponent {
  constructor(
    public advertiserDataService: AdvertiserDataService,
    public advertiserService: AdvertisersService
  ) {}
}
