import {
  AfterViewInit,
  NgZone,
  Component,
  OnInit,
  ViewChild
} from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Advertiser } from 'src/app/models/advertiser/advertiser';
import { AdvertiserDataService } from '../../services/advertiser-data.service';
import { AdvertisersService } from '../advertisers.service';
import { Router, ActivatedRoute } from '@angular/router';
import {
  animate,
  state,
  style,
  transition,
  trigger
} from '@angular/animations';
import { PhoneNumberFormatPipe } from 'src/app/core/phone-number-format.pipe';

export interface UserData {
  name: string;
  age: number;
  city: string;
}

@Component({
  selector: 'app-advertisers-table',
  templateUrl: './advertisers-table.component.html',
  styleUrls: ['./advertisers-table.component.scss'],
  animations: [
    trigger('flyInOut', [
      // state('in', style({ transform: 'translateX(0)' })),
      transition(':enter', [
        style({ transform: 'translateX(100%)' }),
        animate(200)
      ]),
      transition(':leave', [
        animate(200, style({ transform: 'translateX(-100%)' }))
      ])
    ])
  ]
})
export class AdvertisersTableComponent implements OnInit, AfterViewInit {
  displayedColumns: string[] = ['name', 'phone', 'id'];
  dataSource: MatTableDataSource<Advertiser>;
  selectedRowIndex: any = undefined;

  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    private advertiserDataService: AdvertiserDataService,
    private advertiserService: AdvertisersService,
    private router: Router,
    private route: ActivatedRoute,
    private ngZone: NgZone,
    private phoneNumberFormat: PhoneNumberFormatPipe
  ) {
    this.dataSource = new MatTableDataSource();
  }

  ngOnInit(): void {
    this.dataSource.data =
      this.advertiserDataService.getAuthorizedAdvertisers();
    this.dataSource.sort = this.sort;

    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case 'name':
          return item.Name;
        case 'phone':
          return item.MailingAddress.City;
        default:
          return item.Name;
      }
    };
  }

  // ngOnInit(): void {
  //   this.dataSource.data = this.offerDataService.getTemplateOffers(
  //     this.offerTemplateId
  //   );
  //   this.dataSource.sort = this.sort;

  //   this.dataSource.sortingDataAccessor = (item, property) => {
  //     switch (property) {
  //       case 'Name':
  //         return item.Name;
  //       case 'RedirectUrl':
  //         return item.RedirectBaseUrl;
  //       default:
  //         return item.Name;
  //     }
  //   };
  // }

  ngAfterViewInit(): void {
    this.ngZone.runOutsideAngular(() => {
      setTimeout(() => {
        this.sort.sort({ id: 'Name', start: 'asc', disableClear: false });
        this.dataSource.sort = this.sort;
      });
    });
  }

  // ngAfterViewInit(): void {
  //   this.dataSource.sort = this.sort;
  // }

  addAdvertiser() {
    console.log('addAdvertiser');
    this.router.navigate(['Wizard'], { relativeTo: this.route });
    this.advertiserService.displayWizard = true;
  }
}
